package com.selenium.Setup;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class DriverSetup 

{
WebDriver driver;
String url="www.spiceJet.com";
public WebDriver returnBrowser() throws NumberFormatException, IOException
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
System.out.println("Enter Browser");
System.out.println("1.Google chrome");
System.out.println("2.Firefox");
System.out.println("3.IE");
int ch=Integer.parseInt(br.readLine());

switch(ch)
{
case 1:System.setProperty("webdriver.chrome.driver", "D:\\Development_Avecto\\selenium-chrome-driver-2.25.0.jar\\chromdriver.exe");
       driver =new ChromeDriver();
   	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

       driver.get(url);
   	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

       driver.manage().window().maximize();
   	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
   	break;

case 2:System.setProperty("webdriver.gecko.driver", "D:\\Development_Avecto\\selenium-chrome-driver-2.25.0.jar\\geckodriver.exe");
        driver =new FirefoxDriver();
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

        driver.get(url);
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

        driver.manage().window().maximize();
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
    	break;

case 3:System.setProperty("webdriver.chrome.driver", "D:\\Development_Avecto\\selenium-chrome-driver-2.25.0.jar\\IEdriver.exe");
        driver =new InternetExplorerDriver();
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

        driver.get(url);
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

        driver.manage().window().maximize();
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
    	break;

     
}
return driver;

}

}
