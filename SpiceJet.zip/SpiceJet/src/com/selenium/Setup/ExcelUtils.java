package com.selenium.Setup;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils 
{
  FileInputStream fis;
  XSSFWorkbook book;
  XSSFSheet sheet;
  String cellvalue;
  
  public void openExcel(String path) throws Exception
  {
	  fis=new FileInputStream(path);
	  book=new XSSFWorkbook(fis);
	  sheet=book.getSheetAt(0);
  }
  public String getCellValue(int row, int col)
  {
	cellvalue=  sheet.getRow(row).getCell(col).getStringCellValue();
	return cellvalue;
  }
  
}
