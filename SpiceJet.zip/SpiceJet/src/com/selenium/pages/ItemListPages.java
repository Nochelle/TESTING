package com.selenium.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ItemListPages {
	WebDriver driver;
public ItemListPages(WebDriver driver)
{
	this.driver=driver;
}
By from=By.xpath("//a[text()=' Bengaluru (BLR)']");
By to=By.xpath("//a[text()=' chennai (MAA)']");

By depart=By.xpath("//*[@id=\"ui-datepicker-div\"]/div[1]/table/tbody/tr[2]/td[4]/a");

By ret=By.xpath("//*[@id=\"ui-datepicker-div\"]/div[1]/table/tbody/tr[3]/td[5]/a");
By adults=By.xpath("//*[@id=\"divpaxinfo\"]");
By currency=By.xpath("//*[@id=\"ctl00_mainContent_DropDownListCurrency\"]");

public void getFromPlace(String s1) 
{
	WebElement ele=driver.findElement(from);
	ele.sendKeys(s1);
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
	ele.sendKeys(Keys.ENTER);
}
public void getToPlace(String s2) 
{
	WebElement ele=driver.findElement(to);
	ele.sendKeys(s2);
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
	ele.sendKeys(Keys.ENTER);
}
public void getDepart()
{
	driver.findElement(depart).click();
}
public void getRet()
{
	driver.findElement(ret).click();
}
public void getAdult() 
{
	driver.findElement(adults).click();;
}
public void getCurrency()
{
	driver.findElement(currency).click();
}






}
