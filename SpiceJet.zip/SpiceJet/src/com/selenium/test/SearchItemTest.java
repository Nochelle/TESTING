package com.selenium.test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.selenium.Setup.DriverSetup;
import com.selenium.Setup.ExcelUtils;
import com.selenium.pages.ItemListPages;

public class SearchItemTest extends DriverSetup
{
 WebDriver driver;
	@BeforeTest
	public void launchBrowser() throws NumberFormatException, IOException
	{
		driver=returnBrowser();
	}
  @Test
  public void performAction() throws Exception
  {
	 ExcelUtils eu= new ExcelUtils();
	 eu.openExcel("C:\\Users\\701317\\Documents\\Java Pracise\\Goibibo\\Item_details.xlsx");
	 
	 ItemListPages ilp =new ItemListPages(driver);
	 
	 String s1=eu.getCellValue(0, 0);
	 ilp.getFromPlace(s1);
	 String s2=eu.getCellValue(0, 1);
	 ilp.getFromPlace(s2);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

	 ilp.getDepart();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

	 ilp.getRet();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

	 ilp.getAdult();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

	 ilp.getCurrency();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);



  }
  @AfterTest
  public void closeBrowser()
  {
	  driver.quit();
  }
}
