package com.selenium.DriverSetUp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverSetUp {
	WebDriver driver;
	public String url="http://www.goibibo.com/";
public WebDriver returnBrowser() throws NumberFormatException, IOException
{
	BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter Browser");
	System.out.println("1.Google Chrome");
	System.out.println("2.Firefox");
	int ch=Integer.parseInt(br.readLine());
	switch(ch)
	{
	case 1: System.setProperty("webdriver.chrome.driver", "F:\\\\Selenium\\\\New folder\\\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get(url);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
	break;
	}
	return driver;
}
	

}
