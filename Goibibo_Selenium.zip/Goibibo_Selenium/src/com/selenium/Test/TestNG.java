package com.selenium.Test;

import org.testng.annotations.Test;

import com.google.common.io.Files;
import com.selenium.DriverSetUp.DriverSetUp;
import com.selenium.Pages.ExcelUtils;
import com.selenium.Pages.ItemListPages;
import org.testng.annotations.BeforeTest;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;

public class TestNG extends DriverSetUp {
	WebDriver driver;

	@BeforeTest
	public void LaunchBrowser() throws NumberFormatException, IOException {
		driver=returnBrowser();
	}
	@Test
	public void PerformAction() {
		ExcelUtils eu=new ExcelUtils();
		try {
			eu.openExcel("C:\\Users\\bhumika\\eclipse-workspace\\Goibibo_Selenium\\TestData.xlsx");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ItemListPages ilp=new ItemListPages(driver);
		ilp.getRoundTrip();



		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
		String s1=eu.getCellValue(0, 0);
		ilp.getFrom(s1);
		screenShot();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);

		String s2=eu.getCellValue(0, 1);
		ilp.getDestination(s2);

		screenShot();

	}

	@AfterTest
	public void afterTest() {
		driver.quit();
	}

	public void screenShot()
	{
		try {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			screenshot.getAbsoluteFile();
			File dest = new File("./Screenshots/"+System.currentTimeMillis()+".png");
			Files.copy(screenshot,dest);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
