package com.selenium.Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ItemListPages {
	WebDriver driver;
	
public ItemListPages(WebDriver driver)
{
	this.driver=driver;
}
public By RoundTrip=By.xpath("//*[@id=\"content\"]/div/div[2]/div/div[1]/div[2]/div[1]/div/span[2]");
public By from=By.xpath("//input[@class=\"inputSrch\"]");
public By Destination=By.id("gosuggest_inputDest");
public void getRoundTrip()
{
	WebElement el=driver.findElement(RoundTrip);
	el.click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
}
public void getFrom(String s1)
{
	WebElement el=driver.findElement(from);
	el.click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
	el.sendKeys(s1);
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
	el.sendKeys(Keys.ENTER);
	
}
public void getDestination(String s2)
{
	WebElement el=driver.findElement(Destination);
	el.click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
	el.sendKeys(s2);
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
	el.sendKeys(Keys.ENTER);
	
}
}
