package com.levi.mp.inventory.model.json;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * Model class for CA Product
 * 
 * @author adhar@levi.com
 *
 */
@JsonInclude(Include.NON_NULL)
@JsonPropertyOrder({ "value" })
@JsonIgnoreProperties(ignoreUnknown = true)
public class CAProducts implements Serializable {

	private static final long serialVersionUID = -8816626913002875047L;
	
	@JsonProperty(value="@odata.context")
	private String odataContext;
	
	private List<CAProduct> caProduct=null;
	
	@JsonProperty(value="@odata.nextLink")
	private String odataNextLink;
	
	@JsonProperty(value="value")
	public List<CAProduct> getCaProduct() {
		return caProduct;
	}
	
	@JsonProperty(value="value")
	public void setCaProduct(List<CAProduct> caProduct) {
		this.caProduct = caProduct;
	}
	
	@JsonProperty(value="@odata.context")
	public String getOdataContext() {
		return odataContext;
	}
	
	@JsonProperty(value="@odata.context")
	public void setOdataContext(String odataContext) {
		this.odataContext = odataContext;
	}
	
	@JsonProperty(value="@odata.nextLink")
	public String getOdataNextLink() {
		return odataNextLink;
	}
	
	@JsonProperty(value="@odata.nextLink")
	public void setOdataNextLink(String odataNextLink) {
		this.odataNextLink = odataNextLink;
	};
	

	

}
