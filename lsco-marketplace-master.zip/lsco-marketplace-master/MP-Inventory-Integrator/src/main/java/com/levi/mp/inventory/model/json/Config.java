package com.levi.mp.inventory.model.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Configuration class
 * 
 * @author adhar@levi.com
 *
 */
@Data
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
@JsonPropertyOrder({
	"DYNAMODB_ENDPOINT",
	"DYNAMODB_REGION",
	"DEFAULT_REGION",
	"CA_ENDPOINT_V1",
	"CA_PRODUCT_RESOURCE_PATH",
	"CA_BATCH_RESOURCE_PATH",
	"CA_BATCH_POST_ITEMS_LIMIT",
	"REDSHIFT_JDBC_URL",
	"REDSHIFT_JDBC_USERNAME",
	"REDSHIFT_JDBC_PASSWORD",
	"REDSHIFT_SCHEMA_NAME",
	"DYNAMODB_MKTPLACE_TABLE_NAME"
})
public class Config {
	
	@JsonProperty("DYNAMODB_ENDPOINT")
	private String dynamoDBEndPoint;
	
	@JsonProperty("DYNAMODB_REGION")
	private String dynamoDBRegion;
	
	@JsonProperty("DEFAULT_REGION")
	private String defaultRegionCode;
	
	@JsonProperty("CA_ENDPOINT_V1")
	private String cAEndpointV1;
	
	@JsonProperty("CA_PRODUCT_RESOURCE_PATH")
	private String cAProductResourcePath;
	
	@JsonProperty("CA_BATCH_RESOURCE_PATH")
	private String cABatchResourcePath;
	
	@JsonProperty("CA_BATCH_POST_ITEMS_LIMIT")
	private Integer cABatchPostItemsLimit;
		
	@JsonProperty("RED_SHIFT_JDBC_DRIVER_CLASS_NAME")
	private String redShiftJdbcDriverClassName;
	
	@JsonProperty("REDSHIFT_JDBC_URL")
	private String redShiftJdbcUrl;
	
	@JsonProperty("REDSHIFT_JDBC_USERNAME")
	private String redShiftJdbcUsername;
	
	@JsonProperty("REDSHIFT_JDBC_PASSWORD")
	private String redShiftJdbcPassword;
	
	@JsonProperty("REDSHIFT_SCHEMA_NAME")
	private String redshiftSchemaName;
	
	@JsonProperty("DYNAMODB_MKTPLACE_TABLE_NAME")
	private String dynamoDBMarketPlaceTableName;
	
}
