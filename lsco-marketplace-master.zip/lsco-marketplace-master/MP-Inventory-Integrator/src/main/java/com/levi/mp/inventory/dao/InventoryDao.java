package com.levi.mp.inventory.dao;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.extern.log4j.Log4j2;

@Repository
@Log4j2
public class InventoryDao {

	@Autowired
	SpringJdbcConfigHelper springJdbcConfigHelper;

	/**
	 * Fetches all of inventory data from Redshift. Expect around 40K records to come in response on production.
	 * 
	 * @return A map of pc13 to its respective inventory count.
	 */
	public Map<String, Integer> getInventoryData() {

		// return getDummyDataForLocalTesting();

		final String AVAIL_QTY_COL_NAME = "availableQuantity";

		long redshiftDataAccessStart = Calendar.getInstance().getTimeInMillis();

		String redshiftSchemaName = springJdbcConfigHelper.getInventoryConfig().getConfig().getRedshiftSchemaName();

		List<Map<String, Object>> rowSet = springJdbcConfigHelper.getJdbcTemplate().queryForList("SELECT ITEM.ITEM_NAME as pc13"
				// + ", IA1.ATC_QUANTITY as " + AVAIL_QTY_COL_NAME // , IA1.ATC_QUANTITY as display_qty\n"
				+ ", IA1.DC_GROUP_QUANTITY as " + AVAIL_QTY_COL_NAME + " FROM " + redshiftSchemaName + ".I_AVAILABILITY_3 IA1 INNER JOIN " + redshiftSchemaName
				+ ".ITEM_CBO ITEM ON ITEM.ITEM_ID=IA1.ITEM_ID" + " WHERE IA1.IS_DELETED=0");

		long redshiftDataAccessEnd = Calendar.getInstance().getTimeInMillis();

		Map<String, Integer> pc13ToInventoryCountMap = new HashMap<>();
		for (Map<String, Object> row : rowSet) {
			String availQtyStr = (row.get(AVAIL_QTY_COL_NAME)) == null ? "0.0" : row.get(AVAIL_QTY_COL_NAME).toString();
			Integer availQtyInt = (new Double(availQtyStr)).intValue();
			pc13ToInventoryCountMap.put(row.get("pc13").toString(), availQtyInt);
		}
		log.info("Count of inventory items received: " + pc13ToInventoryCountMap.size());
		log.info("Inventory fetch from RedShift took: " + (redshiftDataAccessEnd - redshiftDataAccessStart) / 1000 + " seconds");
		log.debug("pc13ToInventoryCountMap=" + pc13ToInventoryCountMap);
		return pc13ToInventoryCountMap;
	}

	/*
	 * private Map<String, Integer> getDummyDataForLocalTesting(){
	 * 
	 * Map<String, Integer> pc13ToInventoryCountMap = new HashMap<>();
	 * 
	 * pc13ToInventoryCountMap.put("05527054602930", 25); pc13ToInventoryCountMap.put("0001789500340M", 351);
	 * pc13ToInventoryCountMap.put("0002667700230S", 0); pc13ToInventoryCountMap.put("0002981300140L", 2);
	 * pc13ToInventoryCountMap.put("0003462400010S", 0); pc13ToInventoryCountMap.put("0003579300070M", 21);
	 * 
	 * pc13ToInventoryCountMap.put("0003613700020S", 15); pc13ToInventoryCountMap.put("0006581602390L", 344);
	 * pc13ToInventoryCountMap.put("0006582403390S", 15); pc13ToInventoryCountMap.put("002667700310XL", 0);
	 * pc13ToInventoryCountMap.put("00349630006024", 0); pc13ToInventoryCountMap.put("00349640004024", 0);
	 * pc13ToInventoryCountMap.put("00501019303232", 0);
	 * 
	 * 
	 * pc13ToInventoryCountMap.put("00501019304232", 23); pc13ToInventoryCountMap.put("00501066003836", 122);
	 * pc13ToInventoryCountMap.put("00501196303430", 118); pc13ToInventoryCountMap.put("00501225602930", 0);
	 * pc13ToInventoryCountMap.put("00501230203430", 0); pc13ToInventoryCountMap.put("00501245503434", 263);
	 * pc13ToInventoryCountMap.put("00501248202932", 118);
	 * 
	 * 
	 * return pc13ToInventoryCountMap;
	 * 
	 * 
	 * }
	 */

}
