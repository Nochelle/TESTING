package com.levi.mp.inventory.model.db;

import java.io.Serializable;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * Dynamo DB MP_PRODUCTS model class
 *
 */
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@DynamoDBTable(tableName = "TABLE NAME WOULD BE REPLACED VIA DynamoDBMapperConfig.TableNameOverride")
public class Product implements Serializable {

	@DynamoDBIgnore
	private static final long serialVersionUID = 1277695837362904674L;

	@DynamoDBHashKey(attributeName = "pc_13")
	private String pc_13;

	@DynamoDBRangeKey(attributeName = "region_code")
	private String region_code;

	@DynamoDBAttribute(attributeName = "ca_id")
	private String ca_id;
}
