package com.levi.mp.inventory.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.levi.mp.shared.ca.util.MPSharedUtil;

/**
 * Configuration class for RestClient
 * 
 * @author adhar@levi.com
 *
 */
@Configuration
public class RestConfig {
	
	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@Bean
	MPSharedUtil mpSharedUtil() {
		return new MPSharedUtil();
	}

}
