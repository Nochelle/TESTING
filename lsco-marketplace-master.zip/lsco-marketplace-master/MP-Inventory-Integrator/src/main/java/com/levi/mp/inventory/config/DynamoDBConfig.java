package com.levi.mp.inventory.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig.TableNameOverride;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;

import lombok.Data;

/**
 * 
 * This Class will provide the configuration for DynamoDB operations
 * 
 * @author adhar@levi.com
 *
 */
@Component
@Data
public class DynamoDBConfig {

	//@Value(value = "${dynamodb.endpoint}")
	private String dynamoDBEndPoint;

	//@Value(value = "${dynamodb.region}")
	private String dynamoDBRegion;
	
	@Autowired
	InventoryIntegratorConfiguration inventoryConfig;
	
	private DynamoDBMapper dynamoDBMapper;
	
	private AmazonDynamoDB amazonDynamoDB;
	
	private DynamoDB dynamoDB;
	
	@PostConstruct
	public void init() {
		
		dynamoDBEndPoint = inventoryConfig.getConfig().getDynamoDBEndPoint();
		dynamoDBRegion = inventoryConfig.getConfig().getDynamoDBRegion();
		
		amazonDynamoDB = AmazonDynamoDBClientBuilder.standard()
				.withEndpointConfiguration(
						new AwsClientBuilder.EndpointConfiguration(dynamoDBEndPoint, dynamoDBRegion))
				.build();
		
		DynamoDBMapperConfig dynamoDBMapperConfig = DynamoDBMapperConfig.builder().withTableNameOverride(TableNameOverride
				.withTableNameReplacement(inventoryConfig.getConfig().getDynamoDBMarketPlaceTableName()))
				.build();
		
		dynamoDBMapper = new DynamoDBMapper(amazonDynamoDB, dynamoDBMapperConfig);
		
		dynamoDB = new DynamoDB(amazonDynamoDB);
		
		
	}
	
	
	

	/*@Bean
	AmazonDynamoDB amazonDynamoDB() {
		return AmazonDynamoDBClientBuilder.standard()
				.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(dynamoDBEndPoint, dynamoDBRegion))
				.build();
	}

	@Bean
	DynamoDBMapper dynamoDBMapper() {
		return new DynamoDBMapper(amazonDynamoDB());
	}*/
}
