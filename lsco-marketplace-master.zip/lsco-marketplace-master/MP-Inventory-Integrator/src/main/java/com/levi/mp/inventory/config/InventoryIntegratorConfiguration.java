package com.levi.mp.inventory.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.inventory.model.json.Config;
import com.levi.mp.shared.ca.util.MPSharedUtil;

import lombok.extern.log4j.Log4j2;

/**
 * This class contains the necessary configuration properties for MP-Inventory-Integrator application. The
 * property Config is set from inventory/inventory_integrator_config.json in S3 bucket levi-marketplaces
 * 
 * @author adhar@levi.com
 *
 */
@Component
@Log4j2
public class InventoryIntegratorConfiguration {

	private Config config;

	@Autowired
	MPSharedUtil mpSharedUtil;

	@PostConstruct
	public void init() {

		String jsonString;
		String key = System.getenv("env_config");//"inventory/inventory_integrator_config_dev.json";
		try {
			jsonString = mpSharedUtil.getConfigValues(key);

			ObjectMapper objectMapper = new ObjectMapper();
			config = objectMapper.readValue(jsonString, Config.class);
			
			log.debug("Successfully loaded Inventory Integrator Configuration properties.");
			//Commenting to remove logging which contains sensitive information
			//log.debug(">>>>>>>>>Loaded Inventory Integrator Configuration properties:  " + config);

		} catch (Exception e) {
			log.error("Exception occurred while loading configuration properties for Inventory Integrator: " + key + " from S3", e);
			throw new RuntimeException(e);
		}
	}

	public Config getConfig() {
		return config;
	}

}
