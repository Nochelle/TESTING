package com.levi.mp.inventory.service;

/**
 * ServiceType ENUM defining allowable operations
 * 
 * @author adhar@levi.com
 *
 */
public enum ServiceType {

	PRODUCT_IMPORT("product_import"), INVENTORY_UPDATE("inventory_update");
	
	private String type;
	
	private ServiceType(String type) {
		this.type = type;	
	}
	
	public String getServiceType() {
		return this.type;
	}
	
}
