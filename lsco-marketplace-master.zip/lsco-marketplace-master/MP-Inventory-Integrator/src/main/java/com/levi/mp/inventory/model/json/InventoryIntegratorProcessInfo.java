package com.levi.mp.inventory.model.json;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter 
@Setter 
@RequiredArgsConstructor
@EqualsAndHashCode
@AllArgsConstructor
@Builder
public class InventoryIntegratorProcessInfo {

	private Integer totProductsFetchedFromDynamoDB;

	private Integer actualProductsAttempetedToUpdateInCA;

	private Integer productsUpdatedSuccessfullyInCA;

	private Integer productsNotUpdatedInCA;

	private Integer productsmportedFromCA;

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InventoryIntegratorProcessInfo ["
				+(totProductsFetchedFromDynamoDB != null ? "totProductsFetchedFromDynamoDB=" + totProductsFetchedFromDynamoDB :"")
				+(actualProductsAttempetedToUpdateInCA!=null ? ", actualProductsAttempetedToUpdateInCA=" + actualProductsAttempetedToUpdateInCA: "")
				+(productsUpdatedSuccessfullyInCA!=null? ", productsUpdatedSuccessfullyInCA=" + productsUpdatedSuccessfullyInCA : "")
				+(productsNotUpdatedInCA!=null ? ", productsNotUpdatedInCA=" + productsNotUpdatedInCA : "")
				+(productsmportedFromCA!=null ? ", productsmportedFromCA=" + productsmportedFromCA : "") 
				+"]";
	}
	
	

}
