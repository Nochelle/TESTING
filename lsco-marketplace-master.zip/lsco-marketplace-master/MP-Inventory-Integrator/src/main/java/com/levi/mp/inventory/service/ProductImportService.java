package com.levi.mp.inventory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.dao.DynamoDBInventoryAdapter;
import com.levi.mp.inventory.helper.InventoryHelperUtils;
import com.levi.mp.inventory.model.db.Product;
import com.levi.mp.inventory.model.json.CAProducts;
import com.levi.mp.inventory.model.json.InventoryIntegratorProcessInfo;
import com.levi.mp.inventory.rest.client.InventoryRestClientAdapter;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;

import lombok.extern.log4j.Log4j2;

/**
 * Product import service functionality
 * 
 * @author adhar@levi.com
 *
 */
@Log4j2
@Service
public class ProductImportService {

	@Autowired
	InventoryIntegratorConfiguration inventoryConfig;

	@Autowired
	InventoryRestClientAdapter inventoryRestClientAdapter;

	@Autowired
	ChannelAdvisorTokenService channelAdvisorTokenService;

	@Autowired
	DynamoDBInventoryAdapter dynamoDBInventoryAdapter;
	
	InventoryIntegratorProcessInfo inventoryIntegratorProcessInfo;

	private String accessToken = "";

	public void handleServiceRequest() {
		
		log.trace("Starting lambda handler function for product import...");
		
		//delete records from DynamoDB MP_PRODUCTS table before importing the products.
		//dynamoDBInventoryAdapter.deleteAllProducts();
		
		dynamoDBInventoryAdapter.deleteTable(inventoryConfig.getConfig().getDynamoDBMarketPlaceTableName());
		dynamoDBInventoryAdapter.createTable(inventoryConfig.getConfig().getDynamoDBMarketPlaceTableName());

		CAProducts caProducts = null;

		// Get the access token and keep a reference
		accessToken = channelAdvisorTokenService.getOAuth2Token();

		// CA fetches 100 records at a time.
		// We need to check odata.nextlink attribute for the next records
		caProducts = inventoryRestClientAdapter.getProductsFromCA(accessToken);
		if (caProducts == null || caProducts.getCaProduct() == null || caProducts.getCaProduct().isEmpty()) {
			// log.error("No products fetched from CA.");
			throw new RuntimeException("No products fetched from CA.");
		}

		int productCounter = caProducts.getCaProduct().size();
		log.info("Fetched " + productCounter + " initial Products from CA");
		log.debug("The initial products fetched from CA are: " + caProducts.getCaProduct());
		
		List<Product> productList = InventoryHelperUtils.getProductsListFromCAProducts(caProducts, inventoryConfig.getConfig());
		dynamoDBInventoryAdapter.saveProducts(productList);

		while (!StringUtils.isEmpty(caProducts.getOdataNextLink())) {
			log.debug("Invoking CA API for getting next set of products with url: " + caProducts.getOdataNextLink());
			caProducts = inventoryRestClientAdapter.getNextProductsFromCA(accessToken, caProducts.getOdataNextLink());
			if (caProducts == null || caProducts.getCaProduct() == null || caProducts.getCaProduct().isEmpty()) {
				// log.error("No products fetched from CA.");
				throw new RuntimeException("No products fetched from CA.");
			}

			productCounter += caProducts.getCaProduct().size();
			log.info("Fetched " + caProducts.getCaProduct().size() + " next set of products from CA");
			log.debug("The next set of  products fetched from CA are: " + caProducts.getCaProduct());
			log.info("Total number of records fetched so far : " + productCounter);

			productList.clear();
			productList = InventoryHelperUtils.getProductsListFromCAProducts(caProducts, inventoryConfig.getConfig());
			dynamoDBInventoryAdapter.saveProducts(productList);
			log.info("Total number of records saved so far : " + productCounter);
		}

		log.info("Successfully fetched and saved : " + productCounter + " products to Dynamo DB");
		
		//Store track of process related information
		inventoryIntegratorProcessInfo = InventoryIntegratorProcessInfo.builder().productsmportedFromCA(productCounter).build();
		
		//log.info(">>>>>>>>>>>>>"+inventoryIntegratorProcessInfo);
		
		log.trace("lambda handler function for product import completed sucessfully!");

		/*
		 * log.info("Breaking down the product list from CA into batches of " +
		 * inventoryConfig.getConfig().getCABatchPostItemsLimit() + " items each.");
		 * 
		 * Collection<List<Product>> productsToSaveBatches = InventoryHelperUtils.partition(producList,
		 * inventoryConfig.getConfig().getCABatchPostItemsLimit());
		 * 
		 * log.info("Broke down the product list from CA into: " + productsToSaveBatches.size() + " partition(s)");
		 * 
		 * for (List<Product> productbatch : productsToSaveBatches) { int batchCounter = 1;
		 * log.info("Starting save products to dynamo for batch:  " + batchCounter);
		 * 
		 * boolean saveStatus = dynamoDBInventoryAdapter.saveProducts(productbatch);
		 * 
		 * if (!saveStatus) { log.error("Error while saving products in DB"); throw new
		 * RuntimeException("Error while saving products in DB"); }
		 * 
		 * log.info("Successfully saved products for batch: " + batchCounter);
		 * 
		 * batchCounter++; }
		 */

		/*
		 * // Sleep for 2 seconds, so that data is reflected in DynamoDB try {
		 * log.debug("Going to sleep for 2 seconds..."); Thread.sleep(2000); } catch (InterruptedException e) {
		 * 
		 * }
		 * 
		 * // Fetch only those products which have been saved to DB. List<Product> productsFetchedFromDB =
		 * dynamoDBInventoryAdapter.fetchProducts(producList);
		 * 
		 * if (productsFetchedFromDB == null || productsFetchedFromDB.isEmpty()) {
		 * log.error("No products fetched from DB"); throw new RuntimeException("No products fetched from DB"); } //
		 * Creating List<InventoryRequestModel> from products fetched from DB List<InventoryRequestModel>
		 * inventoryRequestModelList = InventoryHelperUtils
		 * .getInventoryRequestModelFromProducts(productsFetchedFromDB, inventoryConfig.getConfig());
		 * 
		 * // Create Json File from File jsonFile =
		 * InventoryHelperUtils.createJSONFileFromPojo(inventoryRequestModelList);
		 * 
		 * if (jsonFile == null) { throw new RuntimeException("Could not generate request.json file"); }
		 * log.info("Starting upload of file " + jsonFile.getAbsolutePath() + " to S3...");
		 * 
		 * boolean fileUploadStatus = S3Adapter.uploadFile(InventoryConstants.MARKETPLACE_S3_BUCKET,
		 * inventoryConfig.getConfig().getS3Folder() + "/" +
		 * inventoryConfig.getConfig().getMpInventoryRequestFileName() +
		 * inventoryConfig.getConfig().getMpInventoryRequestFileExtension(), jsonFile);
		 * 
		 * if (!fileUploadStatus) { throw new RuntimeException("Unable to upload file to S3"); }
		 */

	}

	public InventoryIntegratorProcessInfo getInventoryIntegratorProcessInfo() {
		return inventoryIntegratorProcessInfo;
	}

}
