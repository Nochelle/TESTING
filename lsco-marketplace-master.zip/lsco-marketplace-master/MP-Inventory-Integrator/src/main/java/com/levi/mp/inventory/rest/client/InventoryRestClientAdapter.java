package com.levi.mp.inventory.rest.client;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.helper.InventoryHelperUtils;
import com.levi.mp.inventory.model.json.CAProducts;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

/**
 * Rest Client
 * 
 * @author adhar@levi.com
 *
 */
@Log4j2
@Service
public class InventoryRestClientAdapter {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	InventoryIntegratorConfiguration inventoryConfig;
	
	@Autowired
	SNSService snsService;
	
	String errorMessage;
	String subject;

	/**
	 * Fetch SKU and ID from CA
	 * 
	 * @return {@code CAProducts } the products returned from CA
	 */
	public CAProducts getProductsFromCA(String accessToken) {

		try {
			HttpHeaders requestHeaders = new HttpHeaders();
			requestHeaders.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(requestHeaders);

			// https://api.channeladvisor.com/v1/Products?access_token=xxxxxxxxxxx&$filter=Labels/Any (c:c/Name eq
			// 'Listed')&$select=TotalAvailableQuantity,ID,SKU
			UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder //
					.fromHttpUrl(inventoryConfig.getConfig().getCAEndpointV1() + "/" + inventoryConfig.getConfig().getCAProductResourcePath()) //
					.queryParam("access_token", accessToken) //
					.queryParam("$filter", "Labels/Any (c:c/Name eq 'Listed')") //
					.queryParam("$select", "Sku,ID");

//			UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder
//					.fromHttpUrl(inventoryConfig.getConfig().getCAEndpointV1() + "/" + inventoryConfig.getConfig().getCAProductResourcePath())
//					.queryParam("access_token", accessToken).queryParam("$select", "Sku,ID");

			log.info("Invoking CA API for getProducts: " + uriComponentsBuilder.build().toString());

			ResponseEntity<String> responseEntity = restTemplate.exchange(uriComponentsBuilder.build().toString(), HttpMethod.GET, requestEntity, String.class);

			HttpStatus responseStatus = responseEntity.getStatusCode();
			String responseBody = responseEntity.getBody();
			log.info("CA API getProducts Response status: " + responseStatus.value());
			log.debug("CA API getProducts response content:" + responseBody);

			if (!responseStatus.equals(HttpStatus.OK)) {
				log.error("Unsuccessful response from CA API getproducts");
				throw new RuntimeException("Unsuccessful response from CA API getproducts");
			}

			CAProducts caProducts = new ObjectMapper().readValue(responseBody, CAProducts.class);
			// log.info("CA API getProducts response content:" + caProducts);
			return caProducts;

		} catch (Exception e) {
			log.error("Exception while fetching products from CA", e);
			throw new RuntimeException("Exception while fetching products from CA", e);
		}

	}

	/**
	 * Fetch SKU and ID from CA with pre-configured url returned from initial response from CA
	 * 
	 * @return {@code CAProducts } the products returned from CA
	 */
	public CAProducts getNextProductsFromCA(String accessToken, String url) {
		try {
			HttpHeaders requestHeaders = new HttpHeaders();
			requestHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(requestHeaders);
			UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(URLDecoder.decode(url, "UTF-8"));

			log.info("Invoking CA API for getProducts: " + uriComponentsBuilder.build().toString());

			ResponseEntity<String> responseEntity = restTemplate.exchange(uriComponentsBuilder.build().toString(), HttpMethod.GET, requestEntity, String.class);
			HttpStatus responseStatus = responseEntity.getStatusCode();
			String responseBody = responseEntity.getBody();
			log.info("CA API getProducts Response status: " + responseStatus.value());
			log.debug("CA API getProducts response content:" + responseBody);

			if (!responseStatus.equals(HttpStatus.OK)) {
				// log.error("Unsuccessful response from CA API getproducts");
				throw new RuntimeException("Unsuccessful response from CA API getproducts");
			}

			CAProducts caProducts = new ObjectMapper().readValue(responseBody, CAProducts.class);
			// log.debug("CA API getProducts response content:" + caProducts);
			return caProducts;
		} catch (Exception e) {
			// log.error("Exception while fetching products from CA", e);
			throw new RuntimeException("Exception while fetching products from CA", e);
		}
	}

	/**
	 * Method to update products in CA
	 * 
	 * @param dataList
	 * @param accessToken
	 * @return responseMap containing successful and unsuccessful pc_13s posted to CA
	 */
	public Map<String, List<String>> updateProductsInCA(List<Map<String, String>> dataList, String accessToken) {

		// Map to store the successful and unsuccessful pc_13s posted to CA
		Map<String, List<String>> responseMap = new HashMap<>();
		String requestBody = "";
		try {
			requestBody = InventoryHelperUtils.constructCABatchPostRequestBody(dataList, inventoryConfig.getConfig());

			HttpHeaders requestHeaders = new HttpHeaders();
			requestHeaders.set("Content-Type", "multipart/mixed; boundary=changeset");

			HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, requestHeaders);

			UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder
					.fromHttpUrl(inventoryConfig.getConfig().getCAEndpointV1() + "/" + inventoryConfig.getConfig().getCABatchResourcePath())
					.queryParam("access_token", accessToken);

			String url = uriComponentsBuilder.build().toString();

			log.info("Invoking API for updateProductsInCA: " + url);

			long batchUpdateCAStart = Calendar.getInstance().getTimeInMillis();

			ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);

			long batchUpdateCAEnd = Calendar.getInstance().getTimeInMillis();
			log.info("batch update in CA for batch size: " + dataList.size() + " took: " + (batchUpdateCAEnd - batchUpdateCAStart) / 1000 + " seconds");

			HttpStatus responseStatus = responseEntity.getStatusCode();
			String responseBody = responseEntity.getBody();
			log.info("updateProductsInCA Response status:" + responseStatus.value());
			// log.info("updateProductsInCA Response content:" + responseBody);

			// This is batch status code. This differs from the individual responses for the
			// requests in the batch.
			if (responseStatus.equals(HttpStatus.OK)) {

				log.debug("Filtering out only the HTTP Status code lines from org.springframework.http.MediaType response content");
				List<String> httpStatusCodeLine = Stream.of(responseBody.split("[\\r\\n]+")).filter(s -> s.startsWith("HTTP")).collect(Collectors.toList());

				List<String> successful_pc13s = new ArrayList<>();
				List<String> unsuccessful_pc13s = new ArrayList<>();

				log.debug("Scanning response for successul and unsuccessful post to CA...");
				int counter = 0;

				for (String statusCodeLine : httpStatusCodeLine) {

					String pc_13 = dataList.get(counter).get("pc_13");

					log.debug("pc_13: " + pc_13 + "was posted to CA with status code: " + statusCodeLine);
					// Match successful HTTP Statuses
					if (statusCodeLine.matches(".*(20\\d{1}).*")) {
						successful_pc13s.add(pc_13);
					} else {
						log.error("Error occurred while posting data to CA for product having pc_13: " + pc_13);
						log.error("Response status code: " + statusCodeLine);
						unsuccessful_pc13s.add(pc_13);
					}

					counter++;
				}

				responseMap.put("success", successful_pc13s);
				responseMap.put("fail", unsuccessful_pc13s);

			} else {
				log.error("updateProductsInCA Response status code is not successful");
				responseMap.put("fail", dataList.stream().map(x -> x.get("pc_13")).collect(Collectors.toList()));
			}

		} catch (Exception e) {
			// log.error("Exception while updating products in CA ", e);
			responseMap.put("fail", dataList.stream().map(x -> x.get("pc_13")).collect(Collectors.toList()));

			// Notify Support
			errorMessage = "Exception while updating products in CA" + System.lineSeparator() + "Request Body: "
					+ System.lineSeparator() + requestBody + System.lineSeparator() + "Error message: "
					+ System.lineSeparator() + ExceptionUtils.getStackTrace(e);

			log.error(errorMessage);
			subject = "[MP-Inventory]:Exception while updating products in CA";
			snsService.notifySupport(errorMessage, subject);
		}
		return responseMap;

	}

}
