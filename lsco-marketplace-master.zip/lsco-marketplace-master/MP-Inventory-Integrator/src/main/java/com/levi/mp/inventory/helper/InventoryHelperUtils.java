package com.levi.mp.inventory.helper;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.model.db.Product;
import com.levi.mp.inventory.model.json.CAProduct;
import com.levi.mp.inventory.model.json.CAProducts;
import com.levi.mp.inventory.model.json.Config;

import lombok.extern.log4j.Log4j2;

/**
 * Utility class
 * 
 * @author adhar@levi.com
 *
 */
@Log4j2
@Component
public class InventoryHelperUtils {
	
	@Autowired
	InventoryIntegratorConfiguration inventoryIntegratorConfiguration;
	
	/**
	 * Method to get the String content of a file
	 * 
	 * @param absoulteFileName
	 * @return the String content of the file
	 */
	public static String readFile(String absoulteFileName) {

		try (Stream<String> stream = Files.lines(Paths.get(absoulteFileName))) {
			StringBuffer fileContent = new StringBuffer();
			stream.forEach(str -> fileContent.append(str));

			return fileContent.toString();
		} catch (IOException e) {
			log.error("Exception while reading file " + absoulteFileName + " ", e);
		}

		return "";

	}

	/**
	 * Method to get List from Json data
	 * 
	 * @param jsonData
	 * @return {@code List<Map<String,String>>} list representation of json data
	 * 
	 */
	public static List<Map<String, String>> getListFromJson(String jsonData) {

		try {
			ObjectMapper mapper = new ObjectMapper();
			List<Map<String, String>> data = mapper.readValue(jsonData, new TypeReference<List<Map<String, String>>>() {
			});
			log.info("Json Data from file converted to List<Map<String, String>..." + data);
			return data;
		} catch (Exception e) {
			log.error("Exception occurred while converting json: " + jsonData + " to list ", e);

		}
		return null;

	}

	/**
	 * Method to get Map from Json data
	 * 
	 * @param jsonData
	 * @return {@code Map<String, String>>} map representation of json data
	 *
	 */
	public static Map<String, String> getMapFromJson(String jsonData) {

		try {
			ObjectMapper mapper = new ObjectMapper();
			Map<String, String> data = mapper.readValue(jsonData, new TypeReference<Map<String, String>>() {
			});
			log.info("Json Data from file converted to List<Map<String, String>..." + data);
			return data;
		} catch (Exception e) {
			log.error("Exception occurred while converting json: " + jsonData + " to map", e);
		}
		return null;

	}

	/**
	 * Method to get Map from InputStream
	 * 
	 * @param inputStream
	 * @return the map representation of json
	 */
	public static Map<String, String> getMapFromJson(InputStream inputStream) {

		try {
			ObjectMapper mapper = new ObjectMapper();
			Map<String, String> data = mapper.readValue(inputStream, new TypeReference<Map<String, String>>() {
			});
			log.debug("Json Data from file converted to List<Map<String, String>..." + data);
			return data;
		} catch (Exception e) {
			log.error("Exception occurred while converting inputStream: to map", e);
		}
		return null;

	}

	/**
	 * Method to construct the CA Batch POST request body as per CA requirements
	 * 
	 * @param dataList
	 * @return the post request body for CA batch POST operation
	 */
	public static String constructCABatchPostRequestBody(List<Map<String, String>> dataList, Config config) {

		log.info("Constructing CA Batch POST request body...");

		StringBuffer requestBody = new StringBuffer();

		requestBody.append("--batch").append(System.lineSeparator()).append("Content-Type: multipart/mixed; boundary=changeset")
				.append(System.lineSeparator());
		
		int contentIdCounter = 0;
		
		for (Map<String, String> dataMap : dataList) {
			
			contentIdCounter++;
			String productId = dataMap.get("id");
			String quantity = dataMap.get("display_qty");
			String pc_13 = dataMap.get("pc_13");

			log.debug("Creating update content for product having pc_13: " + pc_13 + " and ca_id: " + productId + " ...");

			

			// DistributionCenterID hard Coded as 0 until we figure out what the value
			// should be

			requestBody.append("--changeset").append(System.lineSeparator()).append("Content-Type: application/http").append(System.lineSeparator())
					.append("Content-Transfer-Encoding: binary").append(System.lineSeparator()).append("Content-ID: " + contentIdCounter)
					.append(System.lineSeparator()).append(System.lineSeparator())
					.append("POST " + config.getCAEndpointV1() + "/" + config.getCAProductResourcePath() + "(" + productId + ")"
							+ "/UpdateQuantity HTTP/1.1")
					.append(System.lineSeparator()).append("Content-Type: application/json").append(System.lineSeparator())
					.append(System.lineSeparator()).append("{\"Value\":{\"UpdateType\":\"Absolute\",\"Updates\":[{\"DistributionCenterID\":" + 0
							+ ",\"Quantity\":" + quantity + "}]}}")
					.append(System.lineSeparator());

			
		}

		requestBody.append("--changeset--").append(System.lineSeparator()).append("--batch--");

		String requestBodyAsString = requestBody.toString();
		log.debug("Created CA Batch Post request Body: " + System.lineSeparator() + requestBodyAsString);

		return requestBodyAsString;
	}

	/**
	 * Method to partition a list based on size parameter
	 *
	 * @param list
	 * @param size
	 * @return {@code Collection<List<T>>}
	 */
	public static <T> Collection<List<T>> partition(List<T> list, int size) {
		final AtomicInteger counter = new AtomicInteger(0);

		return list.stream().collect(Collectors.groupingBy(it -> counter.getAndIncrement() / size)).values();
	}

	/**
	 * Method to get {@code List<Product>} from {@code CAProducts}
	 * 
	 * @param caProducts
	 * @return {@code List<Product>} the products (DB Model)
	 */
	public static List<Product> getProductsListFromCAProducts(CAProducts caProducts, Config config) {
		log.debug("Creating Product db model objects for persisting...");

		List<Product> producList = new ArrayList<>();
		for (CAProduct caProduct : caProducts.getCaProduct()) {

			// Invalid record skip
			if (caProduct.getSku() == null || caProduct.getSku().isEmpty())
				continue;

			Product product = Product.builder().pc_13(caProduct.getSku()).ca_id(caProduct.getProductId()).region_code(config.getDefaultRegionCode())
					.build();
			producList.add(product);

		}
		log.debug("Created Product db model objects: " + producList);
		return producList;

	}

	/**
	 * Method to construct Levi Inventory Bulk API request body
	 * 
	 * @param s3Bucket
	 * @param s3Prefix
	 * @return requestBody
	 */
	public static String constructLeviInventoryBulkRequestBody(String s3Bucket, String s3Prefix) {

		String requestBody = "{\"s3_bucket\":\"" + s3Bucket + "\",\"s3_prefix\":\"" + s3Prefix + "\"}";

		log.info("Levi Inventory Bulk request body: " + requestBody);
		return requestBody;

	}

	/**
	 * method to get inventory integrator configuration json as a POJO
	 * 
	 * @param key
	 * @return config
	 *//*
		 * public static Config getInventoryConfigurationProperties(String key) {
		 * 
		 * String jsonString; try { jsonString = new MPSharedUtil().getConfigValues(key);
		 * 
		 * ObjectMapper objectMapper = new ObjectMapper(); Config config = objectMapper.readValue(jsonString,
		 * Config.class); return config; } catch (Exception e) {
		 * log.error("Exception occurred while getting configuration file:"+key+ " from S3"); } return null; }
		 */
	
}
