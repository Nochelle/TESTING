package com.levi.mp.inventory.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.DeleteTableRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ResourceNotFoundException;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.amazonaws.services.dynamodbv2.util.TableUtils;
import com.levi.mp.inventory.config.DynamoDBConfig;
import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.helper.InventoryConstants;
import com.levi.mp.inventory.model.db.Product;

import lombok.extern.log4j.Log4j2;

/**
 * 
 * DynamoDBAdapter class for performing DynamoDB operations
 *
 */
@Log4j2
@Repository
public class DynamoDBInventoryAdapter {

	/*@Autowired
	private DynamoDBMapper dynamoDBMapper;
	
	@Autowired
	InventoryIntegratorConfiguration inventoryConfig;*/
	

	@Autowired
	DynamoDBConfig dynamoDBConfig;
	
	@Autowired
	InventoryIntegratorConfiguration inventoryConfig;

	
	/**
	 * Method to save products in DB in batch
	 * 
	 * @param products
	 * @return the status of save(true or false)
	 */
	public void saveProducts(List<Product> products) {
		log.info("Saving ChannelAdvisor products in " + inventoryConfig.getConfig().getDynamoDBMarketPlaceTableName() + " table....");
		try {
			long batchSaveStart = Calendar.getInstance().getTimeInMillis();
			List<FailedBatch> failedBatches = dynamoDBConfig.getDynamoDBMapper().batchSave(products);
			long batchSaveEnd = Calendar.getInstance().getTimeInMillis();
			
			log.info("batchSave of products in DynamoDB for batchSize: " + products.size() + " took: "
					+ (batchSaveEnd - batchSaveStart) / 1000 + " seconds.");
			
			for (FailedBatch failedBatch : failedBatches) {
				log.error(failedBatch.hashCode() + " Batch failed due to: ", failedBatch.getException());
				log.error(failedBatch.hashCode() + " Batch - Unprocessed items: " + failedBatch.getUnprocessedItems());
			}
			if (failedBatches == null || failedBatches.isEmpty()) {
				log.info("Saved " + products.size() + " SKUs records");
				return;
			} else
				throw new RuntimeException(
						"Error occured in performing DynamoDB batchSave operation for storing PC13s obtained from ChannelAdvisor. Failed batch size: "
								+ failedBatches.size());
		} catch (Exception e) {
			// log.error("Exception occurred while saving products to inventory in DynamoDB", e);
			throw new RuntimeException("Exception occurred while saving products to inventory in DynamoDB", e);
		}
	}

	/**
	 * Method to fetch products from DB in batch
	 * 
	 * @param products
	 * @return {@code List<Product>}
	 */
	public List<Product> fetchProducts(List<Product> products) {
		
		String tableName = inventoryConfig.getConfig().getDynamoDBMarketPlaceTableName();
		
		log.info("Fetching products from " + tableName + " table...");
		try {
			Map<String, List<Object>> results = dynamoDBConfig.getDynamoDBMapper().batchLoad(products);
			log.debug("Fetched results from DB: " + results);

			List<Product> productsFromDB = new ArrayList<>();
			// Retrieve the products from the result
			if (results != null && results.get(tableName) != null) {
				productsFromDB = results.get(tableName).stream().filter(a -> a instanceof Product).map(a -> (Product) a)
						.collect(Collectors.toList());

				log.info("Fetched products from " +tableName+ " table: " + productsFromDB);
			}

			return productsFromDB;
		} catch (Exception e) {
			// log.error("Exception occurred while fetching products from inventory DB ", e);
			throw new RuntimeException("Exception occurred while fetching products from DynamoDB", e);
		}
	}

	/**
	 * Fetch product by pc13
	 * 
	 * @param pc13
	 * @return the product id
	 */
	/*public String fetchProductIdByPc13(String pc13) {

		// TODO: This method should not be used. Fetching one product at a time could make result in too many calls to
		// DynamoDB. It does not look it is being referenced anywhere at the moment. Once confirmed by Arijit, this
		// method should be commented/deleted.
		
		Map<String, AttributeValue> expressionAttributeValues = new HashMap<String, AttributeValue>();
		expressionAttributeValues.put(":val1", (new AttributeValue()).withS(pc13));

		DynamoDBQueryExpression<Product> queryExpression = new DynamoDBQueryExpression<Product>().withKeyConditionExpression("pc_13 = :val1")
				.withProjectionExpression("ca_id").withExpressionAttributeValues(expressionAttributeValues);

		log.debug("Fetching product id from " + InventoryConstants.MARKETPLACE_DB_TABLENAME + " table for pc13: " + pc13);

		List<Product> productsFromDB = dynamoDBMapper.query(Product.class, queryExpression);

		if (productsFromDB != null && !productsFromDB.isEmpty() && productsFromDB.size() == 1) {
			String ca_id = productsFromDB.get(0).getCa_id();
			log.debug("Fetched product id : " + ca_id);
			return ca_id;

		} else {
			log.error("Not correct product data from DB for pc_13 " + pc13);
			log.error("Continuing to next product.");
		}

		return "";

	}*/

	/**
	 * Method to scan the products table
	 * 
	 * @return {@code List<Product>}
	 */
	public List<Product> scanProductsTable() {

		log.trace("Scanning "+ inventoryConfig.getConfig().getDynamoDBMarketPlaceTableName()+" table...");
		try {
			
			long scanStart = Calendar.getInstance().getTimeInMillis();
			
			// DynamoDBScanExpression scanExpression = new DynamoDBScanExpression().withLimit(100);
			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();

			List<Product> productList = dynamoDBConfig.getDynamoDBMapper().scan(Product.class, scanExpression);
			
			long scanEnd = Calendar.getInstance().getTimeInMillis();
			
			/*
			 * List<Product> productList = new ArrayList<>();
			 * 
			 * ScanResultPage<Product> scanPage = dynamoDBMapper.scanPage(Product.class, scanExpression);
			 * productList.addAll(scanPage.getResults()); while(scanPage.getLastEvaluatedKey()!=null) {
			 * scanExpression.setExclusiveStartKey(scanPage.getLastEvaluatedKey()); scanPage =
			 * dynamoDBMapper.scanPage(Product.class, scanExpression); productList.addAll(scanPage.getResults()); }
			 */

			log.info("Fetched " + productList.size() + " products from DB");
			log.info("Scan of products table in DynamoDB took: "+ (scanEnd - scanStart) / 1000 + " seconds.");
			return productList;
		} catch (Exception e) {
			// log.error("Exception occurred while scanning DnamoDB products table");
			throw new RuntimeException("Exception occcurred while scanning DynamoDB products table before fetching inventory", e);
		}
	}
	
	
	/**
	 * Delete all records from DynamoDB Products table.
	 *
	 */
	public void deleteAllProducts() {

		// Delete all records from DynamoDB table
		//We do a scan and then batchDelete on DynamoDBMapper object
		
		log.trace("Starting to delete all records from DynamoDB table...");
		try {
			
			long batchDeleteStart = Calendar.getInstance().getTimeInMillis();
			// DynamoDBScanExpression scanExpression = new
			// DynamoDBScanExpression().withLimit(100);
			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();

			List<Product> productList = dynamoDBConfig.getDynamoDBMapper().scan(Product.class, scanExpression);

			List<FailedBatch> failedBatches = dynamoDBConfig.getDynamoDBMapper().batchDelete(productList);
			long batchDeleteEnd = Calendar.getInstance().getTimeInMillis();
			
			for (FailedBatch failedBatch : failedBatches) {
				log.error(failedBatch.hashCode() + " Batch failed due to: ", failedBatch.getException());
				log.error(failedBatch.hashCode() + " Batch - Unprocessed items: " + failedBatch.getUnprocessedItems());
			}
			
			if (failedBatches == null || failedBatches.isEmpty()) {
				log.info("Deleted " + productList.size() + " SKUs records");
				log.info("batch delete in DynamoDB for batchSize: " + productList.size() + " took: "
						+ (batchDeleteEnd - batchDeleteStart) / 1000 + " seconds.");
			} else {
				throw new RuntimeException("Error occured in performing DynamoDB batchDelete operation "
						+ "for deleting products. Failed batch size: " + failedBatches.size());

			}
		} catch (Exception e) {
			throw new RuntimeException(
					"Exception occcurred while performing DynamoDB batchDelete operation on products table", e);
		}
	}
	
	
	/**
	 * Method to delete a DynamoDB table
	 * 
	 * @param tableName
	 */
	public void deleteTable(String tableName) {
		
		log.trace("Starting to delete "+tableName+" DynamoDB table...");
		try {
			long deletTableStart = Calendar.getInstance().getTimeInMillis();
			/*DeleteTableRequest deleteTableRequest = new DeleteTableRequest().withTableName(tableName);
			try {
				dynamoDBConfig.getAmazonDynamoDB().deleteTable(deleteTableRequest);
	        } catch (final ResourceNotFoundException e) {
	            if (log.isTraceEnabled()) {
	                log.trace("Table " + deleteTableRequest.getTableName() + " does not exist", e);
	            }
	        }*/
			
			//boolean deleteStatus = TableUtils.deleteTableIfExists(dynamoDBConfig.getAmazonDynamoDB(), deleteTableRequest);
			
			/*if (deleteStatus) {
				log.info(tableName + " was deleted successfully!");
			} else {
				log.error(tableName + " was not deleted. It might not exist!");
			}*/
			
			if(!isTableExist(tableName)) {
				log.info("No need of deleting table: "+ tableName+ " as it does not exist.");
				return;
			}
			
			
			Table table = dynamoDBConfig.getDynamoDB().getTable(tableName);
			table.delete();
			
			//log.info("Waiting for " + tableName + " to be deleted...this may take a while...");
			table.waitForDelete();
			
			long deletTableEnd = Calendar.getInstance().getTimeInMillis();
			
			log.info("DeleteTable request for "+ tableName + " took: "
					+ (deletTableEnd - deletTableStart) / 1000 + " seconds.");
		}catch(Exception e) {
			throw new RuntimeException("Exception occurred while deleting "+tableName, e);
		}
		
	}
	
	/**
	 * Create a DynamoDb table
	 * 
	 * @param tableName
	 */
	public void createTable(String tableName) {
		
		try {
			log.info("Initializing table schema for "+ tableName+"...");
			
            List<AttributeDefinition> attributeDefinitions = new ArrayList<AttributeDefinition>();
			attributeDefinitions
					.add(new AttributeDefinition().withAttributeName("pc_13").withAttributeType(ScalarAttributeType.S));
			attributeDefinitions.add(new AttributeDefinition().withAttributeName("region_code")
					.withAttributeType(ScalarAttributeType.S));

            List<KeySchemaElement> keySchema = new ArrayList<KeySchemaElement>();
            keySchema.add(new KeySchemaElement().withAttributeName("pc_13").withKeyType(KeyType.HASH)); // Partition key
            keySchema.add(new KeySchemaElement().withAttributeName("region_code").withKeyType(KeyType.RANGE)); //Range Key

            CreateTableRequest request = new CreateTableRequest().withTableName(tableName).withKeySchema(keySchema)
                .withAttributeDefinitions(attributeDefinitions).withProvisionedThroughput(
                    new ProvisionedThroughput().withReadCapacityUnits(5L).withWriteCapacityUnits(5L));
           
           log.info("Issuing CreateTable request for " + tableName);
           long createTableStart = Calendar.getInstance().getTimeInMillis();
           
           Table table = dynamoDBConfig.getDynamoDB().createTable(request);

            log.info("Waiting for " + tableName + " to be created...this may take a while...");
            table.waitForActive();
            
            long createTableEnd = Calendar.getInstance().getTimeInMillis();
            
            log.info("CreateTable request for "+ tableName + " took: "
					+ (createTableEnd - createTableStart) / 1000 + " seconds.");

        }
        catch (Exception e) {
           throw new RuntimeException("CreateTable request failed for " + tableName, e);
        }
		
	}
	
	/**
	 * Check if a table exists
	 * 
	 * @param tableName
	 * @return
	 */
	private boolean isTableExist(String tableName) {
		log.info("Checking whether table "+tableName+" exists before attempting to delete.");
        try {
            TableDescription tableDescription = dynamoDBConfig.getDynamoDB().getTable(tableName).describe();
            log.info("Table description: " + tableDescription.getTableStatus());

            return true;
        } catch (com.amazonaws.services.dynamodbv2.model.ResourceNotFoundException rnfe) {
            log.error(tableName+ " Table does not exist");
        }
        return false;

    }
}
