package com.levi.mp.inventory.model.json;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonInclude(Include.NON_NULL)
@JsonPropertyOrder({ "ID", "Sku" })
@JsonRootName(value = "Value")
public class CAProduct implements Serializable {

	private static final long serialVersionUID = -1987311422026680479L;

	private String productId;
	private String sku;
	
	@JsonProperty(value = "ID")
	public String getProductId() {
		return productId;
	}
	
	@JsonProperty(value = "ID")
	public void setProductId(String productId) {
		this.productId = productId;
	}

	@JsonProperty(value = "Sku")
	public String getSku() {
		return sku;
	}

	@JsonProperty(value = "Sku")
	public void setSku(String sku) {
		this.sku = sku;
	}

	@Override
	public String toString() {
		return "Value [id=" + productId + ", sku=" + sku + "]";
	}

}
