package com.levi.mp.inventory.function;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.levi.mp.inventory.helper.InventoryHelperUtils;
import com.levi.mp.inventory.service.InventoryExportService;
import com.levi.mp.inventory.service.ProductImportService;
import com.levi.mp.inventory.service.ServiceType;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

/**
 * 
 * Inventory Lambda Function handler
 * 
 * @author adhar@levi.com
 *
 */
@Log4j2
@Configuration
public class InventoryLambdaFunctionhandler implements RequestStreamHandler {

	private ProductImportService productImportService;

	private InventoryExportService inventoryExportService;
	
	private SNSService snsService;
	
	private ApplicationContext applicationContext;

	ApplicationContext getApplicationContext() {
		if(applicationContext == null) {
			applicationContext = new AnnotationConfigApplicationContext("com.levi.mp");
		}
		return applicationContext;
	}

	public void handleRequest(InputStream inputStream, OutputStream outputStream, Context context) {

		log.info("Starting Marketplace Inventory Lambda");

		try {
			if (inputStream == null) {
				log.error("No lambda input");
				outputStream.write("Please use {\"operation\":<\"product_import\"|\"inventory_update\">} as input for triggering this lamdba".getBytes());
				throw new RuntimeException("No lambda input");
			}
			Map<String, String> inputDataMap = InventoryHelperUtils.getMapFromJson(inputStream);
			if (inputDataMap == null || inputDataMap.isEmpty()) {
				log.error("Lambda input is not ok");
				outputStream.write("Please use {\"operation\":<\"product_import\"|\"inventory_update\">} as input for triggering this lamdba".getBytes());
				throw new RuntimeException("Lambda input is not ok");
			}

			String serviceType = inputDataMap.get("operation");
			log.info("ServiceType requested: " + serviceType);
			if (ServiceType.PRODUCT_IMPORT.getServiceType().equalsIgnoreCase(serviceType)) {
				try {
					productImportService = getApplicationContext().getBean(ProductImportService.class);
					productImportService.handleServiceRequest();
					
					//Change for printing process info in lambda output
					String processInfo = 
							"Successfully completed importing product data from Channel Advisor"
							+System.lineSeparator()
							+"-----Inventory Integrator (Product Import) Process Statistics:-----"
							+ System.lineSeparator()
							+productImportService.getInventoryIntegratorProcessInfo(); 
					 
					outputStream.write(processInfo.getBytes());
				} catch (Exception e) {
					//Notify Support
					log.info("Sending notification to support team");
					try {
						String notificationMessage = 
							"Error occured while fetching products from Channel Advisor and storing in DynamoDB"
							+ System.lineSeparator()
							+"Error Message: "
							+ System .lineSeparator()
							+ExceptionUtils.getStackTrace(e);
						String subject = "[MP-Inventory-Integrator]: Get Products from CA, "+e.getMessage();
						
						snsService = getApplicationContext().getBean(SNSService.class);
						snsService.notifySupport(notificationMessage,subject);
					}catch(Exception e1) {
						log.error("Error occured while sending notification to support team", e1);
					}		
					
					log.error(e.getMessage(), e);
					outputStream.write(("Error occured while fetching products from Channel Advisor and storing in DynamoDB: " + e.getMessage()).getBytes());
				}
			} else if (ServiceType.INVENTORY_UPDATE.getServiceType().equalsIgnoreCase(serviceType)) {
				try {
					inventoryExportService = getApplicationContext().getBean(InventoryExportService.class);
					inventoryExportService.handleServiceRequest();
					
					//Change for printing process info in lambda output
					String processInfo = 
							"Successfully sent inventory data to Channel Advisor"
							+System.lineSeparator()
							+"-----Inventory Integrator (Export) Process Statistics:-----"
							+ System.lineSeparator()
							+inventoryExportService.getInventoryIntegratorProcessInfo(); 
					
					outputStream.write(processInfo.getBytes());
				} catch (Exception e) {

					//Notify Support
					log.info("Sending notification to support team");
					try {
						String notificationMessage = 
							"Exception while sending inventory to Channel Advisor:"
							+ System.lineSeparator()
							+"Error Message: "
							+ System .lineSeparator()
							+ExceptionUtils.getStackTrace(e);
						String subject = "[MP-Inventory-Integrator]: Inventory update to CA, "+e.getMessage();
						
						snsService = getApplicationContext().getBean(SNSService.class);
						snsService.notifySupport(notificationMessage,subject);
					}catch(Exception e1) {
						log.error("Error occured while sending notification to support team", e1);
					}		
					
					log.error(e.getMessage(), e);
					outputStream.write(("Error occured while sending inventory to Channel Advisor: " + e.getMessage()).getBytes());
				}
			} else {
				log.error("Input operation is not correct for InventoryLambdaFunctionhandler: " + inputDataMap);
				outputStream.write("Please use {\"operation\":<\"product_import\"|\"inventory_update\">} as input for triggering this lamdba".getBytes());
			}

			log.info("InventoryLambdaFunctionhandler completed");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			log.error("Error occured while writing to OutputStream", e);
		}

	}

//	public static void main(String[] args) {
//		InventoryLambdaFunctionhandler a = new InventoryLambdaFunctionhandler();
//		InputStream inputStream = new ByteArrayInputStream("{\"operation\":\"product_import\"}".getBytes());
//		a.handleRequest(inputStream, null, null);
//	}

}
