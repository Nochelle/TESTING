package com.levi.mp.inventory.dao;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;

import lombok.Data;
import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
@Data
public class SpringJdbcConfigHelper {

	@Autowired
	InventoryIntegratorConfiguration inventoryConfig;

	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	public void init() {

		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		//dataSource.setDriverClassName(inventoryConfig.getConfig().getRedShiftJdbcDriverClassName());
		dataSource.setDriverClassName("com.amazon.redshift.jdbc.Driver");
		dataSource.setUrl(inventoryConfig.getConfig().getRedShiftJdbcUrl());
		dataSource.setUsername(inventoryConfig.getConfig().getRedShiftJdbcUsername());
		dataSource.setPassword(inventoryConfig.getConfig().getRedShiftJdbcPassword());

		jdbcTemplate = new JdbcTemplate(dataSource);

	}

//	public JdbcTemplate getJdbcTemplate() {
//		return jdbcTemplate;
//	}

}
