package com.levi.mp.inventory.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.dao.DynamoDBInventoryAdapter;
import com.levi.mp.inventory.dao.InventoryDao;
import com.levi.mp.inventory.helper.InventoryHelperUtils;
import com.levi.mp.inventory.model.db.Product;
import com.levi.mp.inventory.model.json.InventoryIntegratorProcessInfo;
import com.levi.mp.inventory.rest.client.InventoryRestClientAdapter;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;

import lombok.extern.log4j.Log4j2;

/**
 * InventoryExport service functionality
 * 
 * @author adhar@levi.com
 *
 */
@Log4j2
@Service
public class InventoryExportService {

	@Autowired
	InventoryIntegratorConfiguration inventoryConfig;

	@Autowired
	InventoryRestClientAdapter inventoryRestClientAdapter;

	@Autowired
	ChannelAdvisorTokenService channelAdvisorTokenService;

	@Autowired
	DynamoDBInventoryAdapter dynamoDBInventoryAdapter;

	@Autowired
	InventoryDao inventoryDao;
	
	InventoryIntegratorProcessInfo inventoryIntegratorProcessInfo;

	private List<Map<String, String>> invBulkDataForABatch = new ArrayList<>();
	
	
	private String accessToken = "";
	
	

	public void handleServiceRequest() {

		log.trace("Starting lambda handler function for inventory export...");
		
		int actualNumberOfrecordsAttemptedToSaveInCA = 0;
		List<String> totalSuccessfulPc13ListPostedToCA = new ArrayList<>();
		List<String> totalUnsuccessfulPc13ListPostedToCA = new ArrayList<>();
		final AtomicInteger batchCounter = new AtomicInteger(0);

		// fetch data from Redshift
		log.info("Fetching inventory data from RedShift...");
		Map<String, Integer> inventoryQtyMap = inventoryDao.getInventoryData();
		if (inventoryQtyMap.isEmpty()) {
			//log.error("No data fetched from Redshift inventory");
			throw new RuntimeException("No data fetched from Redshift inventory");
		}

		List<Product> productsListFromDB = dynamoDBInventoryAdapter.scanProductsTable();
		if (productsListFromDB == null || productsListFromDB.isEmpty()) {
			//log.error("No products fetched from Dynamo DB");
			throw new RuntimeException("No products fetched from Dynamo DB");
		}

		// Convert the productList fetched from DB into batches of 100
		log.info("Breaking down the product list from DB into batches of "
				+ inventoryConfig.getConfig().getCABatchPostItemsLimit() + " items each.");

		Collection<List<Product>> productBatches = InventoryHelperUtils.partition(productsListFromDB,
				inventoryConfig.getConfig().getCABatchPostItemsLimit());

		log.info("Broke down the product list from CA into: " + productBatches.size() + " partition(s)");

		for (List<Product> productList : productBatches) {

			batchCounter.getAndIncrement();

			log.info("Batch " + batchCounter + ": Starting batch post operation to CA for batch size: "
					+ productList.size());

			if (!invBulkDataForABatch.isEmpty()) {
				invBulkDataForABatch.clear();
			}

			for (Product product : productList) {
				
				Map<String, String> invDataMap = new HashMap<>();

				if (StringUtils.isEmpty(product.getPc_13())) {
					log.error("No pc_13 for product id: " + product.getCa_id());
					//log.error("Continuing to next product...");
					continue;
				}

				if (inventoryQtyMap.get(product.getPc_13()) == null) {
					log.error("Could not find avilable qty from inventory data for pc_13: " + product.getPc_13());
					//log.error("Continuing to next product...");
					continue;
				}

				if (!invDataMap.isEmpty()) {
					invDataMap.clear();
				}

				int productAvlQty = inventoryQtyMap.get(product.getPc_13());

				invDataMap.put("pc_13", product.getPc_13());
				invDataMap.put("id", product.getCa_id());
				invDataMap.put("display_qty", String.valueOf(productAvlQty));

				log.debug("Created inventory data: " + invDataMap);

				invBulkDataForABatch.add(invDataMap);

			}

			if (invBulkDataForABatch.isEmpty()) {
				log.error("No data to post to CA for batch: " + batchCounter);
				log.error("Continuing to next batch...");
				continue;
			}

			// post the products to CA
			
			log.info("Batch " + batchCounter + ": Total number of products attempted to update in CA: "
					+ invBulkDataForABatch.size());
			actualNumberOfrecordsAttemptedToSaveInCA += invBulkDataForABatch.size();
			
			// Update inventory for products in CA
			long batchUpdateCAStart = Calendar.getInstance().getTimeInMillis();
			Map<String, List<String>> responseMap = updateProducts(invBulkDataForABatch);
			
			
			if (responseMap.get("fail") != null && !responseMap.get("fail").isEmpty()) {
				log.error("Number of failed pc_13s for batch: " + batchCounter + " is " + responseMap.get("fail").size());
				log.error("Listing the failed products with their pc_13s");
				log.error(responseMap.get("fail"));

				log.info("Batch " + batchCounter + ": Total no of products not updated successfully in CA: "
						+ responseMap.get("fail").size());
				totalUnsuccessfulPc13ListPostedToCA.addAll(responseMap.get("fail"));
			}

			if (responseMap.get("success") != null && !responseMap.get("success").isEmpty()) {
				log.info("Number of successfull pc_13s for batch: " + batchCounter + " is "
						+ responseMap.get("success").size());
				log.info("Listing the successful products with their pc_13s");
				log.info(responseMap.get("success"));

				log.info("Batch " + batchCounter + ": Total no of products updated successfully in CA: "
						+ responseMap.get("success").size());
				totalSuccessfulPc13ListPostedToCA.addAll(responseMap.get("success"));

			}

			long batchUpdateCAEnd = Calendar.getInstance().getTimeInMillis();
			log.info(
					"Batch " + batchCounter + ": Total time taken for the batch update in CA along with parsing response:  "
							+ (batchUpdateCAEnd - batchUpdateCAStart) / 1000 + " seconds");

			if (responseMap.get("fail").size() != 0) {
				log.error("Batch " + batchCounter+ ": All inventory data could not be updated in CA! Check log for details.");
				/*throw new RuntimeException("Batch " + batchCounter
						+ ": All inventory data could not be updated in CA! Check log for details");*/
			}			

		}
		
		//Track process info
		inventoryIntegratorProcessInfo = InventoryIntegratorProcessInfo.builder()
					.totProductsFetchedFromDynamoDB(productsListFromDB.size())
					.actualProductsAttempetedToUpdateInCA(actualNumberOfrecordsAttemptedToSaveInCA)
					.productsUpdatedSuccessfullyInCA(totalSuccessfulPc13ListPostedToCA.size())
					.productsNotUpdatedInCA(totalUnsuccessfulPc13ListPostedToCA.size())
					.build();
		
		//log.info(">>>>>>>>>>>>>"+inventoryIntegratorProcessInfo);
		
		log.info("Total number of products fetched from DynamoDB: " + productsListFromDB.size());
		log.info("Actual number of products attempted to update in CA: " + actualNumberOfrecordsAttemptedToSaveInCA);
		log.info("Total no of products updated successfully in CA: " + totalSuccessfulPc13ListPostedToCA.size());
		log.info("Total no of products not updated successfully in CA: " + totalUnsuccessfulPc13ListPostedToCA.size());

		log.info("lambda handler function for inventory export completed successfully.");
	}

	/*
	 * public void handleServiceRequest_old() {
	 * 
	 * String s3PrefixForInventoryBulkFile = "";
	 * 
	 * log.info("Starting lambda handler function for inventory export...");
	 * 
	 * log.info("Levi Inventory Bulk request API invocation...");
	 * 
	 * String jsonResponse =
	 * inventoryRestClientAdapter.getInventoryBulkResponse(InventoryConstants.
	 * MARKETPLACE_S3_BUCKET, inventoryConfig.getConfig().getS3Folder() + "/" +
	 * inventoryConfig.getConfig().getMpInventoryRequestFileName() +
	 * inventoryConfig.getConfig().getMpInventoryRequestFileExtension());
	 * 
	 * log.info("jsonResponse from Inventory Bulk request: " + jsonResponse);
	 * 
	 * if (jsonResponse == null || jsonResponse.isEmpty()) {
	 * log.error("Inventory Bulk Response is not correct"); throw new
	 * RuntimeException("Inventory Bulk Response is not correct"); }
	 * 
	 * Map<String, String> inventoryBulkResponse =
	 * InventoryHelperUtils.getMapFromJson(jsonResponse);
	 * 
	 * if (inventoryBulkResponse == null || inventoryBulkResponse.isEmpty()) {
	 * log.error("Not Correct response from Levi Inventory Bulk request API ");
	 * throw new
	 * RuntimeException("Not Correct response from Levi Inventory Bulk request API "
	 * ); }
	 * 
	 * s3PrefixForInventoryBulkFile = inventoryBulkResponse.get("s3_prefix");
	 * 
	 * if (s3PrefixForInventoryBulkFile.isEmpty()) { log.
	 * error("No s3_prefix could be retrieved from Levi Inventory Bulk request API response"
	 * ); throw new
	 * RuntimeException("No s3_prefix could be retrieved from Levi Inventory Bulk request API response"
	 * ); }
	 * 
	 * log.info("Starting to download file " + s3PrefixForInventoryBulkFile +
	 * " from S3..."); File downloadedFile =
	 * S3Adapter.downloadFile(InventoryConstants.MARKETPLACE_S3_BUCKET,
	 * s3PrefixForInventoryBulkFile); if (downloadedFile == null) { throw new
	 * RuntimeException("Could not download file: " + s3PrefixForInventoryBulkFile +
	 * " from S3"); }
	 * 
	 * log.info("Successfully downloaded file to: " +
	 * downloadedFile.getAbsolutePath() + " from S3!");
	 * 
	 * log.debug("Reading file: " + downloadedFile.getAbsolutePath() + " ...");
	 * String fileContent =
	 * InventoryHelperUtils.readFile(downloadedFile.getAbsolutePath());
	 * 
	 * if (fileContent == null || fileContent.isEmpty()) {
	 * log.error("No data in file downloaded from S3!!!"); throw new
	 * RuntimeException("No data in file downloaded from S3!!!"); }
	 * 
	 * log.debug("Successfully read file: " + downloadedFile.getAbsolutePath() +
	 * "!"); invBulkData = InventoryHelperUtils.getListFromJson(fileContent);
	 * 
	 * if (invBulkData == null || invBulkData.isEmpty()) { log.
	 * error("No data could be parsed from inventory bulk file downloaded from S3!!!"
	 * ); throw new
	 * RuntimeException("No data could be parsed from inventory bulk file downloaded from S3!!!"
	 * ); }
	 * 
	 * long getProductIdForPC_13Start = Calendar.getInstance().getTimeInMillis();
	 * for (Map<String, String> productDataMap : invBulkData) { String productId;
	 * 
	 * String pc_13 = productDataMap.get("pc_13"); if (pc_13 == null ||
	 * pc_13.isEmpty()) { log.info("No pc_13 found in inventory bulk file data: " +
	 * productDataMap); log.info("Continuing to next product."); continue; }
	 * 
	 * productId = dynamoDBInventoryAdapter.fetchProductIdByPc13(pc_13);
	 * 
	 * if (productId == null || productId.isEmpty()) {
	 * log.error("Not correct productId from DB for pc_13 " + pc_13);
	 * log.error("Continuing to next product."); continue; }
	 * 
	 * productDataMap.put("id", productId);
	 * 
	 * }
	 * 
	 * long getProductIdForPC_13End = Calendar.getInstance().getTimeInMillis();
	 * log.info("Fetching product ids from DB for all Pc13s took: " +
	 * (getProductIdForPC_13End - getProductIdForPC_13Start) / 1000 + " seconds.");
	 * 
	 * // Modifying invBulkData to remove all the products for which id could not be
	 * // fetched from DB. // This should not occur ideally log.
	 * info("Modifying invBulkData to remove all the products for which id could not be fetched from DB"
	 * ); invBulkData = invBulkData.stream().filter(x -> (x.get("id") != null &&
	 * !x.get("id").isEmpty())).collect(Collectors.toList());
	 * 
	 * log.info("inventory bulk data after populating with CA product ID: " +
	 * invBulkData);
	 * 
	 * if (invBulkData.isEmpty()) { log.error("No bulk data to update in CA"); throw
	 * new RuntimeException("No bulk data to update in CA"); }
	 * 
	 * if(!successfulPc13ListPostedToCAInABatch.isEmpty()) {
	 * successfulPc13ListPostedToCAInABatch.clear(); }
	 * if(!unsuccessfulPc13ListPostedToCAInABatch.isEmpty()) {
	 * unsuccessfulPc13ListPostedToCAInABatch.clear(); }
	 * 
	 * // Update inventory for products in CA boolean batchUpdateStatus =
	 * updateProducts(invBulkData);
	 * 
	 * log.info("Total number of products attempted to update in CA: " +
	 * invBulkData.size());
	 * log.info("Total no of products updated successfully in CA: " +
	 * successfulPc13ListPostedToCAInABatch.size());
	 * log.info("Total no of products not updated successfully in CA: " +
	 * unsuccessfulPc13ListPostedToCAInABatch.size());
	 * 
	 * if (!batchUpdateStatus) { log.
	 * error("All inventory data could not be updated in CA! Check log for details."
	 * ); throw new
	 * RuntimeException("All inventory data could not be updated in CA! Check log for details"
	 * ); }
	 * 
	 * log.
	 * info("lambda handler function for inventory export completed successfully");
	 * 
	 * }
	 */

	/**
	 * Method to update products via {@code InventoryRestClientAdapter}
	 * 
	 * @param bulkData
	 * @return batchUpdateStatus
	 */
	private Map<String, List<String>> updateProducts(List<Map<String, String>> bulkData) {

		accessToken = channelAdvisorTokenService.getOAuth2Token();
		
		Map<String, List<String>> responseMap = inventoryRestClientAdapter.updateProductsInCA(bulkData, accessToken);

		

		/*if (responseMap.get("fail") != null && !responseMap.get("fail").isEmpty()) {
			log.error("Number of failed pc_13s for batch: " + batchCounter + " is " + responseMap.get("fail").size());
			log.error("Listing the failed products with their pc_13s");
			log.error(responseMap.get("fail"));

			log.info("Batch " + batchCounter + ": Total no of products not updated successfully in CA: "
					+ responseMap.get("fail").size());
			totalUnsuccessfulPc13ListPostedToCA.addAll(responseMap.get("fail"));
		}

		if (responseMap.get("success") != null && !responseMap.get("success").isEmpty()) {
			log.info("Number of successfull pc_13s for batch: " + batchCounter + " is "
					+ responseMap.get("success").size());
			log.info("Listing the successful products with their pc_13s");
			log.info(responseMap.get("success"));

			log.info("Batch " + batchCounter + ": Total no of products updated successfully in CA: "
					+ responseMap.get("success").size());
			totalSuccessfulPc13ListPostedToCA.addAll(responseMap.get("success"));

		}

		long batchUpdateCAEnd = Calendar.getInstance().getTimeInMillis();
		log.info(
				"Batch " + batchCounter + ": Total time taken for the batch update in CA along with parsing response:  "
						+ (batchUpdateCAEnd - batchUpdateCAStart) / 1000 + " seconds");

		if (responseMap.get("fail").size() == 0) {
			batchUpdateStatus = Boolean.TRUE;
		}*/

		return responseMap;

	}
	
	public InventoryIntegratorProcessInfo getInventoryIntegratorProcessInfo() {
		return inventoryIntegratorProcessInfo;
	}
}
