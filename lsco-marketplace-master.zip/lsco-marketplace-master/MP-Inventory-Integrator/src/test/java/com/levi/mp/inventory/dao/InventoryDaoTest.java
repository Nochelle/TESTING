package com.levi.mp.inventory.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.levi.mp.inventory.InventoryTestConfig;
import com.levi.mp.inventory.config.DynamoDBConfig;
import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.model.json.Config;
import org.junit.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = InventoryTestConfig.class)

public class InventoryDaoTest {

	@MockBean
	SpringJdbcConfigHelper springJdbcConfigHelper;

	@MockBean
	InventoryIntegratorConfiguration inventoryConfig;
	
	@MockBean
	DynamoDBConfig dynamoDBConfig;

	@MockBean
	JdbcTemplate jdbcTemplate;

	@Autowired
	InventoryDao iDao;

	static final Config config = new Config();

	@Before
	public void setUp() throws Exception {
	}

	@BeforeClass
	public static void init() {
		createInventoryIntegratorConfig();
	}

	@Test
	public void testGetInventoryData() {
		Mockito.when(springJdbcConfigHelper.getInventoryConfig()).thenReturn(inventoryConfig);
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		Mockito.when(springJdbcConfigHelper.getJdbcTemplate()).thenReturn(jdbcTemplate);
		Mockito.when(jdbcTemplate.queryForList(Mockito.anyString())).thenReturn(getDummyDataForLocalTesting());

		Map<String, Integer> dataMap = iDao.getInventoryData();
		
		Assert.assertNotNull(dataMap);
		Assert.assertEquals(1, dataMap.size());
		Assert.assertEquals(25, dataMap.get("05527054602930").intValue());
		
		
		// fail("Not yet implemented");
	}

	private static void createInventoryIntegratorConfig() {

		config.setRedShiftJdbcDriverClassName("com.amazon.redshift.jdbc.Driver");
		config.setRedShiftJdbcUrl(
				"jdbc:redshift://10.249.63.2:5439/knowmedm?ssl=true&sslfactory=com.amazon.redshift.ssl.NonValidatingFactory");
		config.setRedShiftJdbcUsername("Dummy_USER");
		config.setRedShiftJdbcPassword("DUMMY_PASSWORD");
		config.setRedshiftSchemaName("DUMMY_SCHEMA");

	}

	private static List<Map<String, Object>> getDummyDataForLocalTesting() {

		List<Map<String, Object>> dataList = new ArrayList<>();

		Map<String, Object> dataMap = new HashMap<>();

		dataMap.put("pc13", "05527054602930");
		dataMap.put("availableQuantity", 25);

		dataList.add(dataMap);

		return dataList;

	}

}
