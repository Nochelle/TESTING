package com.levi.mp.inventory.function;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class InventoryImportFunctionhandlerTest {

	private static Object input;
	private static Object invalidInput;
	private static Object invalidJsonInput;

	@BeforeClass
	public static void createInput() throws IOException {
		// TODO: set up your sample input object here.
		input = "{\"operation\":\"product_import\"}";
		invalidInput = Integer.valueOf(10);
		invalidJsonInput = "{\"operation:\"product_import\"}";
	}

	@Test
	@Ignore
	public void testInventoryImportFunctionHandler() throws JsonParseException, JsonMappingException, IOException {
		Context context = createContext();

		InventoryLambdaFunctionhandler handler = new InventoryLambdaFunctionhandler();
		handler.handleRequest(new ByteArrayInputStream(input.toString().getBytes()), new ByteArrayOutputStream(),
				context);

		/* Assert.assertNotEquals("error", output); */

	}

	@Test
	@Ignore
	public void testInvalidJsonInputToLambda() throws JsonParseException, JsonMappingException, IOException {
		Context context = createContext();

		InventoryLambdaFunctionhandler handler = new InventoryLambdaFunctionhandler();
		handler.handleRequest(new ByteArrayInputStream(invalidJsonInput.toString().getBytes()),
				new ByteArrayOutputStream(), context);

		/* Assert.assertEquals("error", output); */
	}

	@Test
	@Ignore
	public void testInvalidInputToLambda() throws JsonParseException, JsonMappingException, IOException {
		Context context = createContext();

		InventoryLambdaFunctionhandler handler = new InventoryLambdaFunctionhandler();
		handler.handleRequest(new ByteArrayInputStream(invalidInput.toString().getBytes()), new ByteArrayOutputStream(),
				context);

		/* Assert.assertEquals("error", output); */
	}
	
	private Context createContext() {
		return new TestContext();
	}

}
