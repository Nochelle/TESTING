package com.levi.mp.inventory.dao;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedQueryList;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedScanList;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.DeleteTableRequest;
import com.amazonaws.services.dynamodbv2.model.DeleteTableResult;
import com.amazonaws.services.dynamodbv2.model.ResourceNotFoundException;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.amazonaws.services.dynamodbv2.model.WriteRequest;
import com.amazonaws.services.dynamodbv2.util.TableUtils;
import com.levi.mp.inventory.InventoryTestConfig;
import com.levi.mp.inventory.config.DynamoDBConfig;
import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.model.db.Product;
import com.levi.mp.inventory.model.json.Config;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = InventoryTestConfig.class)
public class DynamoDBInventoryAdapterTest {

	final static List<Product> products = new ArrayList<>();
	static final Config config = new Config();
	final static List<FailedBatch> failedbatches = new ArrayList<>();
	final static Map<String, List<Object>> fetchresults = new HashMap<>();
	
	@MockBean
	DynamoDBMapper mapper;
	
	@MockBean
	DynamoDBConfig dynamoDBConfig;
	
	@MockBean
	DynamoDB dynamoDB;
	
	@MockBean
	AmazonDynamoDB amazonDynamoDB;
	
	@MockBean
	Table table;
	
	@MockBean
	DeleteTableResult deleteTableResult;
	
	@MockBean
	TableDescription tableDescription;

	@MockBean
	InventoryIntegratorConfiguration inventoryConfig;

	@MockBean
	SpringJdbcConfigHelper springconfigJdbcHelper;

	@Autowired
	DynamoDBInventoryAdapter dao;

	@Mock
	PaginatedQueryList paginatedQueryList;

	@Mock
	PaginatedScanList paginatedScanList;

	@BeforeClass
	public static void setUp() {

		createMockListofProducts();
		createMockFailedBatches();
		createFetchresults();
		createInventoryIntegratorConfig();

	}

	/*
	 * @Before public void init() { MockitoAnnotations.initMocks(this); }
	 */

	@Test
	public void testSaveProducts_SuccessfulResponse() {
		
		/*Mockito.when(dynamoDBMapperConfig.builder()).thenReturn(builder);
		Mockito.when(tableNameOverride.withTableNamePrefix(Mockito.anyString())).thenReturn(tableNameOverride);
		Mockito.when(builder.withTableNameOverride(Mockito.any())).thenReturn(builder);
		Mockito.when(builder.build()).thenReturn(dynamoDBMapperConfig);*/
		
		Mockito.when(dynamoDBConfig.getDynamoDBMapper()).thenReturn(mapper);
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

		Mockito.when(mapper.batchSave(products))
			.thenReturn(new ArrayList<FailedBatch>());
		try {
			dao.saveProducts(products);
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage() != null); // fail test if exception raised
		}

	}

	@Test
	public void testSaveProducts_Failedbatches() {
		
		Mockito.when(dynamoDBConfig.getDynamoDBMapper()).thenReturn(mapper);
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

		Mockito.when(mapper.batchSave(products)).thenReturn(failedbatches);

		try {
			dao.saveProducts(products);
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage() != null); 
		}
	}

	@Test
	public void testSaveProducts_Exception() {
		Mockito.when(dynamoDBConfig.getDynamoDBMapper()).thenReturn(mapper);
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

		Mockito.when(mapper.batchSave(products))
			.thenThrow(new RuntimeException("Exception while saving products"));

		try {
			dao.saveProducts(products);
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage() != null); 
		}
	}

	@Test
	public void testFetchProducts_Success() {
		Mockito.when(dynamoDBConfig.getDynamoDBMapper()).thenReturn(mapper);
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

		Mockito.when(mapper.batchLoad(products))
			.thenReturn(fetchresults);

		List<Product> productsFromDB = dao.fetchProducts(products);

		Assert.assertNotNull(productsFromDB);
	}

	@Test
	public void testFetchProducts_Exception() {
		Mockito.when(dynamoDBConfig.getDynamoDBMapper()).thenReturn(mapper);
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		try {
			Mockito.when(mapper.batchLoad(products))
				.thenThrow(new RuntimeException("Exception while fetching products"));
			dao.fetchProducts(products);
		} catch (Exception e) {
			assertTrue("Expected Runtime exception", e.getMessage() != null);
			return;
		}
		assertTrue("Expected exception but it did not!", true == false);

		
	}
	
	@Test
	public void testDeleteAllProducts_Success() {
		Mockito.when(dynamoDBConfig.getDynamoDBMapper()).thenReturn(mapper);
		
		Product product = Product.builder().ca_id("45664").pc_13("00501196303430").region_code("US").build();
		List<Product> productList = new ArrayList<>();
		productList.add(product);
		
		Mockito.when(paginatedScanList.get(0)).thenReturn(product);
		Mockito.when(paginatedQueryList.size()).thenReturn(1);
		
		Mockito.when(mapper.scan(Mockito.eq(Product.class), Mockito.any(DynamoDBScanExpression.class)))
			.thenReturn(paginatedScanList);
		
		Mockito.when(mapper.batchDelete(ArgumentMatchers.<List<Product>>any()))
			.thenReturn(new ArrayList<FailedBatch>());
		
		try {
			dao.deleteAllProducts();
		}catch(Exception e) {
			assertFalse(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void testDeleteAllProducts_FailedBatches() {
		Mockito.when(dynamoDBConfig.getDynamoDBMapper()).thenReturn(mapper);
		
		Product product = Product.builder().ca_id("45664").pc_13("00501196303430").region_code("US").build();
		List<Product> productList = new ArrayList<>();
		productList.add(product);
		
		Mockito.when(paginatedScanList.get(0)).thenReturn(product);
		Mockito.when(paginatedQueryList.size()).thenReturn(1);
		
		Mockito.when(mapper.scan(Mockito.eq(Product.class), Mockito.any(DynamoDBScanExpression.class)))
			.thenReturn(paginatedScanList);
		
		Mockito.when(mapper.batchDelete(ArgumentMatchers.<List<Product>>any()))
			.thenReturn(failedbatches);
		try {
			dao.deleteAllProducts();
		}catch(Exception e) {
			assertTrue(e.getMessage() != null
					&& e.getMessage().contains("Exception occcurred while performing DynamoDB batchDelete operation on products table"));
		}
	}
	
	
	@Test
	public void testDeleteAllProducts_Exception() {
		Mockito.when(dynamoDBConfig.getDynamoDBMapper()).thenReturn(mapper);
		
		Product product = Product.builder().ca_id("45664").pc_13("00501196303430").region_code("US").build();
		List<Product> productList = new ArrayList<>();
		productList.add(product);
		
		Mockito.when(paginatedScanList.get(0)).thenReturn(product);
		Mockito.when(paginatedQueryList.size()).thenReturn(1);
		
		Mockito.when(mapper.scan(Mockito.eq(Product.class), Mockito.any(DynamoDBScanExpression.class)))
			.thenReturn(paginatedScanList);
		
		Mockito.when(mapper.batchDelete(ArgumentMatchers.<List<Product>>any()))
		.thenThrow(new RuntimeException("Error occurred while performing dynamoDB batchDelete operation"));
		
		try {
			dao.deleteAllProducts();
			
		}catch(Exception e) {
			assertTrue(e.getMessage() != null
					&& e.getMessage().contains("Exception occcurred while performing DynamoDB batchDelete operation on products table"));
		}
	}
	

	@Test
	public void testScanProductsTable() {
		Mockito.when(dynamoDBConfig.getDynamoDBMapper()).thenReturn(mapper);
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		
		String productId = "45664";
		String pc_13 = "00501196303430";

		Product product = Product.builder().ca_id(productId).pc_13(pc_13).region_code("US").build();
		List<Product> productList = new ArrayList<>();
		productList.add(product);

		Mockito.when(paginatedScanList.get(0)).thenReturn(product);
		Mockito.when(paginatedQueryList.size()).thenReturn(1);

		Mockito.when(mapper.scan(Mockito.eq(Product.class), Mockito.any(DynamoDBScanExpression.class)))
			.thenReturn(paginatedScanList);

		List<Product> productListDB = dao.scanProductsTable();
		Assert.assertNotNull(productListDB);

	}
	
	@Test
	public void deleteTableTest_Success() {
		Mockito.when(dynamoDBConfig.getDynamoDB()).thenReturn(dynamoDB);
		Mockito.when(dynamoDBConfig.getAmazonDynamoDB()).thenReturn(amazonDynamoDB);
		Mockito.when(dynamoDB.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(table.describe()).thenReturn(tableDescription);
		Mockito.when(table.delete()).thenReturn(deleteTableResult);
		/*Mockito.when(amazonDynamoDB.deleteTable(Mockito.any(DeleteTableRequest.class)))
			.thenReturn(deleteTableResult);*/
		/*Mockito.when(tableUtils.deleteTableIfExists
				(amazonDynamoDB, Mockito.any(DeleteTableRequest.class)))
			.thenReturn(Boolean.TRUE);*/
		try {
			Mockito.doNothing().when(table).waitForDelete();
			
			dao.deleteTable("DUMMY_TABLE");
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage() != null); // fail if exception comes
		}

	}
	
	
	@Test
	public void deleteTableTest_ResourceNotFoundException() {
		Mockito.when(dynamoDBConfig.getDynamoDB()).thenReturn(dynamoDB);
		Mockito.when(dynamoDBConfig.getAmazonDynamoDB()).thenReturn(amazonDynamoDB);
		Mockito.when(dynamoDB.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(table.describe())
			.thenThrow(new ResourceNotFoundException("Table not found"));
		/*Mockito.when(amazonDynamoDB.deleteTable(Mockito.any(DeleteTableRequest.class)))
			.thenThrow(new ResourceNotFoundException("Table not found"));*/
		/*Mockito.when(table.delete())
			.thenThrow(new RuntimeException("Exception occurred while deleting table"));*/

		try {
			dao.deleteTable("DUMMY_TABLE");
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage() != null);
		}

	}
	
	
	@Test
	public void deleteTableTest_Exception() {
		Mockito.when(dynamoDBConfig.getDynamoDB()).thenReturn(dynamoDB);
		Mockito.when(dynamoDBConfig.getAmazonDynamoDB()).thenReturn(amazonDynamoDB);
		Mockito.when(dynamoDB.getTable(Mockito.anyString())).thenReturn(table);
		
		Mockito.when(table.describe()).thenReturn(tableDescription);
		
		/*Mockito.when(amazonDynamoDB.deleteTable(Mockito.any(DeleteTableRequest.class)))
			.thenThrow(new RuntimeException("Exception occurred while deleting table"));*/
		Mockito.when(table.delete())
			.thenThrow(new RuntimeException("Exception occurred while deleting table"));

		try {
			Mockito.doNothing().when(table).waitForDelete();
			
			dao.deleteTable("DUMMY_TABLE");
		} catch (Exception e) {
			Assert.assertTrue(
					e.getMessage() != null && e.getMessage().contains("Exception occurred while deleting DUMMY_TABLE"));
		}

	}
	
	@Test
	public void createTableTest_Success() {
		Mockito.when(dynamoDBConfig.getDynamoDB()).thenReturn(dynamoDB);
		Mockito.when(dynamoDB.createTable(Mockito.any(CreateTableRequest.class))).thenReturn(table);

		try {
			Mockito.when(table.waitForActive()).thenReturn(tableDescription);

			dao.createTable("DUMMY_TABLE");

		} catch (Exception e) {
			Assert.assertFalse(e.getMessage() != null); // fail if exception comes
		}

	}
	
	
	@Test
	public void createTableTest_Exception() {
		Mockito.when(dynamoDBConfig.getDynamoDB()).thenReturn(dynamoDB);
		Mockito.when(dynamoDB.createTable(Mockito.any(CreateTableRequest.class)))
				.thenThrow(new RuntimeException("CreateTable request failed"));

		try {
			dao.createTable("DUMMY_TABLE");

		} catch (Exception e) {
			Assert.assertTrue(e.getMessage() != null && 
					e.getMessage().contains("CreateTable request failed for DUMMY_TABLE"));
		}

	}

	private static void createMockListofProducts() {

		Product product = Product.builder().ca_id("45664").pc_13("00501196303430").region_code("US").build();
		products.add(product);

	}

	private static void createMockFailedBatches() {
		FailedBatch failedBatch = new FailedBatch();
		failedBatch.setException(new RuntimeException("Dummy RuntimeException"));

		Map<String, List<WriteRequest>> unProcessedItems = new HashMap<>();
		failedBatch.setUnprocessedItems(unProcessedItems);
		failedbatches.add(failedBatch);
	}

	private static void createFetchresults() {
		List<Object> productsList = new ArrayList<>();

		Product product = Product.builder().ca_id("45664").pc_13("00501196303430").region_code("US").build();
		productsList.add(product);

		fetchresults.put("MP_PRODUCTS_DEV", productsList);

	}
	
	private static void createInventoryIntegratorConfig() {

		config.setDynamoDBMarketPlaceTableName("DUMMY_TABLE");
		config.setDynamoDBEndPoint("DUMMY_DYNAMODB_ENDPOINT");
		config.setDynamoDBRegion("DUMMY_DYNAMODB_REGION");

	}

}
