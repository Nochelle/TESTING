package com.levi.mp.inventory.rest.client;

import static org.junit.Assert.assertTrue;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.levi.mp.inventory.InventoryTestConfig;
import com.levi.mp.inventory.config.DynamoDBConfig;
import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.dao.SpringJdbcConfigHelper;
import com.levi.mp.inventory.model.json.CAProducts;
import com.levi.mp.inventory.model.json.Config;
import com.levi.mp.shared.ca.util.MPSharedUtil;
import com.levi.mp.shared.ca.util.S3Adapter;
import com.levi.mp.shared.sns.SNSService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = InventoryTestConfig.class)
public class InventoryRestClientAdapterTest {

	@MockBean
	InventoryIntegratorConfiguration inventoryConfig;
	
	@MockBean
	SpringJdbcConfigHelper springconfigJdbcHelper;
	
	@MockBean
	DynamoDBConfig dynamoDBConfig;
	
	@MockBean
	RestTemplate restTemplate;
	
	@MockBean
	SNSService snsService;
	
	@Autowired
	InventoryRestClientAdapter inventoryRestClientAdapter;
	
	
	static URI uri;
	static Response response;
	static final Config config = new Config();
	final static String dummyCAToken = "DummyAccessToken";
	final static String dummyURL = "https://google.com";
	final static String s3Bucket = "S3Bucket";
	final static String s3Key = "S3Key";

	@BeforeClass
	public static void setUp() throws URISyntaxException {
		createInventoryIntegratorConfig();

	}

	@Test
	public void testGetProductsFromCA_Success() {
		
		String entity = "{\"value\":[{\"ID\":14173341,\"Sku\":\"0001b39f\"},{\"ID\":14173342,\"Sku\":\"0001b39f\"}]}";

		ResponseEntity<String> responseEntity = ResponseEntity.ok(entity);
		
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

		Mockito.when(restTemplate.exchange(
				Mockito.anyString(), 
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);

		CAProducts caProducts = inventoryRestClientAdapter.getProductsFromCA(dummyCAToken);

		Assert.assertNotNull("caProducts is null", caProducts);
		Assert.assertNotNull("Product is null inside CAProducts", caProducts.getCaProduct());
		Assert.assertEquals(2, caProducts.getCaProduct().size());
		Assert.assertEquals("14173341", caProducts.getCaProduct().get(0).getProductId());

	}
	
	
	@Test
	public void testGetProductsFromCA_Non_200_Response() {

		ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();

		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

		Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(),
				ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);
		
		try {
		CAProducts caProducts = inventoryRestClientAdapter.getProductsFromCA(dummyCAToken);
		}catch(Exception e) {
			Assert.assertTrue(e.getMessage()!=null);
		}

		//Assert.assertNull(caProducts);

	}
	
	
	@Test
	public void testGetProductsFromCA_Exception() {

		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(),
				ArgumentMatchers.<Class<String>>any()))
		.thenThrow(new RuntimeException("Exception occurred when fetching products from CA"));

		CAProducts caProducts;
		try {
			caProducts = inventoryRestClientAdapter.getProductsFromCA(dummyCAToken);
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage()!=null);
		}
		
		//Assert.assertNull(caProducts);

	}
	
	
	
	@Test
	public void testUpdateProductsInCA_Sucess() {
		
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		
		List<Map<String, String>> dataList = new ArrayList<>();
		Map<String, String> dataMap = new HashMap<>();

		dataMap.put("id", "45664");
		dataMap.put("display_qty", "100");
		dataMap.put("pc_13", "00501196303430");

		dataList.add(dataMap);		

		String responseFromCA = getDummyCAPostResponse();
		
		ResponseEntity<String> responseEntity = ResponseEntity.ok(responseFromCA);

		Mockito.when(restTemplate.exchange(
				Mockito.anyString(), 
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);

		Map<String, List<String>> results = inventoryRestClientAdapter.updateProductsInCA(dataList, dummyCAToken);
		Assert.assertNotNull(results);
		Assert.assertNotNull(results.get("success"));

	}
	
	@Test
	public void updateProductsInCA_Non_200_response(){
		
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		
		List<Map<String, String>> dataList = new ArrayList<>();
		Map<String, String> dataMap = new HashMap<>();

		dataMap.put("id", "45664");
		dataMap.put("display_qty", "100");
		dataMap.put("pc_13", "00501196303430");

		dataList.add(dataMap);
		
		ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();

		Mockito.when(restTemplate.exchange(
				Mockito.anyString(), 
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);

		Map<String, List<String>> results = inventoryRestClientAdapter.updateProductsInCA(dataList, dummyCAToken);
		
		Assert.assertNotNull(results);
		Assert.assertNotNull(results.get("fail"));
		
	}
	
	
	
	@Test
	public void updateProductsInCA_BatchResponse200_WithFailedRecords(){
		
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		
		List<Map<String, String>> dataList = new ArrayList<>();
		Map<String, String> dataMap = new HashMap<>();

		dataMap.put("id", "45664");
		dataMap.put("display_qty", "100");
		dataMap.put("pc_13", "00501196303430");

		dataList.add(dataMap);
		
		ResponseEntity<String> responseEntity = ResponseEntity.ok(getDummyCAPostErrorResponse());

		Mockito.when(restTemplate.exchange(
				Mockito.anyString(), 
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);

		Map<String, List<String>> results = inventoryRestClientAdapter.updateProductsInCA(dataList, dummyCAToken);
		
		Assert.assertNotNull(results);
		Assert.assertNotNull(results.get("fail"));
		
	}
	
	
	@Test
	public void updateProductsInCA_Exception(){
		
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		Mockito.when(snsService.notifySupport(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(Boolean.TRUE);
		
		List<Map<String, String>> dataList = new ArrayList<>();
		Map<String, String> dataMap = new HashMap<>();

		dataMap.put("id", "45664");
		dataMap.put("display_qty", "100");
		dataMap.put("pc_13", "00501196303430");

		dataList.add(dataMap);

		Mockito.when(restTemplate.exchange(
				Mockito.anyString(), 
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenThrow(new RuntimeException("Exception occurred while updating products in CA"));

		Map<String, List<String>> results = inventoryRestClientAdapter.updateProductsInCA(dataList, dummyCAToken);
		
		Assert.assertNotNull(results);
		Assert.assertNotNull(results.get("fail"));
		
	}
	
	
	
	
	
	
	
	
	
	
	@Test
	public void testGetNextProductsFromCA_Success() {
		
		String entity = "{\"@odata.context\":\"https://api.channeladvisor.com/v1/$metadata#Products(Sku,ID)\","
				+ "\"value\":[{\"Sku\":\"TestSku_DO_NOT_SHIP\",\"ID\":45660},{\"Sku\":\"TestSku_DO_NOT_SHIP2\",\"ID\":45661}],"
				+ "\"@odata.nextLink\":\"https://api.channeladvisor.com/v1/Products?access_token=GvuEHzmfqEYzXzM00v1k8LI8l-QfdgJ2tYlHZXOEKxk-22653"
				+ "&$select=Sku%2CID&$skip=100\"}";

		ResponseEntity<String> responseEntity = ResponseEntity.ok(entity);
		
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

		Mockito.when(restTemplate.exchange(
				Mockito.anyString(), 
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);

		CAProducts caProducts = inventoryRestClientAdapter.getNextProductsFromCA(dummyCAToken, dummyURL);

		Assert.assertNotNull("caProducts is null", caProducts);
		Assert.assertNotNull("Product is null inside CAProducts", caProducts.getCaProduct());
		Assert.assertEquals(2, caProducts.getCaProduct().size());
		Assert.assertEquals("45660", caProducts.getCaProduct().get(0).getProductId());

	}
	
	
	@Test
	public void testGetNextProductsFromCA_Non_200_Response() {

		try {
			ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();

			Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

			Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(),
					ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);

			inventoryRestClientAdapter.getNextProductsFromCA(dummyCAToken, dummyURL);
		} catch (Exception e) {
			assertTrue("Expected Runtime exception as not a 200 response", e.getMessage() != null);
			return;
		}
		assertTrue("Expected exception for not a 200 response it did not!", true == false);
	}
	
	
	@Test
	public void testGetNextProductsFromCA_Exception() {

		try {
			Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

			Mockito.when(restTemplate.exchange(
					Mockito.anyString(),
					Mockito.any(HttpMethod.class), 
					Mockito.any(),
					ArgumentMatchers.<Class<String>>any()))
			.thenThrow(new RuntimeException("Exception occurred when fetching products from CA"));

			inventoryRestClientAdapter.getNextProductsFromCA(dummyCAToken,dummyURL);
			
		} catch (Exception e) {
			assertTrue("Expected Runtime exception restTemplate.exchange", e.getMessage() != null);
			return;
		}
		assertTrue("Expected exception from restTemplate.exchange() call but it did not!", true == false);
		

	}
	
	
	
	private static void createInventoryIntegratorConfig() {

		config.setCAEndpointV1("https://dummyCAEndpoint");
		config.setCAProductResourcePath("product");
		
	}
	
	private static String getDummyCAPostResponse() {

		/*--batchresponse_53b982ba-e628-4e3e-90de-6071941d5811
		Content-Type: application/http
		Content-Transfer-Encoding: binary
		
		HTTP/1.1 204 No Content
		
		
		--batchresponse_53b982ba-e628-4e3e-90de-6071941d5811--*/

		StringBuffer buffer = new StringBuffer();
		buffer.append("--batchresponse_53b982ba-e628-4e3e-90de-6071941d5811").append(System.lineSeparator()).append("Content-Type: application/http")
				.append(System.lineSeparator()).append("Content-Transfer-Encoding: binary").append(System.lineSeparator())
				.append("HTTP/1.1 204 No Content").append(System.lineSeparator()).append(System.lineSeparator())
				.append("--batchresponse_53b982ba-e628-4e3e-90de-6071941d5811--");

		return buffer.toString();

	}
	
	private static String getDummyCAPostErrorResponse() {

		/*--batchresponse_f4fca79b-085a-4e4f-b608-096e0616f9ae
		Content-Type: application/http
		Content-Transfer-Encoding: binary

		HTTP/1.1 401 Unauthorized
		Content-Type: application/json; odata.metadata=minimal
		OData-Version: 4.0

		{
		  "error":{
		    "code":"","message":"Authorization has been denied for this request."
		  }
		}
		--batchresponse_f4fca79b-085a-4e4f-b608-096e0616f9ae--*/


		StringBuffer buffer = new StringBuffer();
		buffer.append("--batchresponse_f4fca79b-085a-4e4f-b608-096e0616f9ae")
			.append(System.lineSeparator()).append("Content-Type: application/http")
			.append(System.lineSeparator()).append("Content-Transfer-Encoding: binary")
			.append(System.lineSeparator())
			.append("HTTP/1.1 401 Unauthorized").append(System.lineSeparator())
			.append("Content-Type: application/json; odata.metadata=minimal")
			.append(System.lineSeparator()).append("OData-Version: 4.0")
			.append(System.lineSeparator())
			.append("{\"error\":{\"code\":\"\",\"message\":\"Authorization has been denied for this request.\"}}")
			.append(System.lineSeparator()).append("--batchresponse_f4fca79b-085a-4e4f-b608-096e0616f9ae--");

		return buffer.toString();

	}	

	

	private static String getLeviBulkResponse() {
		
		/*
		{
		    "response_id": "b38a169e-f5f6-4ac5-95d4-1caea5e74906",
		    "error": null,
		    "took": 8031,
		    "s3_bucket": "levi-marketplaces",
		    "s3_prefix": "inventory/inv_bulk_response_2018_11_29_11_38.json",
		    "requestedItemCount": 8,
		    "responseItemCount": 6
		}*/
		String response = "{\"response_id\":\"b38a169e-f5f6-4ac5-95d4-1caea5e74906\","
				+ "\"error\":null,\"took\":8031,\"s3_bucket\":\"levi-marketplaces\","
				+ "\"s3_prefix\":\"inventory/inv_bulk_response_2018_11_29_11_38.json\",\"requestedItemCount\":8,\"responseItemCount\":6}";
		return response;
	}
}
