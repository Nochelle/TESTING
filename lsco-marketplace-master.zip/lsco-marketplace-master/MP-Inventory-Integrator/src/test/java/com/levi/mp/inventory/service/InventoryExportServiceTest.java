package com.levi.mp.inventory.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.levi.mp.inventory.InventoryTestConfig;
import com.levi.mp.inventory.config.DynamoDBConfig;
import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.dao.DynamoDBInventoryAdapter;
import com.levi.mp.inventory.dao.InventoryDao;
import com.levi.mp.inventory.dao.SpringJdbcConfigHelper;
import com.levi.mp.inventory.model.db.Product;
import com.levi.mp.inventory.model.json.Config;
import com.levi.mp.inventory.rest.client.InventoryRestClientAdapter;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = InventoryTestConfig.class)
public class InventoryExportServiceTest {

	@MockBean
	InventoryIntegratorConfiguration inventoryConfig;
	
	@MockBean
	SpringJdbcConfigHelper springJdbcConfigHelper;
	
	@MockBean
	DynamoDBConfig dynamoDBConfig;

	@MockBean
	InventoryRestClientAdapter inventoryRestClientAdapter;

	@MockBean
	ChannelAdvisorTokenService channelAdvisorTokenService;

	@MockBean
	DynamoDBInventoryAdapter dynamoDBInventoryAdapter;
	
	@MockBean
	InventoryDao inventoryDao;

	@Autowired
	InventoryExportService inventoryExportService;

	final static Config config = new Config();
	final static String dummyCAToken = "DummyAccessToken";
	final static String s3Bucket = "S3Bucket";
	final static String s3Folder = "S3Folder";
	final static String mpInvReqFileName = "request";
	final static String mpInvReqFileExt = ".json";
	final static Map<String,Integer> dummyInventoryData = new HashMap<>();
	final static List<Product> productList = new ArrayList<>();

	@BeforeClass
	public static void setUp() {
		createInventoryIntegratorConfig();
		getDummyInventoryData();
		createInventoryIntegratorConfig();
		createMockProducts();
	}

	@Test
	public void testInventoryUpdateHandleRequest() {

		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		Mockito.when(inventoryDao.getInventoryData()).thenReturn(dummyInventoryData);
		
		/*Mockito.when(inventoryRestClientAdapter.getInventoryBulkResponse(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getLeviBulkResponse());*/
		Mockito.when(dynamoDBInventoryAdapter.scanProductsTable()).thenReturn(productList);
		
		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(dummyCAToken);
		Mockito.when(inventoryRestClientAdapter.updateProductsInCA(Mockito.any(), Mockito.anyString()))
				.thenReturn(getMockResponseForUpdateCAProducts());

		inventoryExportService.handleServiceRequest();
	}
	
	@Test(expected=RuntimeException.class)
	public void testInventoryUpdateHandleRequest_NoData_From_Redshift() {

		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		Mockito.when(inventoryDao.getInventoryData()).thenReturn(new HashMap<String, Integer>());
		
		inventoryExportService.handleServiceRequest();
	}
	
	
	@Test(expected=RuntimeException.class)
	public void testInventoryUpdateHandleRequest_NoData_From_DynamoDB() {

		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		Mockito.when(inventoryDao.getInventoryData()).thenReturn(dummyInventoryData);
		Mockito.when(dynamoDBInventoryAdapter.scanProductsTable()).thenReturn(new ArrayList<Product>());
		
		inventoryExportService.handleServiceRequest();
	}
	
	
	@Test
	public void testInventoryUpdateHandleRequest_SomeDataFromDynamo_WithNo_PC13() {

		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		Mockito.when(inventoryDao.getInventoryData()).thenReturn(dummyInventoryData);
		
		/*Mockito.when(inventoryRestClientAdapter.getInventoryBulkResponse(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getLeviBulkResponse());*/
		Mockito.when(dynamoDBInventoryAdapter.scanProductsTable()).thenReturn(getMockProductsWithNoPC13s());
		
		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(dummyCAToken);
		Mockito.when(inventoryRestClientAdapter.updateProductsInCA(Mockito.any(), Mockito.anyString()))
				.thenReturn(getMockResponse2ForUpdateCAProducts());

		inventoryExportService.handleServiceRequest();
	}
	
	
	private static List<Product> getMockProductsWithNoPC13s() {
		List<Product> productList = new ArrayList<>();
		
		productList.add(Product.builder().ca_id("58193").region_code("US").build());
		productList.add(Product.builder().ca_id("58194").pc_13("0002667700230S").region_code("US").build());
		productList.add(Product.builder().ca_id("58195").pc_13("0002981300140L").region_code("US").build());
		productList.add(Product.builder().ca_id("58196").pc_13("0002981499140L").region_code("US").build());
		
		return productList;
	}
	
	private static void createMockProducts() {
		productList.add(Product.builder().ca_id("58193").pc_13("0001789500340M").region_code("US").build());
		productList.add(Product.builder().ca_id("58194").pc_13("0002667700230S").region_code("US").build());
		productList.add(Product.builder().ca_id("58195").pc_13("0002981300140L").region_code("US").build());
		productList.add(Product.builder().ca_id("58196").pc_13("0002981499140L").region_code("US").build());
	}
	
	private static void createInventoryIntegratorConfig() {

		config.setCAEndpointV1("");
		config.setCAProductResourcePath("");
		
		config.setCABatchPostItemsLimit(100);
		config.setRedShiftJdbcDriverClassName("com.amazon.redshift.jdbc.Driver");
		config.setRedShiftJdbcUrl("jdbc:redshift://10.249.63.2:5439/knowmedm?ssl=true&sslfactory=com.amazon.redshift.ssl.NonValidatingFactory");
		config.setRedShiftJdbcUsername("Dummy_USER");
		config.setRedShiftJdbcPassword("DUMMY_PASSWORD");
	}

	private static String getLeviBulkResponse() {

		/*
		 * { "response_id": "b38a169e-f5f6-4ac5-95d4-1caea5e74906", "error": null,
		 * "took": 8031, "s3_bucket": "levi-marketplaces", "s3_prefix":
		 * "inventory/inv_bulk_response_2018_11_29_11_38.json", "requestedItemCount": 8,
		 * "responseItemCount": 6 }
		 */
		String response = "{\"response_id\":\"b38a169e-f5f6-4ac5-95d4-1caea5e74906\","
				+ "\"error\":null,\"took\":8031,\"s3_bucket\":\"levi-marketplaces\","
				+ "\"s3_prefix\":\"inventory/inv_bulk_response.json\",\"requestedItemCount\":8,\"responseItemCount\":6}";
		return response;
	}

	private static Map<String, List<String>> getMockResponseForUpdateCAProducts() {

		Map<String, List<String>> dataMap = new HashMap<>();
		List<String> successful_pc13s = new ArrayList<>();
		List<String> unsuccessful_pc13s = new ArrayList<>();

		/*successful_pc13s.add("00501196303430");
		successful_pc13s.add("00501245503434");
		successful_pc13s.add("00501230203430");

		unsuccessful_pc13s.add("00505021603834");
		unsuccessful_pc13s.add("00501225602930");
		unsuccessful_pc13s.add("04511092502830");*/
		
		successful_pc13s.add("0001789500340M");
		successful_pc13s.add("0002667700230S");

		unsuccessful_pc13s.add("0002981300140L");	

		dataMap.put("success", successful_pc13s);
		dataMap.put("fail", unsuccessful_pc13s);

		return dataMap;
	}
	
	
	private static Map<String, List<String>> getMockResponse2ForUpdateCAProducts() {

		Map<String, List<String>> dataMap = new HashMap<>();
		List<String> successful_pc13s = new ArrayList<>();
		List<String> unsuccessful_pc13s = new ArrayList<>();

		/*successful_pc13s.add("00501196303430");
		successful_pc13s.add("00501245503434");
		successful_pc13s.add("00501230203430");

		unsuccessful_pc13s.add("00505021603834");
		unsuccessful_pc13s.add("00501225602930");
		unsuccessful_pc13s.add("04511092502830");*/
		
		successful_pc13s.add("0002667700230S");

		unsuccessful_pc13s.add("0002981300140L");	

		dataMap.put("success", successful_pc13s);
		dataMap.put("fail", unsuccessful_pc13s);

		return dataMap;
	}

	private static void getDummyInventoryData() {

		dummyInventoryData.put("3996400110M", 0);
		
		dummyInventoryData.put("0001789500340M", 351);
		dummyInventoryData.put("0002667700230S", 0);
		dummyInventoryData.put("0002981300140L", 2);
		dummyInventoryData.put("0003462400010S", 0);
		dummyInventoryData.put("0003579300070M", 21);

		dummyInventoryData.put("0003613700020S", 15);
		dummyInventoryData.put("0006581602390L", 344);
		dummyInventoryData.put("0006582403390S", 15);
		dummyInventoryData.put("002667700310XL", 0);
		dummyInventoryData.put("00349630006024", 0);
		dummyInventoryData.put("00349640004024", 0);
		dummyInventoryData.put("00501019303232", 0);

		dummyInventoryData.put("00501019304232", 23);
		dummyInventoryData.put("00501066003836", 122);
		dummyInventoryData.put("00501196303430", 118);
		dummyInventoryData.put("00501225602930", 0);
		dummyInventoryData.put("00501230203430", 0);
		dummyInventoryData.put("00501245503434", 263);
		dummyInventoryData.put("00501248202932", 118);


	}

}