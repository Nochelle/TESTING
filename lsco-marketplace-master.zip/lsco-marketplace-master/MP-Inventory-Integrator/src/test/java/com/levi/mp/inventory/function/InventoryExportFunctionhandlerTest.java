package com.levi.mp.inventory.function;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class InventoryExportFunctionhandlerTest {
	
	private static Object input;

	@BeforeClass
    public static void createInput() throws IOException {
        // TODO: set up your sample input object here.
        input = "{\"operation\":\"inventory_update\"}";
    }
	
	@Test
	@Ignore
	public void testInventoryExportFunctionHandler() throws JsonParseException, JsonMappingException, IOException {
		Context context = createContext();
		
		
		InventoryLambdaFunctionhandler handler = new InventoryLambdaFunctionhandler();
		
		handler.handleRequest(new ByteArrayInputStream(input.toString().getBytes()), new ByteArrayOutputStream(),context);
		
	}

	
	private Context createContext() {
		return new TestContext();
	}
}
