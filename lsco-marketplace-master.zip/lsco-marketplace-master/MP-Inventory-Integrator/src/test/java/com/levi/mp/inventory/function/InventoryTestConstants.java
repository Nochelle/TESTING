package com.levi.mp.inventory.function;

public interface InventoryTestConstants {

	public static final String DYNAMODB_SERVICE_ENDPOINT = "https://dynamodb.us-west-2.amazonaws.com";
	public static final String DYNAMODB_SIGNING_REGION = "us-west-2";
	public static final String MARKETPLACE_DB_TABLENAME = "MP_PRODUCTS";

	public static final String MARKETPLACE_S3_ENDPOINT = "https://s3.us-west-2.amazonaws.com";
	public static final String MARKETPLACE_S3_BUCKET = "levi-marketplaces";
	public static final String MARKETPLACE_S3_FOLDER = "inventory";
	public static final String MARKETPLACE_S3_INV_REQ_FILENAME = "request";
	public static final String MARKETPLACE_S3_INV_REQ_FILEEXTENSION = ".json";

	// public static final String MARKETPLACE_S3_DOWNLOAD_FILENAME =
	// "inv_bulk_request_test.json";
	public static final String MARKETPLACE_S3_DOWNLOAD_FILENAME = "inv_bulk_response_2018_11_22_14_25.json";

	public static final String DEFAULT_REGION = "US";
	public static final String DEFAULT_STORE_ID = "1";

	public static final String CA_ENDPOINT_V1 = "https://api.channeladvisor.com/v1";
	public static final String CA_PRODUCT_PATH = "Products";

	public static final String CA_BATCH_PATH = "$batch";

	public static final Integer CA_BATCH_POST_ITEMS_LIMIT = 100;

	public static final String LEVI_INVENTORY_ENDPOINT_V1 = "https://qa-api.levi-site.com/inventory/v1";
	public static final String LEVI_INVENTORY_BULK_PATH = "bulk";

}
