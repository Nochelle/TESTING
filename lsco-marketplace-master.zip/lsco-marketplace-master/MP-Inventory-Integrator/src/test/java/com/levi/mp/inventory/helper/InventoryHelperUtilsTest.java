package com.levi.mp.inventory.helper;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.levi.mp.inventory.model.db.Product;
import com.levi.mp.inventory.model.json.CAProduct;
import com.levi.mp.inventory.model.json.CAProducts;
import com.levi.mp.inventory.model.json.Config;

public class InventoryHelperUtilsTest {

	final static List<Product> products = new ArrayList<>();
	final static Config config = new Config();
	final static CAProducts caProducts = new CAProducts();
	
	
	@BeforeClass
	public static void setUp() {
		
		createMockListofProducts();
		createMockConfig();
		createMockCAProducts();
	}
	
	
	@Test
	@Ignore //Ignoring as of of now, since we are not using it at the moment.
	public void readFileTest_Success() {
		String filePath = this.getClass().getClassLoader().getResource("products.json").toString();
		if(filePath.startsWith("file:/")) {
			filePath = filePath.substring(6);//Windows and MAC issue. For MAC need a / at beginning
		}
		String content = InventoryHelperUtils.readFile(filePath);
		
		Assert.assertNotNull(content);
		Assert.assertNotEquals("", content);
	}
	
	
	
	@Test
	public void testGetListFromJson_Success() {
		
		List<Map<String, String>> result = 
				InventoryHelperUtils.getListFromJson(createMockInventoryBulkResponse());
		Assert.assertNotNull(result);
		Assert.assertEquals(2, result.size());
	}
	
	@Test
	public void testGetListFromJson_Error() {
		
		List<Map<String, String>> result = 
				InventoryHelperUtils.getListFromJson(createMockInvalidInventoryBulkResponse());
		Assert.assertNull(result);
	}
	
	
	@Test
	public void testGetMapFromJson_Success() {
		
		Map<String, String> result = 
				InventoryHelperUtils.getMapFromJson(createMockMapJsonData());
		Assert.assertNotNull(result);
		Assert.assertEquals(4, result.size());
	}
	
	@Test
	public void testGetMapFromJson_Error() {
		
		Map<String, String> result = 
				InventoryHelperUtils.getMapFromJson(createMockInvalidMapJsonData());
		Assert.assertNull(result);
	}
	
	
	@Test
	public void testgetMapFromJsonInputStream_Success() {
		Map<String, String> result = 
				InventoryHelperUtils.getMapFromJson(this.getClass().getClassLoader().getResourceAsStream("inventory_integrator_config_dev.json"));
		Assert.assertNotNull(result);
	}
	
	@Test
	public void testgetMapFromJsonInputStream_Error() {
		Map<String, String> result = 
				InventoryHelperUtils.getMapFromJson(new ByteArrayInputStream("ABC".getBytes()));
		Assert.assertNull(result);
	}
	
	
	
	@Test
	public void testPartition() {
		List<String> listofString = new ArrayList<>();
		listofString.add("A");
		listofString.add("B");
		listofString.add("C");
		listofString.add("D");
		listofString.add("E");
		
		Collection<List<String>> collection = InventoryHelperUtils.partition(listofString, 2);
		
		Assert.assertNotNull(collection);
		Assert.assertEquals(3, collection.size());
		
		
	}
	
	@Test
	public void testGetProductsListFromCAProducts() {
		List<Product> productList = InventoryHelperUtils.getProductsListFromCAProducts(caProducts, config);
		Assert.assertNotNull(productList);
		Assert.assertNotEquals(0, productList.size());
	}
	
	@Test
	public void testConstructLeviInventoryBulkRequestBody() {
		String response = InventoryHelperUtils.constructLeviInventoryBulkRequestBody("S3Bucket", "S3Prefix");
		Assert.assertNotNull(response);
	}
	
	private static String createMockInventoryBulkResponse() {
		String invBulkResponse = 
			"[{\"pc_13\":\"00501225602930\",\"available_qty\":1000,\"display_qty\":1000,\"display_status\":\"In Stock\"},"
			+ "{\"pc_13\":\"00501245503434\",\"available_qty\":15,\"display_qty\":15,\"display_status\":\"In Stock\"}]";
		return invBulkResponse;
	}
	
	private static String createMockInvalidInventoryBulkResponse() {
		String invBulkResponse = 
			"[\"pc_13\":\"00501225602930\",\"available_qty\":1000,\"display_qty\":1000,\"display_status\":\"In Stock\"},"
			+ "{\"pc_13\":\"00501245503434\",\"available_qty\":15,\"display_qty\":15,\"display_status\":\"In Stock\"}]";
		return invBulkResponse;
	}
	
	private static String createMockMapJsonData() {
		String mapJsonData = "{\"pc_13\":\"00501225602930\",\"available_qty\":1000,"
				+ "\"display_qty\":1000,\"display_status\":\"In Stock\"}";
		return mapJsonData;
	}
	
	private static String createMockInvalidMapJsonData() {
		String mapJsonData = "[{\"pc_13\":\"00501225602930\",\"available_qty\":1000,"
				+ "\"display_qty\":1000,\"display_status\":\"In Stock\"}]";
		return mapJsonData;
	}
	
	
	private static void createMockListofProducts() {

		Product product = Product.builder().ca_id("45664").pc_13("00501196303430").region_code("US").build();
		products.add(product);

	}
	
	private static void createMockConfig() {
		config.setDefaultRegionCode("US");
	}
	
	private static void createMockCAProducts() {
		List<CAProduct> caProductList = new ArrayList<>();
		
		CAProduct caProduct = new CAProduct();
		caProduct.setSku("00501225602930");
		caProduct.setProductId("45664");
		
		caProductList.add(caProduct);
		caProducts.setCaProduct(caProductList);
		
	}
}
