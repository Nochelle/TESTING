package com.levi.mp.inventory;

import org.springframework.context.annotation.ComponentScan;

/**
 * @author Vinay A. Jain
 *
 */
@ComponentScan(basePackages = { "com.levi.mp" })
public class InventoryTestConfig {

}
