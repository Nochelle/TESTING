package com.levi.mp.inventory.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.levi.mp.inventory.InventoryTestConfig;
import com.levi.mp.inventory.config.DynamoDBConfig;
import com.levi.mp.inventory.config.InventoryIntegratorConfiguration;
import com.levi.mp.inventory.dao.DynamoDBInventoryAdapter;
import com.levi.mp.inventory.dao.SpringJdbcConfigHelper;
import com.levi.mp.inventory.model.db.Product;
import com.levi.mp.inventory.model.json.CAProduct;
import com.levi.mp.inventory.model.json.CAProducts;
import com.levi.mp.inventory.model.json.Config;
import com.levi.mp.inventory.rest.client.InventoryRestClientAdapter;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = InventoryTestConfig.class)
public class ProductImportServiceTest {

	@MockBean
	InventoryIntegratorConfiguration inventoryConfig;

	@MockBean
	InventoryRestClientAdapter inventoryRestClientAdapter;

	@MockBean
	SpringJdbcConfigHelper springJdbcConfigHelper;
	
	@MockBean
	DynamoDBConfig dynamoDBConfig;

	@MockBean
	ChannelAdvisorTokenService channelAdvisorTokenService;

	@MockBean
	DynamoDBInventoryAdapter dynamoDBInventoryAdapter;

	@Autowired
	ProductImportService productImportService;

	final static List<Product> products = new ArrayList<>();
	final static CAProducts caProducts = new CAProducts();
	final static CAProducts caProductsWithNextData = new CAProducts();
	final static List<CAProduct> value = new ArrayList<>();
	static final Config config = new Config();

	final static String dummyCAToken = "DummyAccessToken";
	final static String s3Bucket = "S3Bucket";
	final static String s3Key = "S3Key";

	@BeforeClass
	public static void setUp() {
		createMockListofProducts();
		createMockCAProducts();
		createInventoryIntegratorConfig();
		createMockCAProductsWithNextDataLink();
	}

	@Test
	public void testImportServiceHandleRequest_Success() {

		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(dummyCAToken);
		Mockito.when(inventoryRestClientAdapter.getProductsFromCA(Mockito.anyString())).thenReturn(caProductsWithNextData);

		// Mockito.when(dynamoDBInventoryAdapter.saveProducts(Mockito.any()))
		Mockito.doNothing().when(dynamoDBInventoryAdapter).saveProducts(Mockito.any());
		Mockito.doNothing().when(dynamoDBInventoryAdapter).deleteTable(Mockito.anyString());
		Mockito.doNothing().when(dynamoDBInventoryAdapter).createTable(Mockito.anyString());

		Mockito.when(inventoryRestClientAdapter.getNextProductsFromCA(Mockito.anyString(), Mockito.anyString())).thenReturn(caProducts);
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);

		productImportService.handleServiceRequest();

	}

	@Test(expected = RuntimeException.class)
	public void testImportServiceHandleRequest_SaveError() {

		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(dummyCAToken);
		Mockito.when(inventoryRestClientAdapter.getProductsFromCA(Mockito.anyString())).thenReturn(caProducts);
		Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
		//Mockito.when(dynamoDBInventoryAdapter.saveProducts(Mockito.any())).thenThrow(new RuntimeException("Exception occurred when fetching products from CA"));
		Mockito.doNothing().when(dynamoDBInventoryAdapter).deleteTable(Mockito.anyString());
		Mockito.doNothing().when(dynamoDBInventoryAdapter).createTable(Mockito.anyString());
		Mockito.doThrow(new RuntimeException("Save error"))
		.doNothing().when(dynamoDBInventoryAdapter).saveProducts(Mockito.any());
		
		productImportService.handleServiceRequest();

	}

	@Test(expected = RuntimeException.class)
	public void testImportServiceHandleRequest_NoRecordsFromCA() {

		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(dummyCAToken);
		Mockito.doNothing().when(dynamoDBInventoryAdapter).deleteTable(Mockito.anyString());
		Mockito.doNothing().when(dynamoDBInventoryAdapter).createTable(Mockito.anyString());
		Mockito.when(inventoryRestClientAdapter.getProductsFromCA(Mockito.anyString())).thenReturn(new CAProducts());

		productImportService.handleServiceRequest();

	}

	/*
	 * @Test(expected=RuntimeException.class) public void testImportServiceHandleRequest_NoRecordsFromDB() {
	 * 
	 * Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(dummyCAToken);
	 * Mockito.when(inventoryRestClientAdapter.getProductsFromCA(Mockito.anyString())) .thenReturn(caProducts);
	 * Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
	 * Mockito.when(dynamoDBInventoryAdapter.saveProducts(Mockito.any())) .thenReturn(Boolean.TRUE);
	 * Mockito.when(dynamoDBInventoryAdapter.fetchProducts(Mockito.any())) .thenReturn(new ArrayList<Product>());
	 * 
	 * productImportService.handleServiceRequest();
	 * 
	 * }
	 */

	/*
	 * @Test(expected=RuntimeException.class) public void testImportServiceHandleRequest_S3UploadFailure() {
	 * 
	 * Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(dummyCAToken);
	 * Mockito.when(inventoryRestClientAdapter.getProductsFromCA(Mockito.anyString())) .thenReturn(caProducts);
	 * Mockito.when(dynamoDBInventoryAdapter.saveProducts(Mockito.any())) .thenReturn(Boolean.TRUE);
	 * Mockito.when(dynamoDBInventoryAdapter.fetchProducts(Mockito.any())) .thenReturn(products);
	 * Mockito.when(inventoryConfig.getConfig()).thenReturn(config);
	 * Mockito.when(S3Adapter.uploadFile(Mockito.anyString(), Mockito.anyString(),
	 * Mockito.any(File.class))).thenReturn(Boolean.FALSE);
	 * 
	 * productImportService.handleServiceRequest();
	 * 
	 * }
	 */

	private static void createMockCAProducts() {

		CAProduct caProduct = new CAProduct();
		caProduct.setProductId("45664");
		caProduct.setSku("00501196303430");

		value.add(caProduct);

		caProducts.setCaProduct(value);

	}

	private static void createMockCAProductsWithNextDataLink() {

		CAProduct caProduct = new CAProduct();
		caProduct.setProductId("45664");
		caProduct.setSku("00501196303430");

		value.add(caProduct);

		caProductsWithNextData.setCaProduct(value);
		caProductsWithNextData.setOdataNextLink("dummy link");
	}

	private static void createMockListofProducts() {

		Product product = Product.builder().ca_id("45664").pc_13("00501196303430").region_code("US").build();
		products.add(product);

	}

	private static void createInventoryIntegratorConfig() {

		config.setCAEndpointV1("");
		config.setCAProductResourcePath("");
		
		config.setDefaultRegionCode("US");
		config.setCABatchPostItemsLimit(100);
	}

}
