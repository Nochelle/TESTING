package com.levi.mp.shared.ca.util.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
public class ServiceNowInfo {
	@JsonProperty("source")
	private final String source = "lambda_java";
	
	@JsonProperty("application_nm")
	private final String applicationName = "marketplaces";
	
	@JsonProperty("severity")
	private String severity;
	
	@JsonProperty("batch_run_start_dttm")
	private String batchRunStartDttm;
	
	@JsonProperty("batch_run_end_dttm")
	private String batchRunEndDttm;
	
	@JsonProperty("batch_run_status_cd")
	private final String batchRunStatusCd = "failed";
	
	@JsonProperty("job_orchestration_id")
	private final String jobOrchestrationId = "NA";
	
	@JsonProperty("stage_nm")
	private final String stageNm = "NA";
	
	@JsonProperty("stage_start_dttm")
	private final String stageStartDttm = "";
	
	@JsonProperty("stage_end_dttm")
	private final String stageEndEttm = "";
	
	@JsonProperty("stage_status_cd")
	private final String stageStatusCd =  "";
	
	@JsonProperty("job_run_id")
	private final String jobRunId = "NA";
	
	@JsonProperty("source_nm")
	private final String sourceNm =  "NA";
	
	@JsonProperty("target_nm")
	private final String targetNm = "NA";
	
	@JsonProperty("source_details")
	private final String sourceDetails = "NA";
	
	@JsonProperty("target_details")
	private final String targetDetails = "NA";
	
	@JsonProperty("msg")
	private String msg;
	
	@JsonProperty("counts")
	private final String counts = "0";
	
	@JsonProperty("notes")
	private final String notes = "marketplacesupport";
	
	
}
