package com.levi.mp.shared.ca.util;

import java.nio.charset.Charset;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import lombok.extern.log4j.Log4j2;

/**
 * This class provides methods to encrypt and decrypt data based on DESede
 * Algorithm. It assumes the secret key used to encrypt and decrypt data is a
 * base64 encoded string.
 * 
 * @author adhar@levi.com
 *
 */
@Log4j2
public class MPCipher {

	private static final String CRYPTOGRAPHY_ALGO_DESede = "DESede";

	private static DESedeKeySpec keySpec = null;
	private static SecretKeyFactory keyFactory = null;
	private static Cipher cipher = null;

	static {
		try {
			cipher = Cipher.getInstance(CRYPTOGRAPHY_ALGO_DESede);

		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
			log.error("Could not initialize Cipher instance!");
		}
	}

	/**
	 * Method to encrypt data
	 * 
	 * @param dataToEncrypt
	 * @param commonKey
	 * @return encoded data
	 * @throws Exception
	 */
	public static String encrypt(String dataToEncrypt, String base64EncodedCommonKey) throws Exception {
		if (cipher == null) {
			throw new Exception("Could not initialize Cipher instance!");
		}

		String base64DecodedCommonKey = new String(Base64.getDecoder().decode(base64EncodedCommonKey), "UTF8");

		// Initialize cipher
		cipher.init(Cipher.ENCRYPT_MODE, getSecretKey(base64DecodedCommonKey));

		// Encrypt
		byte[] encodedData = cipher.doFinal(dataToEncrypt.getBytes(Charset.forName("UTF8")));

		// Encode bytes to base64 to get a string
		return Base64.getEncoder().encodeToString(encodedData);

	}

	/**
	 * Method to decrypt data
	 * 
	 * @param dataToDecrypt
	 * @param base64EncodedCommonKey
	 * @return decoded data
	 * @throws Exception
	 */
	public static String decrypt(String dataToDecrypt, String base64EncodedCommonKey) throws Exception {
		if (cipher == null) {
			throw new Exception("Could not initialize Cipher instance!");
		}

		String base64DecodedCommonKey = new String(Base64.getDecoder().decode(base64EncodedCommonKey), "UTF8");

		// Decode base64 to get bytes
		byte[] dataToDecode = Base64.getDecoder().decode(dataToDecrypt);

		// Initialize cipher
		cipher.init(Cipher.DECRYPT_MODE, getSecretKey(base64DecodedCommonKey));

		byte[] decodedData = cipher.doFinal(dataToDecode);

		return new String(decodedData, Charset.forName("UTF8"));

	}

	/**
	 * Get {@code SecretKey}
	 * 
	 * @param secretPassword
	 * @return
	 */
	private static SecretKey getSecretKey(String secretPassword) throws Exception {

		keySpec = new DESedeKeySpec(secretPassword.getBytes("UTF8"));
		keyFactory = SecretKeyFactory.getInstance(CRYPTOGRAPHY_ALGO_DESede);
		SecretKey key = keyFactory.generateSecret(keySpec);

		return key;
	}

}
