package com.levi.mp.shared.ca.util;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.sns.AmazonSNS;

import lombok.extern.log4j.Log4j2;

/**
 * 
 * @author Prabir Nandi
 *
 */
@Log4j2
@Component
public class MPSharedUtil {
	
	@Autowired
	S3Adapter s3Adapter;
	
	@Autowired
	AmazonSNS amazonSNS;

	/**
	 * Read the config file from s3 bucket and return values as json string format
	 * 
	 * @param propertiesFileName
	 * @return
	 * @throws Exception
	 */
	public String getConfigValues(String propertiesFileName) {
		try {
			final String bucketName = System.getenv("bucket_name"); //"levi-marketplaces";
			AmazonS3 s3Client = s3Adapter.getS3Client();

			S3Object s3Object = s3Client.getObject(bucketName, propertiesFileName);
			InputStream is = s3Object.getObjectContent();
			String responseString = StreamUtils.copyToString(is, StandardCharsets.UTF_8);
			
			log.debug("Loaded config properties file:" + propertiesFileName);
			
			//Commenting to remove logging of resposneString as it contains sensitive information
			//log.debug("For config properties file: " + propertiesFileName + ",retrieved the following contents: \n" + responseString);
			return responseString;
		} catch (Exception e) {
			throw new RuntimeException("Error while getting configuration details from S3 config file: " + propertiesFileName, e);
		}
	}
	
	/**
	 * Get current timestamp in specified timeZone and datetime format
	 * 
	 * @param timeZone
	 * @param format
	 * @return
	 */
	public String getCurrentDateTime(String timeZone, String format) {
		DateFormat formatter = new SimpleDateFormat(format);
		formatter.setTimeZone(TimeZone.getTimeZone(timeZone));
		return formatter.format(new Date());
	}

	

}