package com.levi.mp.shared.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;

/**
 * This class provides the configuration for AWS SNS
 * 
 * @author adhar@levi.com
 *
 */
@Configuration
public class SNSConfig {

	@Bean
	public AmazonSNS getAmazonSNS() {
		return AmazonSNSClientBuilder.standard()
				.withEndpointConfiguration(
						new AwsClientBuilder.EndpointConfiguration(
								"https://sns.us-west-2.amazonaws.com/", Regions.US_WEST_2.getName()
								)
						)
				.build();

	}

}
