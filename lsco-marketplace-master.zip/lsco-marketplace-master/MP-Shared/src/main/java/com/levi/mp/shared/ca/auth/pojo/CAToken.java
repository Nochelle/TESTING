/**
 * 
 */
package com.levi.mp.shared.ca.auth.pojo;

import lombok.Data;

/**
 * @author Vinay A. Jain
 *
 */
@Data
public class CAToken {
	private String access_token;
	private String token_type;
	private int expires_in;
}
