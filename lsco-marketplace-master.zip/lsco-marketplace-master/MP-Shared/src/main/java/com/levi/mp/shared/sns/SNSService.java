package com.levi.mp.shared.sns;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.shared.ca.util.MPSharedUtil;
import com.levi.mp.shared.ca.util.pojo.MPSharedConfig;
import com.levi.mp.shared.ca.util.pojo.ServiceNowInfo;

import lombok.extern.log4j.Log4j2;

/**
 * This class provides AWS SNS Services
 * 
 * @author adhar@levi.com
 *
 */
@Log4j2
@Service
public class SNSService {

	@Autowired
	AmazonSNS snsClient;

	@Autowired
	MPSharedUtil mpSharedUtil;

	private String notifySupportTopicARN;
	
	private String serviceNowTopicARN;
	
	private String serviceNowTktPriority;

	/**
	 * Retrieve topic ARN from config file in S3
	 * 
	 * @return
	 */
	private String getNotifySupportTopicARN() {

		// Retrieve topic ARN only if not already fetched
		if (notifySupportTopicARN == null || serviceNowTopicARN == null) {
			log.debug("Fetching notify support and serivenow topic ARN from S3...");
			// get config values from s3
			String propertiesFileName = "shared/mp_shared_config_props.json";
			MPSharedConfig config = null;

			try {
				String jsonString = mpSharedUtil.getConfigValues(propertiesFileName);
				config = new ObjectMapper().readValue(jsonString, MPSharedConfig.class);

				if (StringUtils.isEmpty(config.getNotifySupportTopicARN())
						|| StringUtils.isEmpty(config.getSerivceNowTopicARN())) {
					throw new RuntimeException(
							"MP shared properties are not properly defined for NotifySupportTopicARN or SerivceNowTopicARN");
				}
				notifySupportTopicARN = config.getNotifySupportTopicARN();
				serviceNowTopicARN = config.getSerivceNowTopicARN();
				//default serviceNowTktPriority = 2
				serviceNowTktPriority = config.getSerivceNowTktPriority()!=null?config.getSerivceNowTktPriority():"2";
				
				log.debug("Successfully fetched Notify support & SerivceNowTopicARN topic ARN: " + notifySupportTopicARN + ", "+ serviceNowTopicARN);
			} catch (Exception e) {
				throw new RuntimeException("Error occurred while fetching config for MP-Shared", e);
			}

		}

		// return the already fetched topic ARN
		return notifySupportTopicARN;
	}

	/**
	 * send a message to SNS topic
	 * 
	 * @param notifySupportTopicArn
	 * @param message
	 * @param subject
	 * @return
	 */
	public boolean notifySupport(String message, String subject) {
		
		try {

			// Call the method to ensure topic ARN is set
			if (getNotifySupportTopicARN() == null) {
				throw new RuntimeException("Notify Support Topic ARN could not be fetched!");
			}
			
			String dateTime = " " + mpSharedUtil.getCurrentDateTime("PST", "MMdd_HHmm") + ": ";
			
			if(StringUtils.isEmpty(subject)) {
				subject = "<No Subject found> "+dateTime;
			}else if(subject.contains("]:")){
				subject = new StringBuffer(subject).insert(subject.indexOf("]:")+2, dateTime).toString();
			}else {
				subject = dateTime + subject;
			}
			
			// trim down to 100 as SNS does not support more than 100 character in email
			subject = subject.length()>100?subject.substring(0,100):subject;
			
			log.debug("Notify Support subject>>>"+subject);

			PublishRequest publishRequest = new PublishRequest(notifySupportTopicARN, message, subject);
			PublishResult publishResult = snsClient.publish(publishRequest);

			// print MessageId of message published to SNS topic
			log.debug(
					"Published message on MP-NotifySupport SNS topic with MessageId - " + publishResult.getMessageId());
			
			//send message to Service Now topic to create a service now ticket
			sendMsgServiceNowTopic(message, subject);
			
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error("[" + notifySupportTopicARN + "]: Exception occurred while notifying support!",e);
			return Boolean.FALSE;
		}
	}

	/**
	 * send a message to Service Now SNS topic so that a Service Now will be created for Support Team
	 * @param message
	 * @param subject
	 */
	public void sendMsgServiceNowTopic(String message, String subject) {
		try {
			String currentDateTime = mpSharedUtil.getCurrentDateTime("PST", "yyyy-MM-dd HH:mm:ss");
			
			String msg = subject;
			/*if(!StringUtils.isEmpty(subject) && subject.contains(":")) {
				//msg = subject.substring(0, subject.indexOf(":")) +" - "+message;
				//msg = "Test Message.Please Ignore." +subject.substring(0, subject.indexOf(":")) +" - "+message;
			}*/
			
			ServiceNowInfo serviceNowInfo = ServiceNowInfo.builder()
												.severity(serviceNowTktPriority)
												.batchRunStartDttm(currentDateTime)
												.batchRunEndDttm(currentDateTime)
												.msg(msg).build();
			
			String serviceNowInfoStr = new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(serviceNowInfo);
			
			log.debug("message body to service now topic>>>"+serviceNowInfoStr);
			PublishRequest publishRequest = new PublishRequest(serviceNowTopicARN, serviceNowInfoStr, subject);
			PublishResult publishResult = snsClient.publish(publishRequest);

			// print MessageId of message published to SNS topic
			log.debug(
					"Published message on Service Now TopicARN SNS topic with MessageId - " + publishResult.getMessageId());
			
		} catch (Exception e) {
			throw new RuntimeException("Exception while sending message to ServiceNowTopic "+serviceNowTopicARN);
		}
	}

}
