package com.levi.mp.shared.ca.util.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class MPSharedConfig {
	@JsonProperty("AUTH_CA_APPLICATION_ID")
	private String caApplicationID;
	@JsonProperty("AUTH_CA_SHARED_SECRET")
	private String caSharedSecret;
	@JsonProperty("AUTH_REFRESH_TOKEN")
	private String caRefreshToken;
	@JsonProperty("NOTIFY_SUPPORT_TOPIC_ARN")
	private String notifySupportTopicARN;
	@JsonProperty("CREATE_SNOW_TICKET_TOPIC_ARN")
	private String serivceNowTopicARN;
	@JsonProperty("CREATE_SNOW_TICKET_PRIORITY")
	private String serivceNowTktPriority;
	
}
