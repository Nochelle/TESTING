package com.levi.mp.shared.ca.auth;

import java.nio.charset.Charset;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.shared.ca.auth.pojo.CAToken;
import com.levi.mp.shared.ca.util.MPSharedUtil;
import com.levi.mp.shared.ca.util.pojo.MPSharedConfig;

import lombok.extern.log4j.Log4j2;

/**
 * Implementation for fetching ChannelAdvisor's oauth token.
 * 
 * @author Vinay A. Jain
 *
 */
@Component
@Log4j2
public class ChannelAdvisorTokenService {

	public String getOAuth2Token() {
		final String AUTH_TOKEN_URL = "https://api.channeladvisor.com/oauth2/token";

		// get config values from s3
		String propertiesFileName = "shared/mp_shared_config_props.json";
		MPSharedConfig config = null;

		try {
			log.debug("mpSharedUtil = " + mpSharedUtil);
			String jsonString = mpSharedUtil.getConfigValues(propertiesFileName);
			config = new ObjectMapper().readValue(jsonString, MPSharedConfig.class);
			//log.debug("config=" + config);
			if (StringUtils.isEmpty(config.getCaApplicationID()) || StringUtils.isEmpty(config.getCaSharedSecret())
					|| StringUtils.isEmpty(config.getCaRefreshToken())) {
				throw new RuntimeException("MP shared properties are not properly defined for ApplicationID, SharedSecret and/or RefreshToken");
			}
		} catch (Exception e) {
			// log.error("Error occurred while fetching config for MP-Shared", e);
			// e.printStackTrace();
			throw new RuntimeException("Error occurred while fetching config for MP-Shared", e);
		}

		// setup header
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		String auth = config.getCaApplicationID() + ":" + config.getCaSharedSecret();
		byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic " + new String(encodedAuth);
		headers.set("Authorization", authHeader); // set basic auth in header

		// form data
		MultiValueMap<String, String> requestMap = new LinkedMultiValueMap<>();
		requestMap.add("grant_type", "refresh_token");
		requestMap.add("refresh_token", config.getCaRefreshToken());

		// make the rest call
		HttpEntity<MultiValueMap<String, String>> httEntityRequest = new HttpEntity<>(requestMap, headers);
		ResponseEntity<CAToken> restResponse = restTemplate.postForEntity(AUTH_TOKEN_URL, httEntityRequest, CAToken.class);

		//check rest call status
		if (!restResponse.getStatusCode().equals(HttpStatus.OK)) {
			throw new RuntimeException("Error occurred while fetching auth token from Channel Advisor");
		}

		CAToken caToken = restResponse.getBody();
		//Commenting to remove logging which contains sensitive information
		//log.debug("Response token: " + caToken);

		if (StringUtils.isEmpty(caToken.getAccess_token())) {
			throw new RuntimeException("Access token recevied from CA is null/empty!");
		}
		
		log.debug("Successfully received Access Token from CA.");

		return caToken.getAccess_token();
	}

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private MPSharedUtil mpSharedUtil;
}
