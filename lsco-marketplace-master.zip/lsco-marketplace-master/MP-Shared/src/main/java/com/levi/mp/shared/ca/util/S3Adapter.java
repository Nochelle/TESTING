package com.levi.mp.shared.ca.util;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Component;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.event.ProgressEvent;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.s3.transfer.Upload;

import lombok.extern.log4j.Log4j2;

/**
 * 
 * S3 Adapter for performing AWS S3 operations
 *
 */
@Log4j2
@Component
public class S3Adapter {

	private final AmazonS3 s3client;
	private final TransferManager transferManager;

	//private final static S3Adapter adapter = new S3Adapter();
	private final static String s3url = "https://s3.us-west-2.amazonaws.com";
	private final static String s3Region = Regions.US_WEST_2.getName();

	public S3Adapter() {
		s3client = AmazonS3ClientBuilder.standard().withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(s3url, s3Region)).build();
		transferManager = TransferManagerBuilder.standard().withS3Client(s3client).build();
	}

	/*public static S3Adapter getInstance() {
		return adapter;
	}*/

	public AmazonS3 getS3Client() {
		return s3client;
	}

	/**
	 * Method to upload file in AWS S3
	 * 
	 * @param bucketName
	 * @param keyName
	 * @param file
	 * @return status of file upload
	 */
	public boolean uploadFile(String bucketName, String keyName, File file) {

		try {
			Upload upload = transferManager.upload(bucketName, keyName, file);
			upload.addProgressListener(new ProgressListener() {

				@Override
				public void progressChanged(ProgressEvent progressEvent) {

					log.debug("Bytes transferred: " + progressEvent.getBytesTransferred());
				}
			});
			upload.waitForCompletion();
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error("Exception occurred while uploading file: " + file.getAbsolutePath() + " to S3 ", e);
		}
		return Boolean.FALSE;

	}

	/**
	 * Method to download file from AWS S3
	 * 
	 * @param bucketName
	 * @param keyName
	 * @return the downloaded file
	 */
	public File downloadFile(String bucketName, String keyName) {

		try {
			File file  = File.createTempFile("inv_bulk", ".json");
			
			Download download = transferManager.download(bucketName, keyName, file);

			download.addProgressListener(new ProgressListener() {

				@Override
				public void progressChanged(ProgressEvent progressEvent) {

					log.debug("Bytes transferred: " + progressEvent.getBytesTransferred());
				}
			});
			download.waitForCompletion();
			
			return file;
		} catch (Exception e) {
			log.error("Exception occurred while downloading file: " + keyName + " to S3 ", e);
		}
		return null;

	}

}
