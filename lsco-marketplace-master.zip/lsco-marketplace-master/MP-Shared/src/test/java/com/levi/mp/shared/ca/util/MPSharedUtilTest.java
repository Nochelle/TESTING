package com.levi.mp.shared.ca.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;

/**
 * @author Prabir Nandi
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class MPSharedUtilTest {

	@InjectMocks
	MPSharedUtil mpSharedUtil;
	
	@Mock
	AmazonS3 s3Client; 
	
	@Mock
	S3Object s3Object; 
	
	@Mock
	S3Adapter s3Adaptor;
	
	@Mock
	RestTemplate restTemplate;
	
	

	@Test
	public void getConfigValuesTest_HappyPath() throws Exception {
		String key="shared/mp_shared.json";
		try {
			String mockProperties = "{\"AUTH_CA_APPLICATION_ID\":\"1234\",\"AUTH_CA_SHARED_SECRET\":\"abcd\",\"AUTH_REFRESH_TOKEN\":\"klmn\"}";
			InputStream inputStream = new ByteArrayInputStream(mockProperties.getBytes());
			S3ObjectInputStream objectInputStream = new S3ObjectInputStream(inputStream, null);
			
			when(s3Adaptor.getS3Client()).thenReturn(s3Client);
			
			when(s3Client.getObject(ArgumentMatchers.any(), ArgumentMatchers.anyString())).thenReturn(s3Object);
			
			when(s3Object.getObjectContent()).thenReturn(objectInputStream);
			
			String jsonString = mpSharedUtil.getConfigValues(key);
			assertNotNull("Response jsonString is null", jsonString);
			assertTrue("No value found from s3 config file", !jsonString.isEmpty());

		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}
	
	@Test
	public void getConfigValuesTest_Error() throws Exception {
		String key="shared/mp_shared.json";
		try {
			
			when(s3Adaptor.getS3Client()).thenReturn(null);
			
			String jsonString = mpSharedUtil.getConfigValues(key);
			assertNotNull("Response jsonString null", jsonString);
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}

	//@Test
	public void notifySupportTest() throws Exception {
		MPSharedUtil mpSharedUtil = new MPSharedUtil();

//		try {
//			//TODO: **Mockito**
//			Boolean successFlag = mpSharedUtil.notifySupport("this is a test message. Prabir");
//			assertNotNull("Success Flag is null", successFlag);
//			assertTrue("Message not successfully sent to SNS", successFlag);
//
//		} catch (Exception e) {
//			log.error("Exception>>>" + e);
//			assertTrue(e.getMessage(), e.getMessage().isEmpty());
//		}
	}
	
	@Test
	public void getCurrentDateTimeTest_HappyPath() {
		String timeZone="IST";
		String dateFormat = "yyyyMMdd_HHmmss";
		
		try {
			String convertedDate  = mpSharedUtil.getCurrentDateTime(timeZone, dateFormat);
			System.out.println("Current time in("+timeZone+"):"+convertedDate);
			assertNotNull("converted current Date is null", convertedDate);
			assertTrue("converted current Date is enpty", !convertedDate.isEmpty());
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void getCurrentDateTimeTest_Error() {
		String timeZone="PST";
		String dateFormat = "PNZyyyyMMdd_HHmmss";
		
		String convertedDate  = mpSharedUtil.getCurrentDateTime(timeZone, dateFormat);
		System.out.println("Current time in("+timeZone+"):"+convertedDate);
	
	}
}
