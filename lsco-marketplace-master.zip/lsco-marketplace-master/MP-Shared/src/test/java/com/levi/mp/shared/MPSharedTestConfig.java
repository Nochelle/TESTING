package com.levi.mp.shared;

import org.springframework.context.annotation.ComponentScan;

/**
 * Spring boot package loader
 * 
 * @author Vinay A. Jain
 *
 */

@ComponentScan(basePackages = { "com.levi.mp" })
public class MPSharedTestConfig {
}
