/**
 * @author Vinay Jain
 */
package com.levi.mp.shared.ca.auth;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.levi.mp.shared.MPSharedTestConfig;
import com.levi.mp.shared.ca.auth.pojo.CAToken;
import com.levi.mp.shared.ca.util.MPSharedUtil;

/**
 * @author Vinay Jain
 *
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MPSharedTestConfig.class)

public class ChannelAdvisorTokenServiceTest {

	@MockBean
	MPSharedUtil mpSharedUtil;

	@MockBean
	RestTemplate restTemplate;

	@Autowired
	private ChannelAdvisorTokenService caTokenService;

	@Test
	public void getOAuth2TokenTest_HappyPath() {
		final String dummyJsonConfigString = "{" + "\"AUTH_CA_APPLICATION_ID\":\"mockApplicationId\", "
				+ "\"AUTH_CA_SHARED_SECRET\":\"mockSharedSecret\", " + "\"AUTH_REFRESH_TOKEN\":\"mockRefreshToken\"" + "}";
		when(mpSharedUtil.getConfigValues(Mockito.anyString())).thenReturn(dummyJsonConfigString);

		CAToken mockCAToken = new CAToken();
		mockCAToken.setAccess_token("mockAccessToken");
		ResponseEntity<Object> mockRestResponse = ResponseEntity.ok(mockCAToken);
		when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(mockRestResponse);

		String tok = caTokenService.getOAuth2Token();
		assertNotNull("CA Token is null", tok);
		assertTrue("No token value found from ChannelAdvisor", !tok.isEmpty());
	}

	@Test
	public void getOAuth2TokenTest_MalformedPropsLoad() {
		final String malformedJsonConfigString = "{" + "\"ABC\":\"id\", " + "\"DEF\":\"secret\", " + "\"GHI\":\"token\"" + "}";
		when(mpSharedUtil.getConfigValues(Mockito.anyString())).thenReturn(malformedJsonConfigString);

		// inconsequential - it shouldn't reach restTemplate call in the method
		when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(null);

		try {
			caTokenService.getOAuth2Token();
		} catch (RuntimeException e) {
			assertTrue("Expected Runtime exception error message not found!", e.getMessage() != null);
			return;
		}
		assertTrue("Expected MP Shared config reader to fail for malformed props file but it did not!", true == false);
	}

	@Test
	public void getOAuth2TokenTest_MissingCaApplicationID_FromPropertiesFile() {
		final String missingApplicationIDJsonConfigString = "{" + "\"AUTH_CA_SHARED_SECRET\":\"mockSharedSecret\", "
				+ "\"AUTH_REFRESH_TOKEN\":\"mockRefreshToken\"" + "}"; // missing props
		when(mpSharedUtil.getConfigValues(Mockito.anyString())).thenReturn(missingApplicationIDJsonConfigString);

		// inconsequential - it shouldn't reach restTemplate call in the method
		when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(null);

		try {
			caTokenService.getOAuth2Token();
		} catch (RuntimeException e) {
			assertTrue("Expected Runtime exception error message not found!", e.getMessage() != null);
			return;
		}
		assertTrue("Expected MP Shared config reader to fail for missing ApplicationID from props file but it did not!", true == false);
	}

	@Test
	public void getOAuth2TokenTest_MissingCaSecret_FromPropertiesFile() {
		final String missingSharedSecretJsonConfigString = "{\"AUTH_CA_APPLICATION_ID\":\"mockApplicationId\", "
				+ "\"AUTH_REFRESH_TOKEN\":\"mockRefreshToken\"}"; // missing props
		when(mpSharedUtil.getConfigValues(Mockito.anyString())).thenReturn(missingSharedSecretJsonConfigString);

		// inconsequential - it shouldn't reach restTemplate call in the method
		when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(null);

		try {
			caTokenService.getOAuth2Token();
		} catch (RuntimeException e) {
			assertTrue("Expected Runtime exception error message not found!", e.getMessage() != null);
			return;
		}
		assertTrue("Expected MP Shared config reader to fail for missing Shared Secret from props file but it did not!", true == false);
	}

	@Test
	public void getOAuth2TokenTest_MissingRefreshToken_FromPropertiesFile() {
		final String missingRefreshTokenJsonConfigString = "{" + "\"AUTH_CA_APPLICATION_ID\":\"mockApplicationId\", "
				+ "\"AUTH_CA_SHARED_SECRET\":\"mockSharedSecret\" " + "}"; // missing props
		when(mpSharedUtil.getConfigValues(Mockito.anyString())).thenReturn(missingRefreshTokenJsonConfigString);

		// inconsequential - it shouldn't reach restTemplate call in the method
		when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(null);

		try {
			caTokenService.getOAuth2Token();
		} catch (RuntimeException e) {
			assertTrue("Expected Runtime exception error message not found!", e.getMessage() != null);
			return;
		}
		assertTrue("Expected MP Shared config reader to fail for missing RefreshToken from props file but it did not!", true == false);
	}

	@Test
	public void getOAuth2TokenTest_NonSuccessCodeFromCAcall() {
		final String dummyJsonConfigString = "{" + "\"AUTH_CA_APPLICATION_ID\":\"mockApplicationId\", "
				+ "\"AUTH_CA_SHARED_SECRET\":\"mockSharedSecret\", " + "\"AUTH_REFRESH_TOKEN\":\"mockRefreshToken\"" + "}";
		when(mpSharedUtil.getConfigValues(Mockito.anyString())).thenReturn(dummyJsonConfigString);

		CAToken mockCAToken = new CAToken();
		mockCAToken.setAccess_token("mockAccessToken");
		ResponseEntity<Object> mockRestResponse = new ResponseEntity<>(mockCAToken, HttpStatus.BAD_REQUEST);
		when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(mockRestResponse);

		try {
			String tok = caTokenService.getOAuth2Token();
			assertNull("CA Token is not null when expected to be null", tok);
			assertTrue("Token value found from ChannelAdvisor when expected to not be found", tok.isEmpty());
		} catch (RuntimeException rte) {
			assertTrue("Expected Runtime exception error message not found!", rte.getMessage() != null);
			return;
		}
		assertTrue("Expected getOAuth2Token() to fail due to non-HttpStatus.OK response but it did not!", true == false);
	}

	@Test
	public void getOAuth2TokenTest_EmptyAccessTokenFromCAcall() {
		final String dummyJsonConfigString = "{" + "\"AUTH_CA_APPLICATION_ID\":\"mockApplicationId\", "
				+ "\"AUTH_CA_SHARED_SECRET\":\"mockSharedSecret\", " + "\"AUTH_REFRESH_TOKEN\":\"mockRefreshToken\"" + "}";
		when(mpSharedUtil.getConfigValues(Mockito.anyString())).thenReturn(dummyJsonConfigString);

		CAToken mockCAToken = new CAToken();
		mockCAToken.setAccess_token(""); // empty access_token to test for failure scenario
		ResponseEntity<Object> mockRestResponse = ResponseEntity.ok(mockCAToken);
		when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(mockRestResponse);

		try {
			String tok = caTokenService.getOAuth2Token();
		} catch (RuntimeException e) {
			assertTrue("Expected Runtime exception error message not found!", e.getMessage() != null);
			return;
		}
		assertTrue("Token value found from ChannelAdvisor when expected not to!", true == false);
	}
}
