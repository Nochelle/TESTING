package com.levi.mp.shared.ca.util;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class MPCipherTest {
	
	//This will come from configuration file in S3
	public static final String base64EncodedCommonKey = "ZG9uJ3QgdGVsbCB0aGlzIHRvIGFueW9uZSBwbHMhISE=";
	//commonKey="don't tell this to anyone pls!!!"
	//The bits for this key has to be in power of 2.

	@Test
	public void encryptDecryptTest() {
		try {
			String password = "Password123";
			//String base64EncodedCommonKey = Base64.getEncoder().encodeToString(commonKey.getBytes("UTF8"));

			String encryptedPassword = MPCipher.encrypt(password, base64EncodedCommonKey);

			Assert.assertNotNull(encryptedPassword);

			String decryptedPassword = MPCipher.decrypt(encryptedPassword, base64EncodedCommonKey);

			Assert.assertNotNull(decryptedPassword);

			Assert.assertEquals(password, decryptedPassword);

		} catch (Exception e) {
			Assert.assertFalse(e.getMessage() != null);
		}

	}

}
