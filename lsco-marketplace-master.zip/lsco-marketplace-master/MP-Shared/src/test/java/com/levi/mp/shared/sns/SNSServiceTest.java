package com.levi.mp.shared.sns;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.levi.mp.shared.MPSharedTestConfig;
import com.levi.mp.shared.ca.util.MPSharedUtil;

/**
 * Unit test class for {@code SNSService}
 * 
 * @author adhar@levi.com
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MPSharedTestConfig.class)
public class SNSServiceTest {

	@MockBean
	AmazonSNS amazonSNS;

	@MockBean
	PublishResult publishResult;
	
	@MockBean
	MPSharedUtil mpSharedUtil;
	
	@MockBean
	RestTemplate restTemplate;

	@Autowired
	SNSService snsService;

	@Test
	public void notifySupportTest_Success() {

		try {
			String fileContent = getFileContent("mp_shared_config_props.json");
			Mockito.when(mpSharedUtil.getConfigValues(Mockito.anyString()))
				.thenReturn(fileContent);
			
			Mockito.when(mpSharedUtil.getCurrentDateTime(Mockito.anyString(), Mockito.anyString()))
			.thenReturn("0201_1630");
			
			publishResult.setMessageId("DUMMY_MESSAGE_ID");

			Mockito.when(amazonSNS.publish(Mockito.any(PublishRequest.class))).thenReturn(publishResult);
			
			boolean result = snsService.notifySupport("sample message", "[MP-OrderImport]:Invalid Site ID: 587 pksnmnbvcxzasdfghjklpoiuytrewqa12345678pn0mnbvcxzasdfgh");
			assertTrue(result);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.assertFalse(e.getMessage() != null);
		}

	}
	
	
	
	
	private String getFileContent(String fileName) throws IOException{
		
		String os = System.getProperty("os.name");
		String filePath = SNSServiceTest.class.getClassLoader().getResource(fileName).toString();//Cancel_Ship_Order_Status.xml Cancel_FB_1.xml
		if (filePath.startsWith("file:/")) {
			
			// Windows and MAC issue. For MAC need a / at beginning
			if(!StringUtils.isEmpty(os)) {
				if(os.indexOf("win")>=0 || os.indexOf("Win")>=0) {
					filePath = filePath.substring(6);
				}else if(os.indexOf("mac")>=0 || os.indexOf("Mac")>=0) {
					filePath = filePath.substring(5);
				}else {
					//Not handling at the moment
				}
			}
			
		}
		return readFile(filePath);
	}
	
	
	/**
	 * Method to get the String content of a file
	 * 
	 * @param absoulteFileName
	 * @return the String content of the file
	 */
	private String readFile(String absoulteFileName)throws IOException {

		try (Stream<String> stream = Files.lines(Paths.get(absoulteFileName), StandardCharsets.ISO_8859_1)) {
			StringBuffer fileContent = new StringBuffer();
			stream.forEach(str -> fileContent.append(str));

			return fileContent.toString();
		} catch (IOException e) {
			throw e;
		}
	}

}
