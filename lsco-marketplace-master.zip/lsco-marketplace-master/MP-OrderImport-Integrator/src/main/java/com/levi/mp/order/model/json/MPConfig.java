package com.levi.mp.order.model.json;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "FREE_RETURN", "SMART_LABEL_FEE" })
public class MPConfig {
	@JsonProperty("FREE_RETURN")
	private boolean freeReturn;
	@JsonProperty("SMART_LABEL_FEE")
	private BigDecimal smartLabelFee;
}
