package com.levi.mp.order.model.json;

public class GoogleConfig extends MPConfig {
	
}
