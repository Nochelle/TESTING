package com.levi.mp.order.model.json;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Component
@JsonIgnoreProperties(ignoreUnknown = true)
// @JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ProfileID", "SiteOrderID", "SiteID", "SiteName",
		"TotalPrice", "TotalTaxPrice", "TotalShippingPrice",
		"TotalShippingTaxPrice", "EstimatedShipDateUtc", "CheckoutStatus",
		"PaymentStatus", "ShippingStatus", "BuyerUserId", "BuyerEmailAddress",
		"PaymentMethod", "PaymentCreditCardLast4",
		"PaymentMerchantReferenceNumber", "ShippingTitle", "ShippingFirstName",
		"ShippingLastName", "ShippingSuffix", "ShippingCompanyName",
		"ShippingCompanyJobTitle", "ShippingDaytimePhone",
		"ShippingEveningPhone", "ShippingAddressLine1", "ShippingAddressLine2",
		"ShippingCity", "ShippingStateOrProvince", "ShippingPostalCode",
		"ShippingCountry", "BillingTitle", "BillingFirstName",
		"BillingLastName", "BillingSuffix", "BillingCompanyName",
		"BillingCompanyJobTitle", "BillingDaytimePhone", "BillingEveningPhone",
		"BillingAddressLine1", "BillingAddressLine2", "BillingCity",
		"BillingStateOrProvince", "BillingPostalCode", "BillingCountry",
		"Items"

})
@Data
// public class UpdateSchemaForOrderCreate implements Serializable
public class UpdateSchemaForOrderCreate {

	@JsonProperty("ProfileID")
	private long profileID;

	@JsonProperty("SiteOrderID")
	private String siteOrderID;

	@JsonProperty("SiteID")
	private long siteID;

	@JsonProperty("SiteName")
	private String siteName;

	@JsonProperty("TotalPrice")
	private Double totalPrice;

	@JsonProperty("TotalTaxPrice")
	private Double totalTaxPrice;

	@JsonProperty("TotalShippingPrice")
	private Double totalShippingPrice;

	@JsonProperty("TotalShippingTaxPrice")
	private Double totalShippingTaxPrice;

	@JsonProperty("EstimatedShipDateUtc")
	private String estimatedShipDateUtc;

	@JsonProperty("CheckoutStatus")
	private String checkoutStatus;

	@JsonProperty("PaymentStatus")
	private String paymentStatus;

	@JsonProperty("ShippingStatus")
	private String shippingStatus;

	@JsonProperty("BuyerUserId")
	private String buyerUserId;

	@JsonProperty("BuyerEmailAddress")
	private String buyerEmailAddress;

	@JsonProperty("PaymentMethod")
	private String paymentMethod;

	@JsonProperty("PaymentCreditCardLast4")
	private String paymentCreditCardLast4;

	@JsonProperty("PaymentMerchantReferenceNumber")
	private String paymentMerchantReferenceNumber;

	@JsonProperty("ShippingTitle")
	private String shippingTitle;

	@JsonProperty("ShippingFirstName")
	private String shippingFirstName;

	@JsonProperty("ShippingLastName")
	private String shippingLastName;

	@JsonProperty("ShippingSuffix")
	private Object shippingSuffix;

	@JsonProperty("ShippingCompanyName")
	private Object shippingCompanyName;

	@JsonProperty("ShippingCompanyJobTitle")
	private Object shippingCompanyJobTitle;

	@JsonProperty("ShippingDaytimePhone")
	private String shippingDaytimePhone;

	@JsonProperty("ShippingEveningPhone")
	private Object shippingEveningPhone;

	@JsonProperty("ShippingAddressLine1")
	private String shippingAddressLine1;

	@JsonProperty("ShippingAddressLine2")
	private String shippingAddressLine2;

	@JsonProperty("ShippingCity")
	private String shippingCity;

	@JsonProperty("ShippingStateOrProvince")
	private String shippingStateOrProvince;

	@JsonProperty("ShippingPostalCode")
	private String shippingPostalCode;

	@JsonProperty("ShippingCountry")
	private String shippingCountry;

	@JsonProperty("BillingTitle")
	private String billingTitle;

	@JsonProperty("BillingFirstName")
	private String billingFirstName;

	@JsonProperty("BillingLastName")
	private String billingLastName;

	@JsonProperty("BillingSuffix")
	private String billingSuffix;

	@JsonProperty("BillingCompanyName")
	private String billingCompanyName;

	@JsonProperty("BillingCompanyJobTitle")
	private Object billingCompanyJobTitle;

	@JsonProperty("BillingDaytimePhone")
	private String billingDaytimePhone;

	@JsonProperty("BillingEveningPhone")
	private Object billingEveningPhone;

	@JsonProperty("BillingAddressLine1")
	private String billingAddressLine1;

	@JsonProperty("BillingAddressLine2")
	private String billingAddressLine2;

	@JsonProperty("BillingCity")
	private String billingCity;

	@JsonProperty("BillingStateOrProvince")
	private String billingStateOrProvince;

	@JsonProperty("BillingPostalCode")
	private String billingPostalCode;

	@JsonProperty("BillingCountry")
	private String billingCountry;

	@JsonProperty("Items")
	private List<OrderItems> itemList;

}
