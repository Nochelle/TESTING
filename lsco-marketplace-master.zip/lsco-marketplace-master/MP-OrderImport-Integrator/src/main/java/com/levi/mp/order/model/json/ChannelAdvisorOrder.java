
package com.levi.mp.order.model.json;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Component
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "@odata.context", "ID", "ProfileID", "SiteID", "SiteName", "SiteOrderID", "SecondarySiteOrderID", "SellerOrderID",
		"CheckoutSourceID", "CreatedDateUtc", "ImportDateUtc", "PublicNotes", "PrivateNotes", "SpecialInstructions", "TotalPrice", "TotalTaxPrice",
		"TotalShippingPrice", "TotalShippingTaxPrice", "TotalInsurancePrice", "TotalGiftOptionPrice", "TotalGiftOptionTaxPrice",
		"AdditionalCostOrDiscount", "EstimatedShipDateUtc", "DeliverByDateUtc", "ResellerID", "FlagID", "FlagDescription", "OrderTags",
		"DistributionCenterTypeRollup", "CheckoutStatus", "PaymentStatus", "ShippingStatus", "CheckoutDateUtc", "PaymentDateUtc", "ShippingDateUtc",
		"BuyerUserId", "BuyerEmailAddress", "BuyerEmailOptIn", "OrderTaxType", "ShippingTaxType", "GiftOptionsTaxType", "PaymentMethod",
		"PaymentTransactionID", "PaymentPaypalAccountID", "PaymentCreditCardLast4", "PaymentMerchantReferenceNumber", "ShippingTitle",
		"ShippingFirstName", "ShippingLastName", "ShippingSuffix", "ShippingCompanyName", "ShippingCompanyJobTitle", "ShippingDaytimePhone",
		"ShippingEveningPhone", "ShippingAddressLine1", "ShippingAddressLine2", "ShippingCity", "ShippingStateOrProvince", "ShippingPostalCode",
		"ShippingCountry", "BillingTitle", "BillingFirstName", "BillingLastName", "BillingSuffix", "BillingCompanyName", "BillingCompanyJobTitle",
		"BillingDaytimePhone", "BillingEveningPhone", "BillingAddressLine1", "BillingAddressLine2", "BillingCity", "BillingStateOrProvince",
		"BillingPostalCode", "BillingCountry", "PromotionCode", "PromotionAmount", "Items", "Fulfillments" })
public class ChannelAdvisorOrder implements Serializable {

	@JsonProperty("@odata.context")
	private String odataContext;
	@JsonProperty("ID")
	private long iD;
	@JsonProperty("ProfileID")
	private long profileID;
	@JsonProperty("SiteID")
	private long siteID;
	@JsonProperty("SiteName")
	private String siteName;
	@JsonProperty("SiteAccountID")
	private String siteAccountID;
	@JsonProperty("SiteOrderID")
	private String siteOrderID;
	@JsonProperty("SecondarySiteOrderID")
	private Object secondarySiteOrderID;
	@JsonProperty("SellerOrderID")
	private Object sellerOrderID;
	@JsonProperty("CheckoutSourceID")
	private Object checkoutSourceID;
	@JsonProperty("CreatedDateUtc")
	private String createdDateUtc;
	@JsonProperty("ImportDateUtc")
	private String importDateUtc;
	@JsonProperty("PublicNotes")
	private Object publicNotes;
	@JsonProperty("PrivateNotes")
	private String privateNotes;
	@JsonProperty("SpecialInstructions")
	private String specialInstructions;
	@JsonProperty("TotalPrice")
	private BigDecimal totalPrice;
	@JsonProperty("TotalTaxPrice")
	private BigDecimal totalTaxPrice;
	@JsonProperty("TotalShippingPrice")
	private BigDecimal totalShippingPrice;
	@JsonProperty("TotalShippingTaxPrice")
	private BigDecimal totalShippingTaxPrice;
	@JsonProperty("TotalInsurancePrice")
	private BigDecimal totalInsurancePrice;
	@JsonProperty("TotalGiftOptionPrice")
	private BigDecimal totalGiftOptionPrice;
	@JsonProperty("TotalGiftOptionTaxPrice")
	private BigDecimal totalGiftOptionTaxPrice;
	@JsonProperty("AdditionalCostOrDiscount")
	private BigDecimal additionalCostOrDiscount;
	@JsonProperty("EstimatedShipDateUtc")
	private Object estimatedShipDateUtc;
	@JsonProperty("DeliverByDateUtc")
	private Object deliverByDateUtc;
	@JsonProperty("ResellerID")
	private Object resellerID;
	@JsonProperty("FlagID")
	private long flagID;
	@JsonProperty("FlagDescription")
	private Object flagDescription;
	@JsonProperty("OrderTags")
	private Object orderTags;
	@JsonProperty("DistributionCenterTypeRollup")
	private String distributionCenterTypeRollup;
	@JsonProperty("CheckoutStatus")
	private String checkoutStatus;
	@JsonProperty("PaymentStatus")
	private String paymentStatus;
	@JsonProperty("ShippingStatus")
	private String shippingStatus;
	@JsonProperty("CheckoutDateUtc")
	private String checkoutDateUtc;
	@JsonProperty("PaymentDateUtc")
	private String paymentDateUtc;
	@JsonProperty("ShippingDateUtc")
	private Object shippingDateUtc;
	@JsonProperty("BuyerUserId")
	private String buyerUserId;
	@JsonProperty("BuyerEmailAddress")
	private String buyerEmailAddress;
	@JsonProperty("BuyerEmailOptIn")
	private boolean buyerEmailOptIn;
	@JsonProperty("OrderTaxType")
	private String orderTaxType;
	@JsonProperty("ShippingTaxType")
	private String shippingTaxType;
	@JsonProperty("GiftOptionsTaxType")
	private String giftOptionsTaxType;
	@JsonProperty("PaymentMethod")
	private String paymentMethod;
	@JsonProperty("PaymentTransactionID")
	private Object paymentTransactionID;
	@JsonProperty("PaymentPaypalAccountID")
	private Object paymentPaypalAccountID;
	@JsonProperty("PaymentCreditCardLast4")
	private String paymentCreditCardLast4;
	@JsonProperty("PaymentMerchantReferenceNumber")
	private Object paymentMerchantReferenceNumber;
	@JsonProperty("ShippingTitle")
	private Object shippingTitle;
	@JsonProperty("ShippingFirstName")
	private String shippingFirstName;
	@JsonProperty("ShippingLastName")
	private String shippingLastName;
	@JsonProperty("ShippingSuffix")
	private Object shippingSuffix;
	@JsonProperty("ShippingCompanyName")
	private Object shippingCompanyName;
	@JsonProperty("ShippingCompanyJobTitle")
	private Object shippingCompanyJobTitle;
	@JsonProperty("ShippingDaytimePhone")
	private String shippingDaytimePhone;
	@JsonProperty("ShippingEveningPhone")
	private Object shippingEveningPhone;
	@JsonProperty("ShippingAddressLine1")
	private String shippingAddressLine1;
	@JsonProperty("ShippingAddressLine2")
	private String shippingAddressLine2;
	@JsonProperty("ShippingCity")
	private String shippingCity;
	@JsonProperty("ShippingStateOrProvince")
	private String shippingStateOrProvince;
	@JsonProperty("ShippingStateOrProvinceName")
	private String shippingStateOrProvinceName;
	@JsonProperty("ShippingPostalCode")
	private String shippingPostalCode;
	@JsonProperty("ShippingCountry")
	private String shippingCountry;
	@JsonProperty("BillingTitle")
	private Object billingTitle;
	@JsonProperty("BillingFirstName")
	private String billingFirstName;
	@JsonProperty("BillingLastName")
	private String billingLastName;
	@JsonProperty("BillingSuffix")
	private String billingSuffix;
	@JsonProperty("BillingCompanyName")
	private String billingCompanyName;
	@JsonProperty("BillingCompanyJobTitle")
	private Object billingCompanyJobTitle;
	@JsonProperty("BillingDaytimePhone")
	private String billingDaytimePhone;
	@JsonProperty("BillingEveningPhone")
	private Object billingEveningPhone;
	@JsonProperty("BillingAddressLine1")
	private String billingAddressLine1;
	@JsonProperty("BillingAddressLine2")
	private String billingAddressLine2;
	@JsonProperty("BillingCity")
	private String billingCity;
	@JsonProperty("BillingStateOrProvince")
	private String billingStateOrProvince;
	@JsonProperty("BillingPostalCode")
	private String billingPostalCode;
	@JsonProperty("BillingCountry")
	private String billingCountry;
	@JsonProperty("PromotionCode")
	private Object promotionCode;
	@JsonProperty("PromotionAmount")
	private long promotionAmount;
	@JsonProperty("Items")
	private List<Item> items = null;
	@JsonProperty("Fulfillments")
	private List<Fulfillment> fulfillments = null;
	private final static long serialVersionUID = -6298700789659378196L;

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public ChannelAdvisorOrder() {
	}

	/**
	 * 
	 * @param buyerUserId
	 * @param billingStateOrProvince
	 * @param promotionCode
	 * @param resellerID
	 * @param shippingCompanyJobTitle
	 * @param billingEveningPhone
	 * @param totalInsurancePrice
	 * @param flagDescription
	 * @param shippingCompanyName
	 * @param billingFirstName
	 * @param shippingDaytimePhone
	 * @param shippingSuffix
	 * @param checkoutStatus
	 * @param orderTaxType
	 * @param shippingFirstName
	 * @param billingLastName
	 * @param estimatedShipDateUtc
	 * @param additionalCostOrDiscount
	 * @param secondarySiteOrderID
	 * @param shippingStateOrProvince
	 * @param distributionCenterTypeRollup
	 * @param shippingPostalCode
	 * @param paymentStatus
	 * @param paymentDateUtc
	 * @param billingDaytimePhone
	 * @param iD
	 * @param billingAddressLine1
	 * @param billingAddressLine2
	 * @param shippingEveningPhone
	 * @param totalGiftOptionPrice
	 * @param items
	 * @param paymentPaypalAccountID
	 * @param checkoutSourceID
	 * @param checkoutDateUtc
	 * @param billingTitle
	 * @param shippingCountry
	 * @param shippingLastName
	 * @param shippingTaxType
	 * @param specialInstructions
	 * @param shippingDateUtc
	 * @param billingSuffix
	 * @param sellerOrderID
	 * @param buyerEmailAddress
	 * @param privateNotes
	 * @param totalShippingPrice
	 * @param createdDateUtc
	 * @param totalShippingTaxPrice
	 * @param siteID
	 * @param billingPostalCode
	 * @param paymentCreditCardLast4
	 * @param billingCity
	 * @param paymentTransactionID
	 * @param billingCountry
	 * @param billingCompanyJobTitle
	 * @param shippingTitle
	 * @param promotionAmount
	 * @param totalTaxPrice
	 * @param shippingStatus
	 * @param siteName
	 * @param totalPrice
	 * @param siteOrderID
	 * @param fulfillments
	 * @param importDateUtc
	 * @param publicNotes
	 * @param deliverByDateUtc
	 * @param totalGiftOptionTaxPrice
	 * @param odataContext
	 * @param buyerEmailOptIn
	 * @param paymentMerchantReferenceNumber
	 * @param flagID
	 * @param orderTags
	 * @param billingCompanyName
	 * @param profileID
	 * @param shippingAddressLine1
	 * @param giftOptionsTaxType
	 * @param shippingAddressLine2
	 * @param shippingCity
	 * @param paymentMethod
	 */
	public ChannelAdvisorOrder(String odataContext, long iD, long profileID, long siteID, String siteName, String siteOrderID,
			Object secondarySiteOrderID, Object sellerOrderID, Object checkoutSourceID, String createdDateUtc, String importDateUtc,
			Object publicNotes, String privateNotes, String specialInstructions, BigDecimal totalPrice, BigDecimal totalTaxPrice,
			BigDecimal totalShippingPrice, BigDecimal totalShippingTaxPrice, BigDecimal totalInsurancePrice, BigDecimal totalGiftOptionPrice,
			BigDecimal totalGiftOptionTaxPrice, BigDecimal additionalCostOrDiscount, Object estimatedShipDateUtc, Object deliverByDateUtc,
			Object resellerID, long flagID, Object flagDescription, Object orderTags, String distributionCenterTypeRollup, String checkoutStatus,
			String paymentStatus, String shippingStatus, String checkoutDateUtc, String paymentDateUtc, Object shippingDateUtc, String buyerUserId,
			String buyerEmailAddress, boolean buyerEmailOptIn, String orderTaxType, String shippingTaxType, String giftOptionsTaxType,
			String paymentMethod, Object paymentTransactionID, Object paymentPaypalAccountID, String paymentCreditCardLast4,
			Object paymentMerchantReferenceNumber, Object shippingTitle, String shippingFirstName, String shippingLastName, Object shippingSuffix,
			Object shippingCompanyName, Object shippingCompanyJobTitle, String shippingDaytimePhone, Object shippingEveningPhone,
			String shippingAddressLine1, String shippingAddressLine2, String shippingCity, String shippingStateOrProvince, String shippingPostalCode,
			String shippingCountry, Object billingTitle, String billingFirstName, String billingLastName, String billingSuffix,
			String billingCompanyName, Object billingCompanyJobTitle, String billingDaytimePhone, Object billingEveningPhone,
			String billingAddressLine1, String billingAddressLine2, String billingCity, String billingStateOrProvince, String billingPostalCode,
			String billingCountry, Object promotionCode, long promotionAmount, List<Item> items, List<Fulfillment> fulfillments) {
		super();
		this.odataContext = odataContext;
		this.iD = iD;
		this.profileID = profileID;
		this.siteID = siteID;
		this.siteName = siteName;
		this.siteOrderID = siteOrderID;
		this.secondarySiteOrderID = secondarySiteOrderID;
		this.sellerOrderID = sellerOrderID;
		this.checkoutSourceID = checkoutSourceID;
		this.createdDateUtc = createdDateUtc;
		this.importDateUtc = importDateUtc;
		this.publicNotes = publicNotes;
		this.privateNotes = privateNotes;
		this.specialInstructions = specialInstructions;
		this.totalPrice = totalPrice;
		this.totalTaxPrice = totalTaxPrice;
		this.totalShippingPrice = totalShippingPrice;
		this.totalShippingTaxPrice = totalShippingTaxPrice;
		this.totalInsurancePrice = totalInsurancePrice;
		this.totalGiftOptionPrice = totalGiftOptionPrice;
		this.totalGiftOptionTaxPrice = totalGiftOptionTaxPrice;
		this.additionalCostOrDiscount = additionalCostOrDiscount;
		this.estimatedShipDateUtc = estimatedShipDateUtc;
		this.deliverByDateUtc = deliverByDateUtc;
		this.resellerID = resellerID;
		this.flagID = flagID;
		this.flagDescription = flagDescription;
		this.orderTags = orderTags;
		this.distributionCenterTypeRollup = distributionCenterTypeRollup;
		this.checkoutStatus = checkoutStatus;
		this.paymentStatus = paymentStatus;
		this.shippingStatus = shippingStatus;
		this.checkoutDateUtc = checkoutDateUtc;
		this.paymentDateUtc = paymentDateUtc;
		this.shippingDateUtc = shippingDateUtc;
		this.buyerUserId = buyerUserId;
		this.buyerEmailAddress = buyerEmailAddress;
		this.buyerEmailOptIn = buyerEmailOptIn;
		this.orderTaxType = orderTaxType;
		this.shippingTaxType = shippingTaxType;
		this.giftOptionsTaxType = giftOptionsTaxType;
		this.paymentMethod = paymentMethod;
		this.paymentTransactionID = paymentTransactionID;
		this.paymentPaypalAccountID = paymentPaypalAccountID;
		this.paymentCreditCardLast4 = paymentCreditCardLast4;
		this.paymentMerchantReferenceNumber = paymentMerchantReferenceNumber;
		this.shippingTitle = shippingTitle;
		this.shippingFirstName = shippingFirstName;
		this.shippingLastName = shippingLastName;
		this.shippingSuffix = shippingSuffix;
		this.shippingCompanyName = shippingCompanyName;
		this.shippingCompanyJobTitle = shippingCompanyJobTitle;
		this.shippingDaytimePhone = shippingDaytimePhone;
		this.shippingEveningPhone = shippingEveningPhone;
		this.shippingAddressLine1 = shippingAddressLine1;
		this.shippingAddressLine2 = shippingAddressLine2;
		this.shippingCity = shippingCity;
		this.shippingStateOrProvince = shippingStateOrProvince;
		this.shippingPostalCode = shippingPostalCode;
		this.shippingCountry = shippingCountry;
		this.billingTitle = billingTitle;
		this.billingFirstName = billingFirstName;
		this.billingLastName = billingLastName;
		this.billingSuffix = billingSuffix;
		this.billingCompanyName = billingCompanyName;
		this.billingCompanyJobTitle = billingCompanyJobTitle;
		this.billingDaytimePhone = billingDaytimePhone;
		this.billingEveningPhone = billingEveningPhone;
		this.billingAddressLine1 = billingAddressLine1;
		this.billingAddressLine2 = billingAddressLine2;
		this.billingCity = billingCity;
		this.billingStateOrProvince = billingStateOrProvince;
		this.billingPostalCode = billingPostalCode;
		this.billingCountry = billingCountry;
		this.promotionCode = promotionCode;
		this.promotionAmount = promotionAmount;
		this.items = items;
		this.fulfillments = fulfillments;
	}

	@JsonProperty("SiteAccountID")
	public String getSiteAccountID() {
		return siteAccountID;
	}

	@JsonProperty("SiteAccountID")
	public void setSiteAccountID(String siteAccountID) {
		this.siteAccountID = siteAccountID;
	}

	@JsonProperty("@odata.context")
	public String getOdataContext() {
		return odataContext;
	}

	@JsonProperty("@odata.context")
	public void setOdataContext(String odataContext) {
		this.odataContext = odataContext;
	}

	@JsonProperty("ID")
	public long getID() {
		return iD;
	}

	@JsonProperty("ID")
	public void setID(long iD) {
		this.iD = iD;
	}

	@JsonProperty("ProfileID")
	public long getProfileID() {
		return profileID;
	}

	@JsonProperty("ProfileID")
	public void setProfileID(long profileID) {
		this.profileID = profileID;
	}

	@JsonProperty("SiteID")
	public long getSiteID() {
		return siteID;
	}

	@JsonProperty("SiteID")
	public void setSiteID(long siteID) {
		this.siteID = siteID;
	}

	@JsonProperty("SiteName")
	public String getSiteName() {
		return siteName;
	}

	@JsonProperty("SiteName")
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	@JsonProperty("SiteOrderID")
	public String getSiteOrderID() {
		return siteOrderID;
	}

	@JsonProperty("SiteOrderID")
	public void setSiteOrderID(String siteOrderID) {
		this.siteOrderID = siteOrderID;
	}

	@JsonProperty("SecondarySiteOrderID")
	public Object getSecondarySiteOrderID() {
		return secondarySiteOrderID;
	}

	@JsonProperty("SecondarySiteOrderID")
	public void setSecondarySiteOrderID(Object secondarySiteOrderID) {
		this.secondarySiteOrderID = secondarySiteOrderID;
	}

	@JsonProperty("SellerOrderID")
	public Object getSellerOrderID() {
		return sellerOrderID;
	}

	@JsonProperty("SellerOrderID")
	public void setSellerOrderID(Object sellerOrderID) {
		this.sellerOrderID = sellerOrderID;
	}

	@JsonProperty("CheckoutSourceID")
	public Object getCheckoutSourceID() {
		return checkoutSourceID;
	}

	@JsonProperty("CheckoutSourceID")
	public void setCheckoutSourceID(Object checkoutSourceID) {
		this.checkoutSourceID = checkoutSourceID;
	}

	@JsonProperty("CreatedDateUtc")
	public String getCreatedDateUtc() {
		return createdDateUtc;
	}

	@JsonProperty("CreatedDateUtc")
	public void setCreatedDateUtc(String createdDateUtc) {
		this.createdDateUtc = createdDateUtc;
	}

	@JsonProperty("ImportDateUtc")
	public String getImportDateUtc() {
		return importDateUtc;
	}

	@JsonProperty("ImportDateUtc")
	public void setImportDateUtc(String importDateUtc) {
		this.importDateUtc = importDateUtc;
	}

	@JsonProperty("PublicNotes")
	public Object getPublicNotes() {
		return publicNotes;
	}

	@JsonProperty("PublicNotes")
	public void setPublicNotes(Object publicNotes) {
		this.publicNotes = publicNotes;
	}

	@JsonProperty("PrivateNotes")
	public String getPrivateNotes() {
		return privateNotes;
	}

	@JsonProperty("PrivateNotes")
	public void setPrivateNotes(String privateNotes) {
		this.privateNotes = privateNotes;
	}

	@JsonProperty("SpecialInstructions")
	public String getSpecialInstructions() {
		return specialInstructions;
	}

	@JsonProperty("SpecialInstructions")
	public void setSpecialInstructions(String specialInstructions) {
		this.specialInstructions = specialInstructions;
	}

	@JsonProperty("TotalPrice")
	public BigDecimal getTotalPrice() {
		return totalPrice != null ? totalPrice : new BigDecimal("0.00");
	}

	@JsonProperty("TotalPrice")
	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	@JsonProperty("TotalTaxPrice")
	public BigDecimal getTotalTaxPrice() {
		return totalTaxPrice != null ? totalTaxPrice : new BigDecimal("0.00");
	}

	@JsonProperty("TotalTaxPrice")
	public void setTotalTaxPrice(BigDecimal totalTaxPrice) {
		this.totalTaxPrice = totalTaxPrice;
	}

	@JsonProperty("TotalShippingPrice")
	public BigDecimal getTotalShippingPrice() {
		return totalShippingPrice != null ? totalShippingPrice : new BigDecimal("0.00");
	}

	@JsonProperty("TotalShippingPrice")
	public void setTotalShippingPrice(BigDecimal totalShippingPrice) {
		this.totalShippingPrice = totalShippingPrice;
	}

	@JsonProperty("TotalShippingTaxPrice")
	public BigDecimal getTotalShippingTaxPrice() {
		return totalShippingTaxPrice != null ? totalShippingTaxPrice : new BigDecimal("0.00");
	}

	@JsonProperty("TotalShippingTaxPrice")
	public void setTotalShippingTaxPrice(BigDecimal totalShippingTaxPrice) {
		this.totalShippingTaxPrice = totalShippingTaxPrice;
	}

	@JsonProperty("TotalInsurancePrice")
	public BigDecimal getTotalInsurancePrice() {
		return totalInsurancePrice != null ? totalInsurancePrice : new BigDecimal("0.00");
	}

	@JsonProperty("TotalInsurancePrice")
	public void setTotalInsurancePrice(BigDecimal totalInsurancePrice) {
		this.totalInsurancePrice = totalInsurancePrice;
	}

	@JsonProperty("TotalGiftOptionPrice")
	public BigDecimal getTotalGiftOptionPrice() {
		return totalGiftOptionPrice != null ? totalGiftOptionPrice : new BigDecimal("0.00");
	}

	@JsonProperty("TotalGiftOptionPrice")
	public void setTotalGiftOptionPrice(BigDecimal totalGiftOptionPrice) {
		this.totalGiftOptionPrice = totalGiftOptionPrice;
	}

	@JsonProperty("TotalGiftOptionTaxPrice")
	public Object getTotalGiftOptionTaxPrice() {
		return totalGiftOptionTaxPrice != null ? totalGiftOptionTaxPrice : new BigDecimal("0.00");
	}

	@JsonProperty("TotalGiftOptionTaxPrice")
	public void setTotalGiftOptionTaxPrice(BigDecimal totalGiftOptionTaxPrice) {
		this.totalGiftOptionTaxPrice = totalGiftOptionTaxPrice;
	}

	@JsonProperty("AdditionalCostOrDiscount")
	public BigDecimal getAdditionalCostOrDiscount() {
		return additionalCostOrDiscount;
	}

	@JsonProperty("AdditionalCostOrDiscount")
	public void setAdditionalCostOrDiscount(BigDecimal additionalCostOrDiscount) {
		this.additionalCostOrDiscount = additionalCostOrDiscount;
	}

	@JsonProperty("EstimatedShipDateUtc")
	public Object getEstimatedShipDateUtc() {
		return estimatedShipDateUtc;
	}

	@JsonProperty("EstimatedShipDateUtc")
	public void setEstimatedShipDateUtc(Object estimatedShipDateUtc) {
		this.estimatedShipDateUtc = estimatedShipDateUtc;
	}

	@JsonProperty("DeliverByDateUtc")
	public Object getDeliverByDateUtc() {
		return deliverByDateUtc;
	}

	@JsonProperty("DeliverByDateUtc")
	public void setDeliverByDateUtc(Object deliverByDateUtc) {
		this.deliverByDateUtc = deliverByDateUtc;
	}

	@JsonProperty("ResellerID")
	public Object getResellerID() {
		return resellerID;
	}

	@JsonProperty("ResellerID")
	public void setResellerID(Object resellerID) {
		this.resellerID = resellerID;
	}

	@JsonProperty("FlagID")
	public long getFlagID() {
		return flagID;
	}

	@JsonProperty("FlagID")
	public void setFlagID(long flagID) {
		this.flagID = flagID;
	}

	@JsonProperty("FlagDescription")
	public Object getFlagDescription() {
		return flagDescription;
	}

	@JsonProperty("FlagDescription")
	public void setFlagDescription(Object flagDescription) {
		this.flagDescription = flagDescription;
	}

	@JsonProperty("OrderTags")
	public Object getOrderTags() {
		return orderTags;
	}

	@JsonProperty("OrderTags")
	public void setOrderTags(Object orderTags) {
		this.orderTags = orderTags;
	}

	@JsonProperty("DistributionCenterTypeRollup")
	public String getDistributionCenterTypeRollup() {
		return distributionCenterTypeRollup;
	}

	@JsonProperty("DistributionCenterTypeRollup")
	public void setDistributionCenterTypeRollup(String distributionCenterTypeRollup) {
		this.distributionCenterTypeRollup = distributionCenterTypeRollup;
	}

	@JsonProperty("CheckoutStatus")
	public String getCheckoutStatus() {
		return checkoutStatus;
	}

	@JsonProperty("CheckoutStatus")
	public void setCheckoutStatus(String checkoutStatus) {
		this.checkoutStatus = checkoutStatus;
	}

	@JsonProperty("PaymentStatus")
	public String getPaymentStatus() {
		return paymentStatus;
	}

	@JsonProperty("PaymentStatus")
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	@JsonProperty("ShippingStatus")
	public String getShippingStatus() {
		return shippingStatus;
	}

	@JsonProperty("ShippingStatus")
	public void setShippingStatus(String shippingStatus) {
		this.shippingStatus = shippingStatus;
	}

	@JsonProperty("CheckoutDateUtc")
	public String getCheckoutDateUtc() {
		return checkoutDateUtc;
	}

	@JsonProperty("CheckoutDateUtc")
	public void setCheckoutDateUtc(String checkoutDateUtc) {
		this.checkoutDateUtc = checkoutDateUtc;
	}

	@JsonProperty("PaymentDateUtc")
	public String getPaymentDateUtc() {
		return paymentDateUtc;
	}

	@JsonProperty("PaymentDateUtc")
	public void setPaymentDateUtc(String paymentDateUtc) {
		this.paymentDateUtc = paymentDateUtc;
	}

	@JsonProperty("ShippingDateUtc")
	public Object getShippingDateUtc() {
		return shippingDateUtc;
	}

	@JsonProperty("ShippingDateUtc")
	public void setShippingDateUtc(Object shippingDateUtc) {
		this.shippingDateUtc = shippingDateUtc;
	}

	@JsonProperty("BuyerUserId")
	public String getBuyerUserId() {
		return buyerUserId;
	}

	@JsonProperty("BuyerUserId")
	public void setBuyerUserId(String buyerUserId) {
		this.buyerUserId = buyerUserId;
	}

	@JsonProperty("BuyerEmailAddress")
	public String getBuyerEmailAddress() {
		return buyerEmailAddress;
	}

	@JsonProperty("BuyerEmailAddress")
	public void setBuyerEmailAddress(String buyerEmailAddress) {
		this.buyerEmailAddress = buyerEmailAddress;
	}

	@JsonProperty("BuyerEmailOptIn")
	public boolean isBuyerEmailOptIn() {
		return buyerEmailOptIn;
	}

	@JsonProperty("BuyerEmailOptIn")
	public void setBuyerEmailOptIn(boolean buyerEmailOptIn) {
		this.buyerEmailOptIn = buyerEmailOptIn;
	}

	@JsonProperty("OrderTaxType")
	public String getOrderTaxType() {
		return orderTaxType;
	}

	@JsonProperty("OrderTaxType")
	public void setOrderTaxType(String orderTaxType) {
		this.orderTaxType = orderTaxType;
	}

	@JsonProperty("ShippingTaxType")
	public String getShippingTaxType() {
		return shippingTaxType;
	}

	@JsonProperty("ShippingTaxType")
	public void setShippingTaxType(String shippingTaxType) {
		this.shippingTaxType = shippingTaxType;
	}

	@JsonProperty("GiftOptionsTaxType")
	public String getGiftOptionsTaxType() {
		return giftOptionsTaxType;
	}

	@JsonProperty("GiftOptionsTaxType")
	public void setGiftOptionsTaxType(String giftOptionsTaxType) {
		this.giftOptionsTaxType = giftOptionsTaxType;
	}

	@JsonProperty("PaymentMethod")
	public String getPaymentMethod() {
		return paymentMethod;
	}

	@JsonProperty("PaymentMethod")
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	@JsonProperty("PaymentTransactionID")
	public Object getPaymentTransactionID() {
		return paymentTransactionID;
	}

	@JsonProperty("PaymentTransactionID")
	public void setPaymentTransactionID(Object paymentTransactionID) {
		this.paymentTransactionID = paymentTransactionID;
	}

	@JsonProperty("PaymentPaypalAccountID")
	public Object getPaymentPaypalAccountID() {
		return paymentPaypalAccountID;
	}

	@JsonProperty("PaymentPaypalAccountID")
	public void setPaymentPaypalAccountID(Object paymentPaypalAccountID) {
		this.paymentPaypalAccountID = paymentPaypalAccountID;
	}

	@JsonProperty("PaymentCreditCardLast4")
	public String getPaymentCreditCardLast4() {
		return paymentCreditCardLast4;
	}

	@JsonProperty("PaymentCreditCardLast4")
	public void setPaymentCreditCardLast4(String paymentCreditCardLast4) {
		this.paymentCreditCardLast4 = paymentCreditCardLast4;
	}

	@JsonProperty("PaymentMerchantReferenceNumber")
	public Object getPaymentMerchantReferenceNumber() {
		return paymentMerchantReferenceNumber;
	}

	@JsonProperty("PaymentMerchantReferenceNumber")
	public void setPaymentMerchantReferenceNumber(Object paymentMerchantReferenceNumber) {
		this.paymentMerchantReferenceNumber = paymentMerchantReferenceNumber;
	}

	@JsonProperty("ShippingTitle")
	public Object getShippingTitle() {
		return shippingTitle;
	}

	@JsonProperty("ShippingTitle")
	public void setShippingTitle(Object shippingTitle) {
		this.shippingTitle = shippingTitle;
	}

	@JsonProperty("ShippingFirstName")
	public String getShippingFirstName() {
		return shippingFirstName;
	}

	@JsonProperty("ShippingFirstName")
	public void setShippingFirstName(String shippingFirstName) {
		this.shippingFirstName = shippingFirstName;
	}

	@JsonProperty("ShippingLastName")
	public String getShippingLastName() {
		return shippingLastName;
	}

	@JsonProperty("ShippingLastName")
	public void setShippingLastName(String shippingLastName) {
		this.shippingLastName = shippingLastName;
	}

	@JsonProperty("ShippingSuffix")
	public Object getShippingSuffix() {
		return shippingSuffix;
	}

	@JsonProperty("ShippingSuffix")
	public void setShippingSuffix(Object shippingSuffix) {
		this.shippingSuffix = shippingSuffix;
	}

	@JsonProperty("ShippingCompanyName")
	public Object getShippingCompanyName() {
		return shippingCompanyName;
	}

	@JsonProperty("ShippingCompanyName")
	public void setShippingCompanyName(Object shippingCompanyName) {
		this.shippingCompanyName = shippingCompanyName;
	}

	@JsonProperty("ShippingCompanyJobTitle")
	public Object getShippingCompanyJobTitle() {
		return shippingCompanyJobTitle;
	}

	@JsonProperty("ShippingCompanyJobTitle")
	public void setShippingCompanyJobTitle(Object shippingCompanyJobTitle) {
		this.shippingCompanyJobTitle = shippingCompanyJobTitle;
	}

	@JsonProperty("ShippingDaytimePhone")
	public String getShippingDaytimePhone() {
		return shippingDaytimePhone;
	}

	@JsonProperty("ShippingDaytimePhone")
	public void setShippingDaytimePhone(String shippingDaytimePhone) {
		this.shippingDaytimePhone = shippingDaytimePhone;
	}

	@JsonProperty("ShippingEveningPhone")
	public Object getShippingEveningPhone() {
		return shippingEveningPhone;
	}

	@JsonProperty("ShippingEveningPhone")
	public void setShippingEveningPhone(Object shippingEveningPhone) {
		this.shippingEveningPhone = shippingEveningPhone;
	}

	@JsonProperty("ShippingAddressLine1")
	public String getShippingAddressLine1() {
		return shippingAddressLine1;
	}

	@JsonProperty("ShippingAddressLine1")
	public void setShippingAddressLine1(String shippingAddressLine1) {
		this.shippingAddressLine1 = shippingAddressLine1;
	}

	@JsonProperty("ShippingAddressLine2")
	public String getShippingAddressLine2() {
		return shippingAddressLine2;
	}

	@JsonProperty("ShippingAddressLine2")
	public void setShippingAddressLine2(String shippingAddressLine2) {
		this.shippingAddressLine2 = shippingAddressLine2;
	}

	@JsonProperty("ShippingCity")
	public String getShippingCity() {
		return shippingCity;
	}

	@JsonProperty("ShippingCity")
	public void setShippingCity(String shippingCity) {
		this.shippingCity = shippingCity;
	}

	@JsonProperty("ShippingStateOrProvince")
	public String getShippingStateOrProvince() {
		return shippingStateOrProvince;
	}

	@JsonProperty("ShippingStateOrProvince")
	public void setShippingStateOrProvince(String shippingStateOrProvince) {
		this.shippingStateOrProvince = shippingStateOrProvince;
	}

	@JsonProperty("ShippingStateOrProvinceName")
	public String getShippingStateOrProvinceName() {
		return shippingStateOrProvinceName;
	}

	@JsonProperty("ShippingStateOrProvinceName")
	public void setShippingStateOrProvinceName(String shippingStateOrProvinceName) {
		this.shippingStateOrProvinceName = shippingStateOrProvinceName;
	}

	@JsonProperty("ShippingPostalCode")
	public String getShippingPostalCode() {
		return shippingPostalCode;
	}

	@JsonProperty("ShippingPostalCode")
	public void setShippingPostalCode(String shippingPostalCode) {
		this.shippingPostalCode = shippingPostalCode;
	}

	@JsonProperty("ShippingCountry")
	public String getShippingCountry() {
		return shippingCountry;
	}

	@JsonProperty("ShippingCountry")
	public void setShippingCountry(String shippingCountry) {
		this.shippingCountry = shippingCountry;
	}

	@JsonProperty("BillingTitle")
	public Object getBillingTitle() {
		return billingTitle;
	}

	@JsonProperty("BillingTitle")
	public void setBillingTitle(Object billingTitle) {
		this.billingTitle = billingTitle;
	}

	@JsonProperty("BillingFirstName")
	public String getBillingFirstName() {
		return billingFirstName;
	}

	@JsonProperty("BillingFirstName")
	public void setBillingFirstName(String billingFirstName) {
		this.billingFirstName = billingFirstName;
	}

	@JsonProperty("BillingLastName")
	public String getBillingLastName() {
		return billingLastName;
	}

	@JsonProperty("BillingLastName")
	public void setBillingLastName(String billingLastName) {
		this.billingLastName = billingLastName;
	}

	@JsonProperty("BillingSuffix")
	public String getBillingSuffix() {
		return billingSuffix;
	}

	@JsonProperty("BillingSuffix")
	public void setBillingSuffix(String billingSuffix) {
		this.billingSuffix = billingSuffix;
	}

	@JsonProperty("BillingCompanyName")
	public String getBillingCompanyName() {
		return billingCompanyName;
	}

	@JsonProperty("BillingCompanyName")
	public void setBillingCompanyName(String billingCompanyName) {
		this.billingCompanyName = billingCompanyName;
	}

	@JsonProperty("BillingCompanyJobTitle")
	public Object getBillingCompanyJobTitle() {
		return billingCompanyJobTitle;
	}

	@JsonProperty("BillingCompanyJobTitle")
	public void setBillingCompanyJobTitle(Object billingCompanyJobTitle) {
		this.billingCompanyJobTitle = billingCompanyJobTitle;
	}

	@JsonProperty("BillingDaytimePhone")
	public String getBillingDaytimePhone() {
		return billingDaytimePhone;
	}

	@JsonProperty("BillingDaytimePhone")
	public void setBillingDaytimePhone(String billingDaytimePhone) {
		this.billingDaytimePhone = billingDaytimePhone;
	}

	@JsonProperty("BillingEveningPhone")
	public Object getBillingEveningPhone() {
		return billingEveningPhone;
	}

	@JsonProperty("BillingEveningPhone")
	public void setBillingEveningPhone(Object billingEveningPhone) {
		this.billingEveningPhone = billingEveningPhone;
	}

	@JsonProperty("BillingAddressLine1")
	public String getBillingAddressLine1() {
		return billingAddressLine1;
	}

	@JsonProperty("BillingAddressLine1")
	public void setBillingAddressLine1(String billingAddressLine1) {
		this.billingAddressLine1 = billingAddressLine1;
	}

	@JsonProperty("BillingAddressLine2")
	public String getBillingAddressLine2() {
		return billingAddressLine2;
	}

	@JsonProperty("BillingAddressLine2")
	public void setBillingAddressLine2(String billingAddressLine2) {
		this.billingAddressLine2 = billingAddressLine2;
	}

	@JsonProperty("BillingCity")
	public String getBillingCity() {
		return billingCity;
	}

	@JsonProperty("BillingCity")
	public void setBillingCity(String billingCity) {
		this.billingCity = billingCity;
	}

	@JsonProperty("BillingStateOrProvince")
	public String getBillingStateOrProvince() {
		return billingStateOrProvince;
	}

	@JsonProperty("BillingStateOrProvince")
	public void setBillingStateOrProvince(String billingStateOrProvince) {
		this.billingStateOrProvince = billingStateOrProvince;
	}

	@JsonProperty("BillingPostalCode")
	public String getBillingPostalCode() {
		return billingPostalCode;
	}

	@JsonProperty("BillingPostalCode")
	public void setBillingPostalCode(String billingPostalCode) {
		this.billingPostalCode = billingPostalCode;
	}

	@JsonProperty("BillingCountry")
	public String getBillingCountry() {
		return billingCountry;
	}

	@JsonProperty("BillingCountry")
	public void setBillingCountry(String billingCountry) {
		this.billingCountry = billingCountry;
	}

	@JsonProperty("PromotionCode")
	public Object getPromotionCode() {
		return promotionCode;
	}

	@JsonProperty("PromotionCode")
	public void setPromotionCode(Object promotionCode) {
		this.promotionCode = promotionCode;
	}

	@JsonProperty("PromotionAmount")
	public long getPromotionAmount() {
		return promotionAmount;
	}

	@JsonProperty("PromotionAmount")
	public void setPromotionAmount(long promotionAmount) {
		this.promotionAmount = promotionAmount;
	}

	@JsonProperty("Items")
	public List<Item> getItems() {
		return items;
	}

	@JsonProperty("Items")
	public void setItems(List<Item> items) {
		this.items = items;
	}

	@JsonProperty("Fulfillments")
	public List<Fulfillment> getFulfillments() {
		return fulfillments;
	}

	@JsonProperty("Fulfillments")
	public void setFulfillments(List<Fulfillment> fulfillments) {
		this.fulfillments = fulfillments;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("odataContext", odataContext).append("iD", iD).append("profileID", profileID).append("siteID", siteID)
				.append("siteName", siteName).append("siteOrderID", siteOrderID).append("secondarySiteOrderID", secondarySiteOrderID)
				.append("sellerOrderID", sellerOrderID).append("checkoutSourceID", checkoutSourceID).append("createdDateUtc", createdDateUtc)
				.append("importDateUtc", importDateUtc).append("publicNotes", publicNotes).append("privateNotes", privateNotes)
				.append("specialInstructions", specialInstructions).append("totalPrice", totalPrice).append("totalTaxPrice", totalTaxPrice)
				.append("totalShippingPrice", totalShippingPrice).append("totalShippingTaxPrice", totalShippingTaxPrice)
				.append("totalInsurancePrice", totalInsurancePrice).append("totalGiftOptionPrice", totalGiftOptionPrice)
				.append("totalGiftOptionTaxPrice", totalGiftOptionTaxPrice).append("additionalCostOrDiscount", additionalCostOrDiscount)
				.append("estimatedShipDateUtc", estimatedShipDateUtc).append("deliverByDateUtc", deliverByDateUtc).append("resellerID", resellerID)
				.append("flagID", flagID).append("flagDescription", flagDescription).append("orderTags", orderTags)
				.append("distributionCenterTypeRollup", distributionCenterTypeRollup).append("checkoutStatus", checkoutStatus)
				.append("paymentStatus", paymentStatus).append("shippingStatus", shippingStatus).append("checkoutDateUtc", checkoutDateUtc)
				.append("paymentDateUtc", paymentDateUtc).append("shippingDateUtc", shippingDateUtc).append("buyerUserId", buyerUserId)
				.append("buyerEmailAddress", buyerEmailAddress).append("buyerEmailOptIn", buyerEmailOptIn).append("orderTaxType", orderTaxType)
				.append("shippingTaxType", shippingTaxType).append("giftOptionsTaxType", giftOptionsTaxType).append("paymentMethod", paymentMethod)
				.append("paymentTransactionID", paymentTransactionID).append("paymentPaypalAccountID", paymentPaypalAccountID)
				.append("paymentCreditCardLast4", paymentCreditCardLast4).append("paymentMerchantReferenceNumber", paymentMerchantReferenceNumber)
				.append("shippingTitle", shippingTitle).append("shippingFirstName", shippingFirstName).append("shippingLastName", shippingLastName)
				.append("shippingSuffix", shippingSuffix).append("shippingCompanyName", shippingCompanyName)
				.append("shippingCompanyJobTitle", shippingCompanyJobTitle).append("shippingDaytimePhone", shippingDaytimePhone)
				.append("shippingEveningPhone", shippingEveningPhone).append("shippingAddressLine1", shippingAddressLine1)
				.append("shippingAddressLine2", shippingAddressLine2).append("shippingCity", shippingCity)
				.append("shippingStateOrProvince", shippingStateOrProvince).append("shippingPostalCode", shippingPostalCode)
				.append("shippingCountry", shippingCountry).append("billingTitle", billingTitle).append("billingFirstName", billingFirstName)
				.append("billingLastName", billingLastName).append("billingSuffix", billingSuffix).append("billingCompanyName", billingCompanyName)
				.append("billingCompanyJobTitle", billingCompanyJobTitle).append("billingDaytimePhone", billingDaytimePhone)
				.append("billingEveningPhone", billingEveningPhone).append("billingAddressLine1", billingAddressLine1)
				.append("billingAddressLine2", billingAddressLine2).append("billingCity", billingCity)
				.append("billingStateOrProvince", billingStateOrProvince).append("billingPostalCode", billingPostalCode)
				.append("billingCountry", billingCountry).append("promotionCode", promotionCode).append("promotionAmount", promotionAmount)
				.append("items", items).append("fulfillments", fulfillments).toString();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(buyerUserId).append(billingStateOrProvince).append(promotionCode).append(resellerID)
				.append(shippingCompanyJobTitle).append(billingEveningPhone).append(flagDescription).append(totalInsurancePrice)
				.append(shippingCompanyName).append(billingFirstName).append(shippingDaytimePhone).append(shippingSuffix).append(orderTaxType)
				.append(checkoutStatus).append(shippingFirstName).append(billingLastName).append(estimatedShipDateUtc)
				.append(additionalCostOrDiscount).append(secondarySiteOrderID).append(shippingStateOrProvince).append(distributionCenterTypeRollup)
				.append(shippingPostalCode).append(paymentStatus).append(paymentDateUtc).append(billingDaytimePhone).append(iD)
				.append(billingAddressLine1).append(billingAddressLine2).append(shippingEveningPhone).append(totalGiftOptionPrice).append(items)
				.append(paymentPaypalAccountID).append(checkoutSourceID).append(checkoutDateUtc).append(billingTitle).append(shippingCountry)
				.append(shippingLastName).append(shippingTaxType).append(specialInstructions).append(shippingDateUtc).append(billingSuffix)
				.append(buyerEmailAddress).append(sellerOrderID).append(privateNotes).append(totalShippingPrice).append(createdDateUtc)
				.append(totalShippingTaxPrice).append(siteID).append(billingPostalCode).append(paymentCreditCardLast4).append(billingCity)
				.append(paymentTransactionID).append(billingCountry).append(billingCompanyJobTitle).append(shippingTitle).append(promotionAmount)
				.append(shippingStatus).append(totalTaxPrice).append(siteName).append(totalPrice).append(siteOrderID).append(fulfillments)
				.append(importDateUtc).append(publicNotes).append(deliverByDateUtc).append(totalGiftOptionTaxPrice).append(odataContext)
				.append(buyerEmailOptIn).append(paymentMerchantReferenceNumber).append(orderTags).append(flagID).append(billingCompanyName)
				.append(profileID).append(shippingAddressLine1).append(giftOptionsTaxType).append(shippingAddressLine2).append(shippingCity)
				.append(paymentMethod).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof ChannelAdvisorOrder) == false) {
			return false;
		}
		ChannelAdvisorOrder rhs = ((ChannelAdvisorOrder) other);
		return new EqualsBuilder().append(buyerUserId, rhs.buyerUserId).append(billingStateOrProvince, rhs.billingStateOrProvince)
				.append(promotionCode, rhs.promotionCode).append(resellerID, rhs.resellerID)
				.append(shippingCompanyJobTitle, rhs.shippingCompanyJobTitle).append(billingEveningPhone, rhs.billingEveningPhone)
				.append(flagDescription, rhs.flagDescription).append(totalInsurancePrice, rhs.totalInsurancePrice)
				.append(shippingCompanyName, rhs.shippingCompanyName).append(billingFirstName, rhs.billingFirstName)
				.append(shippingDaytimePhone, rhs.shippingDaytimePhone).append(shippingSuffix, rhs.shippingSuffix)
				.append(orderTaxType, rhs.orderTaxType).append(checkoutStatus, rhs.checkoutStatus).append(shippingFirstName, rhs.shippingFirstName)
				.append(billingLastName, rhs.billingLastName).append(estimatedShipDateUtc, rhs.estimatedShipDateUtc)
				.append(additionalCostOrDiscount, rhs.additionalCostOrDiscount).append(secondarySiteOrderID, rhs.secondarySiteOrderID)
				.append(shippingStateOrProvince, rhs.shippingStateOrProvince).append(distributionCenterTypeRollup, rhs.distributionCenterTypeRollup)
				.append(shippingPostalCode, rhs.shippingPostalCode).append(paymentStatus, rhs.paymentStatus)
				.append(paymentDateUtc, rhs.paymentDateUtc).append(billingDaytimePhone, rhs.billingDaytimePhone).append(iD, rhs.iD)
				.append(billingAddressLine1, rhs.billingAddressLine1).append(billingAddressLine2, rhs.billingAddressLine2)
				.append(shippingEveningPhone, rhs.shippingEveningPhone).append(totalGiftOptionPrice, rhs.totalGiftOptionPrice)
				.append(items, rhs.items).append(paymentPaypalAccountID, rhs.paymentPaypalAccountID).append(checkoutSourceID, rhs.checkoutSourceID)
				.append(checkoutDateUtc, rhs.checkoutDateUtc).append(billingTitle, rhs.billingTitle).append(shippingCountry, rhs.shippingCountry)
				.append(shippingLastName, rhs.shippingLastName).append(shippingTaxType, rhs.shippingTaxType)
				.append(specialInstructions, rhs.specialInstructions).append(shippingDateUtc, rhs.shippingDateUtc)
				.append(billingSuffix, rhs.billingSuffix).append(buyerEmailAddress, rhs.buyerEmailAddress).append(sellerOrderID, rhs.sellerOrderID)
				.append(privateNotes, rhs.privateNotes).append(totalShippingPrice, rhs.totalShippingPrice).append(createdDateUtc, rhs.createdDateUtc)
				.append(totalShippingTaxPrice, rhs.totalShippingTaxPrice).append(siteID, rhs.siteID).append(billingPostalCode, rhs.billingPostalCode)
				.append(paymentCreditCardLast4, rhs.paymentCreditCardLast4).append(billingCity, rhs.billingCity)
				.append(paymentTransactionID, rhs.paymentTransactionID).append(billingCountry, rhs.billingCountry)
				.append(billingCompanyJobTitle, rhs.billingCompanyJobTitle).append(shippingTitle, rhs.shippingTitle)
				.append(promotionAmount, rhs.promotionAmount).append(shippingStatus, rhs.shippingStatus).append(totalTaxPrice, rhs.totalTaxPrice)
				.append(siteName, rhs.siteName).append(totalPrice, rhs.totalPrice).append(siteOrderID, rhs.siteOrderID)
				.append(fulfillments, rhs.fulfillments).append(importDateUtc, rhs.importDateUtc).append(publicNotes, rhs.publicNotes)
				.append(deliverByDateUtc, rhs.deliverByDateUtc).append(totalGiftOptionTaxPrice, rhs.totalGiftOptionTaxPrice)
				.append(odataContext, rhs.odataContext).append(buyerEmailOptIn, rhs.buyerEmailOptIn)
				.append(paymentMerchantReferenceNumber, rhs.paymentMerchantReferenceNumber).append(orderTags, rhs.orderTags)
				.append(flagID, rhs.flagID).append(billingCompanyName, rhs.billingCompanyName).append(profileID, rhs.profileID)
				.append(shippingAddressLine1, rhs.shippingAddressLine1).append(giftOptionsTaxType, rhs.giftOptionsTaxType)
				.append(shippingAddressLine2, rhs.shippingAddressLine2).append(shippingCity, rhs.shippingCity)
				.append(paymentMethod, rhs.paymentMethod).isEquals();
	}

}
