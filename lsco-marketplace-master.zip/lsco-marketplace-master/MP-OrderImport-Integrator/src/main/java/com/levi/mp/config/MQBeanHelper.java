package com.levi.mp.config;

import javax.jms.JMSException;
import javax.jms.QueueConnection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.mq.jms.MQQueue;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;

/**
 * 
 * This MQBeanHelper class will provide the MQQueueConnectionFactory and other MQ related classes
 * 
 * @author Prabir Nandi
 *
 */
@Component
public class MQBeanHelper {
	
	@Autowired
	OrderImportLoadConfiguration orderImportIntegratorConfiguration;
	
	@Autowired
	MQQueueConnectionFactory mqQueueConnectionFactory;
	
	public MQQueueConnectionFactory getMQQueueConnectionFactory() throws JMSException {
		mqQueueConnectionFactory.setConnectionNameList(orderImportIntegratorConfiguration.getOrderImportConfig().getMqConfig().getMQHOST());
		mqQueueConnectionFactory.setChannel(orderImportIntegratorConfiguration.getOrderImportConfig().getMqConfig().getMQCHANNEL());// communications link
		mqQueueConnectionFactory.setPort(orderImportIntegratorConfiguration.getOrderImportConfig().getMqConfig().getMQPORT());
		mqQueueConnectionFactory.setQueueManager(orderImportIntegratorConfiguration.getOrderImportConfig().getMqConfig().getMQQMGR());// service provider
		mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
		return mqQueueConnectionFactory;
	}
	
	public QueueConnection getQueueConnection() throws JMSException {
		return getMQQueueConnectionFactory().createQueueConnection(orderImportIntegratorConfiguration.getOrderImportConfig().getMqConfig().getMQAPPUSER(), 
				orderImportIntegratorConfiguration.getOrderImportConfig().getMqConfig().getMQAPPPWD());
	}
	
	public MQQueue getMQQueue() throws JMSException {
		return new MQQueue(orderImportIntegratorConfiguration.getOrderImportConfig().getMqConfig().getMQSENDQNAME());
	}
	
	public OrderImportLoadConfiguration getConfig(){
		return orderImportIntegratorConfiguration;
	}

	
}
