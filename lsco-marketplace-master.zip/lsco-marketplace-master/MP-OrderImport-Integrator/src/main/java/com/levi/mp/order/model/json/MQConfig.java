package com.levi.mp.order.model.json;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Component
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "MQ_APP_PWD", "MQ_APP_USER", "MQ_CHANNEL", "MQ_HOST", "MQ_PORT", "MQ_QMGR", "MQ_SEND_QNAME" })
public class MQConfig {
	@JsonProperty("MQ_APP_PWD")
	private String mQAPPPWD;
	@JsonProperty("MQ_APP_USER")
	private String mQAPPUSER;
	@JsonProperty("MQ_CHANNEL")
	private String mQCHANNEL;
	@JsonProperty("MQ_HOST")
	private String mQHOST;
	@JsonProperty("MQ_PORT")
	private Integer mQPORT;
	@JsonProperty("MQ_QMGR")
	private String mQQMGR;
	@JsonProperty("MQ_SEND_QNAME")
	private String mQSENDQNAME;
}
