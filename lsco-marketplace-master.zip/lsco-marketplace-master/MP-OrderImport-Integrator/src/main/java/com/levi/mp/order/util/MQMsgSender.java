package com.levi.mp.order.util;

import java.util.HashMap;
import java.util.Map;

import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.QueueConnection;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.mq.jms.MQQueue;
import com.levi.mp.config.MQBeanHelper;
import com.levi.mp.config.OrderImportLoadConfiguration;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class MQMsgSender {

	@Autowired
	MQBeanHelper beanHelper;

	private QueueConnection queueConnection;

	private QueueSession queueSession;
	
	@Autowired
	SNSService snsService;
	
	@Autowired
	OrderImportLoadConfiguration orderImportLoadConfig;

	/**
	 * Send the message to JMS queue
	 */
	public Map<String, String> sendMsg(Map<String, String> msgListMap) {

		Map<String, String> responseMap = new HashMap<>();
		String orderId = "";
		String msg = "";

		try {
			QueueSender queueSender = this.createQueueSender();

			// iterate through each message and send to MQ
			for (Map.Entry<String, String> entry : msgListMap.entrySet()) {
				try {

					orderId = entry.getKey();
					msg = entry.getValue();

					/* Create text message */
					TextMessage textMessage = queueSession.createTextMessage(msg);
					// textMessage.setJMSReplyTo(queue);
					// textMessage.setJMSType("mcd://xmlns");// message type
					// textMessage.setJMSExpiration(5 * 1000);// message expiration
					// message delivery mode either persistent or non-persistemnt
					textMessage.setJMSDeliveryMode(DeliveryMode.PERSISTENT);

					/* send text message */
					// queueSender.setTimeToLive(2 * 1000);
					queueSender.send(textMessage);

					// queueSession.commit();
					log.info("Message sent successful for CA Order ID:>>>" + orderId);
					responseMap.put(orderId, IConstants.STATUS_SUCCESS);
				} catch (JMSException e) {
					log.error("***JMSException while sending message to "
							+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQSENDQNAME()
							+ " ,CA Order ID:" + orderId);
					//notify support
					log.info("Sending notification to support team");
					String notificationMessage = 
							"JMSException while sending message to "
									+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQSENDQNAME()
									+ " ,CA Order ID:" + orderId
							+ System.lineSeparator()
							+"Error Message: "
							+ System .lineSeparator()
							+ExceptionUtils.getStackTrace(e);
					String subject = "[MP-OrderImport]:JMSException sending message to JMS for CA Order ID:" + orderId;
					
					snsService.notifySupport(notificationMessage, subject);
					
					responseMap.put(orderId, IConstants.STATUS_ERROR);
				} catch (Throwable e) {
					log.error("***Exception while sending message to "
							+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQSENDQNAME()
							+ " ,CA Order ID:" + orderId);
					responseMap.put(orderId, IConstants.STATUS_ERROR);
					//notify support
					log.info("Sending notification to support team");
					String notificationMessage = 
							"Exception while sending message to "
									+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQSENDQNAME()
									+ " ,CA Order ID:" + orderId
							+ System.lineSeparator()
							+"Error Message: "
							+ System .lineSeparator()
							+ExceptionUtils.getStackTrace(e);
					
					String subject = "[MP-OrderImport]: Exception sending message to JMS for CA Order ID:" + orderId;
					
					snsService.notifySupport(notificationMessage, subject);
				}
			}
		} finally {
			try {

				if (null != queueConnection) {
					queueConnection.close();
					log.debug("JMS connection successfully closed...");
				}

			} catch (Exception e) {
				log.error("***Exception while closing queue connection***", e);
				String notificationMessage = 
						"Exception while closing MQ connection for "
								+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQSENDQNAME()
								+ " ,CA Order ID:" + orderId
						+ System.lineSeparator()
						+"Error Message: "
						+ System .lineSeparator()
						+ExceptionUtils.getStackTrace(e);
				
				String subject = "[MP-OrderImport]: Exception while closing MQ connection";
				snsService.notifySupport(notificationMessage, subject);
			}
		}
		return responseMap;
	}

	protected QueueSender createQueueSender() {
		try {

			/* Create Connection */
			queueConnection = beanHelper.getQueueConnection();
			queueConnection.start();

			/* Create session */
			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			/* Create sender queue */
			MQQueue mqQueue = beanHelper.getMQQueue();
			QueueSender queueSender = queueSession.createSender(mqQueue);
			log.debug("MQ connection successfully started for: "
					+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQHOST() + "::"
					+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQCHANNEL() + "::"
					+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQSENDQNAME());
			return queueSender;
		} catch (Throwable e) {
			log.error("***Exception while creating QueueSender: "
					+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQHOST() + "::"
					+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQCHANNEL() + "::"
					+ beanHelper.getConfig().getOrderImportConfig().getMqConfig().getMQSENDQNAME(), e);
			throw new RuntimeException("Exception while creating QueueSender", e);
		}
	}
}
