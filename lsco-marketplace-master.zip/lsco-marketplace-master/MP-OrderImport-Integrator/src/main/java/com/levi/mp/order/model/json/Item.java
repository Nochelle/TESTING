
package com.levi.mp.order.model.json;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Component
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ID",
    "ProfileID",
    "OrderID",
    "ProductID",
    "SiteOrderItemID",
    "SiteListingID",
    "Sku",
    "Title",
    "Quantity",
    "UnitPrice",
    "TaxPrice",
    "ShippingPrice",
    "ShippingTaxPrice",
    "RecyclingFee",
    "GiftMessage",
    "GiftNotes",
    "GiftPrice",
    "GiftTaxPrice",
    "IsBundle",
    "ItemURL",
    "Promotions"
})
public class Item implements Serializable
{

    @JsonProperty("ID")
    private long iD;
    @JsonProperty("ProfileID")
    private long profileID;
    @JsonProperty("OrderID")
    private long orderID;
    @JsonProperty("ProductID")
    private long productID;
    @JsonProperty("SiteOrderItemID")
    private String siteOrderItemID;
    @JsonProperty("SiteListingID")
    private String siteListingID;
    @JsonProperty("Sku")
    private String sku;
    @JsonProperty("Title")
    private String title;
    @JsonProperty("Quantity")
    private long quantity;
    @JsonProperty("UnitPrice")
    private BigDecimal unitPrice;
    @JsonProperty("TaxPrice")
    private BigDecimal taxPrice;
    @JsonProperty("ShippingPrice")
    private BigDecimal shippingPrice;
    @JsonProperty("ShippingTaxPrice")
    private BigDecimal shippingTaxPrice;
    @JsonProperty("RecyclingFee")
    private BigDecimal recyclingFee;
    @JsonProperty("GiftMessage")
    private Object giftMessage;
    @JsonProperty("GiftNotes")
    private Object giftNotes;
    @JsonProperty("GiftPrice")
    private BigDecimal giftPrice;
    @JsonProperty("GiftTaxPrice")
    private BigDecimal giftTaxPrice;
    @JsonProperty("IsBundle")
    private boolean isBundle;
    @JsonProperty("ItemURL")
    private String itemURL;
    @JsonProperty("Promotions")
    private List<Promotion> promotions = null;
    private final static long serialVersionUID = -4120260349128436285L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Item() {
    }

    /**
     * 
     * @param giftMessage
     * @param siteOrderItemID
     * @param orderID
     * @param giftTaxPrice
     * @param promotions
     * @param taxPrice
     * @param unitPrice
     * @param sku
     * @param shippingTaxPrice
     * @param iD
     * @param productID
     * @param isBundle
     * @param title
     * @param giftNotes
     * @param profileID
     * @param shippingPrice
     * @param itemURL
     * @param giftPrice
     * @param quantity
     * @param recyclingFee
     * @param siteListingID
     */
    public Item(long iD, long profileID, long orderID, long productID, String siteOrderItemID, String siteListingID, String sku, String title, long quantity, BigDecimal unitPrice, BigDecimal taxPrice, BigDecimal shippingPrice, BigDecimal shippingTaxPrice, BigDecimal recyclingFee, Object giftMessage, Object giftNotes, BigDecimal giftPrice, BigDecimal giftTaxPrice, boolean isBundle, String itemURL, List<Promotion> promotions) {
        super();
        this.iD = iD;
        this.profileID = profileID;
        this.orderID = orderID;
        this.productID = productID;
        this.siteOrderItemID = siteOrderItemID;
        this.siteListingID = siteListingID;
        this.sku = sku;
        this.title = title;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.taxPrice = taxPrice;
        this.shippingPrice = shippingPrice;
        this.shippingTaxPrice = shippingTaxPrice;
        this.recyclingFee = recyclingFee;
        this.giftMessage = giftMessage;
        this.giftNotes = giftNotes;
        this.giftPrice = giftPrice;
        this.giftTaxPrice = giftTaxPrice;
        this.isBundle = isBundle;
        this.itemURL = itemURL;
        this.promotions = promotions;
    }

    @JsonProperty("ID")
    public long getID() {
        return iD;
    }

    @JsonProperty("ID")
    public void setID(long iD) {
        this.iD = iD;
    }

    @JsonProperty("ProfileID")
    public long getProfileID() {
        return profileID;
    }

    @JsonProperty("ProfileID")
    public void setProfileID(long profileID) {
        this.profileID = profileID;
    }

    @JsonProperty("OrderID")
    public long getOrderID() {
        return orderID;
    }

    @JsonProperty("OrderID")
    public void setOrderID(long orderID) {
        this.orderID = orderID;
    }

    @JsonProperty("ProductID")
    public long getProductID() {
        return productID;
    }

    @JsonProperty("ProductID")
    public void setProductID(long productID) {
        this.productID = productID;
    }

    @JsonProperty("SiteOrderItemID")
    public String getSiteOrderItemID() {
        return siteOrderItemID;
    }

    @JsonProperty("SiteOrderItemID")
    public void setSiteOrderItemID(String siteOrderItemID) {
        this.siteOrderItemID = siteOrderItemID;
    }

    @JsonProperty("SiteListingID")
    public String getSiteListingID() {
        return siteListingID;
    }

    @JsonProperty("SiteListingID")
    public void setSiteListingID(String siteListingID) {
        this.siteListingID = siteListingID;
    }

    @JsonProperty("Sku")
    public String getSku() {
        return sku;
    }

    @JsonProperty("Sku")
    public void setSku(String sku) {
        this.sku = sku;
    }

    @JsonProperty("Title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("Title")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("Quantity")
    public long getQuantity() {
        return quantity;
    }

    @JsonProperty("Quantity")
    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    @JsonProperty("UnitPrice")
    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    @JsonProperty("UnitPrice")
    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    @JsonProperty("TaxPrice")
    public BigDecimal getTaxPrice() {
        return taxPrice;
    }

    @JsonProperty("TaxPrice")
    public void setTaxPrice(BigDecimal taxPrice) {
        this.taxPrice = taxPrice;
    }

    @JsonProperty("ShippingPrice")
    public BigDecimal getShippingPrice() {
        return shippingPrice;
    }

    @JsonProperty("ShippingPrice")
    public void setShippingPrice(BigDecimal shippingPrice) {
        this.shippingPrice = shippingPrice;
    }

    @JsonProperty("ShippingTaxPrice")
    public BigDecimal getShippingTaxPrice() {
        return shippingTaxPrice;
    }

    @JsonProperty("ShippingTaxPrice")
    public void setShippingTaxPrice(BigDecimal shippingTaxPrice) {
        this.shippingTaxPrice = shippingTaxPrice;
    }

    @JsonProperty("RecyclingFee")
    public BigDecimal getRecyclingFee() {
        return recyclingFee;
    }

    @JsonProperty("RecyclingFee")
    public void setRecyclingFee(BigDecimal recyclingFee) {
        this.recyclingFee = recyclingFee;
    }

    @JsonProperty("GiftMessage")
    public Object getGiftMessage() {
        return giftMessage;
    }

    @JsonProperty("GiftMessage")
    public void setGiftMessage(Object giftMessage) {
        this.giftMessage = giftMessage;
    }

    @JsonProperty("GiftNotes")
    public Object getGiftNotes() {
        return giftNotes;
    }

    @JsonProperty("GiftNotes")
    public void setGiftNotes(Object giftNotes) {
        this.giftNotes = giftNotes;
    }

    @JsonProperty("GiftPrice")
    public BigDecimal getGiftPrice() {
        return giftPrice;
    }

    @JsonProperty("GiftPrice")
    public void setGiftPrice(BigDecimal giftPrice) {
        this.giftPrice = giftPrice;
    }

    @JsonProperty("GiftTaxPrice")
    public BigDecimal getGiftTaxPrice() {
        return giftTaxPrice;
    }

    @JsonProperty("GiftTaxPrice")
    public void setGiftTaxPrice(BigDecimal giftTaxPrice) {
        this.giftTaxPrice = giftTaxPrice;
    }

    @JsonProperty("IsBundle")
    public boolean isIsBundle() {
        return isBundle;
    }

    @JsonProperty("IsBundle")
    public void setIsBundle(boolean isBundle) {
        this.isBundle = isBundle;
    }

    @JsonProperty("ItemURL")
    public String getItemURL() {
        return itemURL;
    }

    @JsonProperty("ItemURL")
    public void setItemURL(String itemURL) {
        this.itemURL = itemURL;
    }

    @JsonProperty("Promotions")
    public List<Promotion> getPromotions() {
        return promotions;
    }

    @JsonProperty("Promotions")
    public void setPromotions(List<Promotion> promotions) {
        this.promotions = promotions;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("iD", iD).append("profileID", profileID).append("orderID", orderID).append("productID", productID).append("siteOrderItemID", siteOrderItemID).append("siteListingID", siteListingID).append("sku", sku).append("title", title).append("quantity", quantity).append("unitPrice", unitPrice).append("taxPrice", taxPrice).append("shippingPrice", shippingPrice).append("shippingTaxPrice", shippingTaxPrice).append("recyclingFee", recyclingFee).append("giftMessage", giftMessage).append("giftNotes", giftNotes).append("giftPrice", giftPrice).append("giftTaxPrice", giftTaxPrice).append("isBundle", isBundle).append("itemURL", itemURL).append("promotions", promotions).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(giftMessage).append(siteOrderItemID).append(orderID).append(giftTaxPrice).append(promotions).append(taxPrice).append(unitPrice).append(sku).append(shippingTaxPrice).append(productID).append(iD).append(isBundle).append(title).append(giftNotes).append(profileID).append(shippingPrice).append(itemURL).append(giftPrice).append(quantity).append(recyclingFee).append(siteListingID).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Item) == false) {
            return false;
        }
        Item rhs = ((Item) other);
        return new EqualsBuilder().append(giftMessage, rhs.giftMessage).append(siteOrderItemID, rhs.siteOrderItemID).append(orderID, rhs.orderID).append(giftTaxPrice, rhs.giftTaxPrice).append(promotions, rhs.promotions).append(taxPrice, rhs.taxPrice).append(unitPrice, rhs.unitPrice).append(sku, rhs.sku).append(shippingTaxPrice, rhs.shippingTaxPrice).append(productID, rhs.productID).append(iD, rhs.iD).append(isBundle, rhs.isBundle).append(title, rhs.title).append(giftNotes, rhs.giftNotes).append(profileID, rhs.profileID).append(shippingPrice, rhs.shippingPrice).append(itemURL, rhs.itemURL).append(giftPrice, rhs.giftPrice).append(quantity, rhs.quantity).append(recyclingFee, rhs.recyclingFee).append(siteListingID, rhs.siteListingID).isEquals();
    }

}
