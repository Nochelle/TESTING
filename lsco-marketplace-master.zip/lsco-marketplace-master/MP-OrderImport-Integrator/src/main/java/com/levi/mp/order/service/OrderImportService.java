package com.levi.mp.order.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.levi.mp.order.model.json.ChannelAdvisorOrder;
import com.levi.mp.order.model.json.OrderImportProcessInfo;
import com.levi.mp.order.model.json.Orders;
import com.levi.mp.order.model.xml.TXML;
import com.levi.mp.order.rest.client.OrderRestClientAdapter;
import com.levi.mp.order.util.IConstants;
import com.levi.mp.order.util.MQMsgBuilder;
import com.levi.mp.order.util.MQMsgSender;
import com.levi.mp.order.util.OrderImportUtil;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

/**
 * @author Prabir Nandi
 *
 */
@Component
@Log4j2
public class OrderImportService {

	@Autowired
	ChannelAdvisorTokenService advisorTokenService;

//	@Autowired
//	MPSharedUtil mpSharedUtil;

	@Autowired
	OrderImportUtil orderImportUtil;

	@Autowired
	OrderRestClientAdapter restClientAdaptor;
	
	@Autowired
	MQMsgSender mqMsgSender;
	
	@Autowired
	MQMsgBuilder mqMsgBuilder;
	
//	@Autowired
//	OrderImportLoadConfiguration orderImportLoadConfig;
	
	@Autowired
	SNSService snsService;
	
	//Object to store the processInfo
	OrderImportProcessInfo orderImportProcessInfo;
	
	
	
	
	public void processNewOrders() {
		
		Orders orders = null;
		log.info("Start:OrderService.processNewOrders()>>>");
		
		//final String caAccessToken = advisorTokenService.getOAuth2Token();

		// call CA api and get the Order List
		orders = restClientAdaptor.getUnexportedOrders();
		
		//log.debug("getSmartLabelFee>>>"+orderImportLoadConfig.getOrderImportConfig().getMPConfig(IConstants.ORDER_TYPE_GOOGLE).getSmartLabelFee());

		postOrderstoMQAndUpdateExportFlag(orders);

	}

	/**
	 * post the COI message to MQ and update export status to CA
	 * @param orders
	 * @param caAccessToken
	 */
	public void postOrderstoMQAndUpdateExportFlag(Orders orders) {
		
			orderImportProcessInfo = OrderImportProcessInfo.builder().build();
		
			int noOfOrdersFowWhichXMLMessagesBuiltOK = 0;
			int noOfOrdersPostedSuccessfullyTOMQ = 0;
			int noOfOrderSuccessfullyUpdatedinCA = 0;
			
			//check for any order from CA API response
			if (null != orders && null != orders.getCaOrders() && orders.getCaOrders().size() > 0) {
				TXML txml = null;
				Map<String, String> mqMsgListMap = new HashMap<String, String>();
				// iterate each order
				for (ChannelAdvisorOrder order : orders.getCaOrders()) {

						// convert JSON object to XML based on the attribute mapping
						log.debug("Going to convert from Json To XML Object for Order ID:"+order.getID() +" and SiteOrderID:"+order.getSiteOrderID());
						txml = orderImportUtil.convertJsonToXMLObject(order);
						
						if (txml != null) {
							String txmlString = mqMsgBuilder.buildSendMsg(txml);
							log.debug("txmlString>>>\n"+txmlString);
							
							//Counter for number of successful xml messages constructed that would be posted to MQ
							if(!StringUtils.isEmpty(txmlString)) {
								noOfOrdersFowWhichXMLMessagesBuiltOK++;
								mqMsgListMap.put(String.valueOf(order.getID()), txmlString);
							}
							
						}
				}

				Map<String, String> resultMap = null;

				// post all Orders Message to MQ if there is any
				if(mqMsgListMap!=null && mqMsgListMap.size()>0) {
					resultMap = mqMsgSender.sendMsg(mqMsgListMap);
				}
								
				if(resultMap!=null && resultMap.size()>0) {
					
					final String caAccessToken = advisorTokenService.getOAuth2Token();
					log.info(caAccessToken+" this is the access token #################");
					// update order exported status to true to CA to stop being exported in next batch pull			
					for (Map.Entry<String, String> entry : resultMap.entrySet()) { //iterate the resultMap
						try {
							if (IConstants.STATUS_SUCCESS.equals(entry.getValue())) {
								noOfOrdersPostedSuccessfullyTOMQ++;
								boolean updateOrderStatusInCAStatus = restClientAdaptor.updateOrderSatusFlag(entry.getKey(), caAccessToken);
								if(updateOrderStatusInCAStatus) {
									noOfOrderSuccessfullyUpdatedinCA++;
								}
								log.info("Successfully updated export flag as true for CA Order id: " + entry.getKey());
							}
						} catch (Exception e) {
							log.error("***Exception while calling to CA API for updating export flag for CA Order ID:" + entry.getKey());
							String notificationMessage = 
									"Exception occured while updating export flag:"
									+ System.lineSeparator()
									+"Error Message: "
									+ System .lineSeparator()
									+ExceptionUtils.getStackTrace(e);
								String subject = "[MP-OrderImport]: Exception occured while updating export status flag to CA for CA Order ID:" + entry.getKey();
								snsService.notifySupport(notificationMessage, subject);
						}
					}
				}else {
					log.debug("There are no orders in resultMap , so skipping update order status API call>>>");
				}
				
			
			
				//Store track of process related information
				orderImportProcessInfo.setTotUnExportedOrdersFromCA(orders.getCaOrders().size());
				orderImportProcessInfo.setOrderXmlMessagesBuiltOK(noOfOrdersFowWhichXMLMessagesBuiltOK);
				orderImportProcessInfo.setOrderXmlMessagesNotBuilt((orders.getCaOrders().size() - noOfOrdersFowWhichXMLMessagesBuiltOK));
				orderImportProcessInfo.setOrderXmlsPostedToMQSuccess(noOfOrdersPostedSuccessfullyTOMQ);
				orderImportProcessInfo.setOrderXmlsNotPostedToMQ(noOfOrdersFowWhichXMLMessagesBuiltOK - noOfOrdersPostedSuccessfullyTOMQ);
				orderImportProcessInfo.setOrdersStatusUpdatedInCA(noOfOrderSuccessfullyUpdatedinCA);
				orderImportProcessInfo.setOrderStatusNotUpdatedInCA(noOfOrdersPostedSuccessfullyTOMQ - noOfOrderSuccessfullyUpdatedinCA);
			
				//log.info(">>>>>>>>>>>>>"+orderImportProcessInfo);
			
			
			
			log.info("--------------------------------------------OrderImport Process Statistics:--------------------------------------------");
			log.info("Total # of Unexported Orders fetched from CA: " + orderImportProcessInfo.getTotUnExportedOrdersFromCA());
			log.info("Total # of Orders for which XML Messages generated successfully: " + orderImportProcessInfo.getOrderXmlMessagesBuiltOK());
			log.info("Total # of Orders for which XML Messages could NOT be generated: " + orderImportProcessInfo.getOrderXmlMessagesNotBuilt());
			log.info("Total # of Order XMLs posted successfully to MQ: " + orderImportProcessInfo.getOrderXmlsPostedToMQSuccess());
			log.info("Total # of Order XMLs could NOT be posted to MQ: " +orderImportProcessInfo.getOrderXmlsNotPostedToMQ());
			log.info("Total # of Orders for which status flag successfully updated in CA: " + orderImportProcessInfo.getOrdersStatusUpdatedInCA());
			log.info("Total # of Orders for which status flag could NOT be updated in CA: " + orderImportProcessInfo.getOrderStatusNotUpdatedInCA());
			log.info("----------------------------------------------------------------------------------------");	
			} else { // No Orders found to be exported from CA API Call
				log.info("No Orders found to be exported from CA. Current Time(PST): "
						+ OrderImportUtil.getCurrentDateTime("PST", "MM/dd/yyyy HH:mm:ss.SSS"));
				//Set up statistics in case there are no orders from CA 
				orderImportProcessInfo.setTotUnExportedOrdersFromCA(0);
			}
			log.info("End:OrderService.processNewOrders()>>>");		
			
			return;
	}
	
	public OrderImportProcessInfo getOrderImportProcesInfo() {
		return orderImportProcessInfo;
	}

}
