package com.levi.mp.order.model.json;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "FREE_RETURN", "SMART_LABEL_FEE" })
public class FacebookConfig extends MPConfig{
	
}
