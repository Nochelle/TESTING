package com.levi.mp.order.model.json;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.levi.mp.order.util.IConstants;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "MQ_CONFIG"})
public class OrderImportConfig {
	@JsonProperty("MQ_CONFIG")
	MQConfig mqConfig;
	
	@JsonProperty("FACEBOOK")
	FacebookConfig facebook;
	
	@JsonProperty("GOOGLE")
	GoogleConfig google;
	
	
	
	public MPConfig getMPConfig(String orderType) {
		
		if(IConstants.ORDER_TYPE_FB.equals(orderType)) {
			return facebook;
		}else if(IConstants.ORDER_TYPE_GOOGLE.equals(orderType)) {
			return google;
		}
		return null;
	}

}
