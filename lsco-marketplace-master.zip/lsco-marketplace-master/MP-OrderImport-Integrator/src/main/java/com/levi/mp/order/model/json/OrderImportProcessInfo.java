package com.levi.mp.order.model.json;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * 
 * @author adhar@levi.com
 *
 */
@Getter
@Setter
@RequiredArgsConstructor
@EqualsAndHashCode
@AllArgsConstructor
@Builder
public class OrderImportProcessInfo {

	private Integer totUnExportedOrdersFromCA;

	private Integer orderXmlMessagesBuiltOK;

	private Integer orderXmlMessagesNotBuilt;

	private Integer orderXmlsPostedToMQSuccess;

	private Integer orderXmlsNotPostedToMQ;

	private Integer ordersStatusUpdatedInCA;

	private Integer orderStatusNotUpdatedInCA;

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OrderImportProcessInfo ["
				+ (totUnExportedOrdersFromCA !=null ? "totUnExportedOrdersFromCA=" + totUnExportedOrdersFromCA : "")
				+ (orderXmlMessagesBuiltOK!= null ? ", orderXmlMessagesBuiltOK=" + orderXmlMessagesBuiltOK : "")
				+ (orderXmlMessagesNotBuilt!= null ? ", orderXmlMessagesNotBuilt="+ orderXmlMessagesNotBuilt: "") 
				+ (orderXmlsPostedToMQSuccess!= null ? ", orderXmlsPostedToMQSuccess=" +orderXmlsPostedToMQSuccess: "")
				+ (orderXmlsNotPostedToMQ!= null ? ", orderXmlsNotPostedToMQ=" + orderXmlsNotPostedToMQ: "") 
				+ (ordersStatusUpdatedInCA != null ? ", ordersStatusUpdatedInCA="+ ordersStatusUpdatedInCA: "") 
				+ (orderStatusNotUpdatedInCA != null ? ", orderStatusNotUpdatedInCA=" + orderStatusNotUpdatedInCA : "") 
				+ "]";
	}

}
