package com.levi.mp.order.model.json;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Sku", "Title", "Quantity", "UnitPrice", "TaxPrice",
		"ShippingPrice", "ShippingTaxPrice" })
public class OrderItems {

	@JsonProperty("Sku")
	private String sku;
	@JsonProperty("Title")
	private String title;
	@JsonProperty("Quantity")
	private long quantity;
	@JsonProperty("UnitPrice")
	private Double unitPrice;
	@JsonProperty("TaxPrice")
	private Double taxPrice;
	@JsonProperty("ShippingPrice")
	private Double shippingPrice;
	@JsonProperty("ShippingTaxPrice")
	private Double shippingTaxPrice;

}
