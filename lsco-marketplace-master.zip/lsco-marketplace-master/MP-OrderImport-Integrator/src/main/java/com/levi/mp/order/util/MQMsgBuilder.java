package com.levi.mp.order.util;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.levi.mp.order.model.xml.TXML;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class MQMsgBuilder {
	
	@Autowired
	SNSService snsService;
	
	/**
	 * convert TXML object to String XML
	 * 
	 * @param txml
	 * @return strMsg
	 */
	public String buildSendMsg(TXML txml) {
		String strMsg = null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(TXML.class);

			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			StringWriter sw = new StringWriter();
			marshaller.marshal(txml, sw);
			strMsg = sw.toString();
		} catch (Exception e) {
			log.error("***Exception in buildSendMsg***", e);
			log.info("Sending notification to support team");
			//Notify Support
			String notificationMessage = 
					"Exception in building message from Txml:"
					+((txml!=null && txml.getMessage()!= null && txml.getMessage().getOrder()!=null
					&& txml.getMessage().getOrder().getOrderNumber()!=null)
							?txml.getMessage().getOrder().getOrderNumber() : "Empty TXML")
					+ System.lineSeparator()
					+"Error Message: "
					+ System .lineSeparator()
					+ExceptionUtils.getStackTrace(e);	
			String subject = "[MP-OrderImport]: Exception in building COI message from Txml";
			
			snsService.notifySupport(notificationMessage, subject);
		}
		return strMsg;
	}
}
