package com.levi.mp.order.util;

public interface IConstants {

	public String CARD_TYPE_GOOGLE = "Google";
	public String CARD_TYPE_FB = "Facebook";
	public String ORDER_TYPE_GOOGLE = "OT_GOOGLE";
	public String ORDER_TYPE_FB = "OT_FB";
	public String GOOGLE_ORDER_ID_PREFIX = "GL_";
	public String FACEBOOK_ORDER_ID_PREFIX = "FB_";

	public int GOOGLE_SITE_ID = 1168;
	public int FACEBOOK_SITE_ID = 1309;

	public String STATUS_SUCCESS = "SUCCESS";
	public String STATUS_ERROR = "ERROR";
	
	public String DATE_FORMART_WITH_MS = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public String DATE_FORMART_WITHOUT_MS = "yyyy-MM-dd'T'HH:mm:ss'Z'";
	public String DATE_FORMART_EOM = "MM/dd/yy HH:mm";	
}
