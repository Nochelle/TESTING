package com.levi.mp.order.function;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.levi.mp.order.model.json.Orders;
import com.levi.mp.order.service.OrderImportService;

import lombok.extern.log4j.Log4j2;

/**
 * AWS Lambda Handler that also initializes Spring's ApplicationContext for wiring beans.
 * 
 * @author Prabir Nandi
 *
 */
@Component
@Log4j2
public class OrderImportAutomationHandler {

	ApplicationContext getApplicationContext() {
		return new AnnotationConfigApplicationContext("com.levi.mp");
	}

	public String handleAutomationRequest(Orders input) {
		log.debug("OrderImportAutomationHandler.handleRequest(), input:" + input);
		orderImportService = getApplicationContext().getBean(OrderImportService.class);
		try {
			orderImportService.postOrderstoMQAndUpdateExportFlag(input);
			return "Order Import Job successfully Completed";
		} catch (Exception e) {
			log.error("Error occured while importing orders", e);
			return "Error occured while importing orders";
		}
	}

	@Autowired
	private OrderImportService orderImportService;

}
