package com.levi.mp.order.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazonaws.util.StringUtils;
import com.levi.mp.config.OrderImportLoadConfiguration;
import com.levi.mp.order.model.json.ChannelAdvisorOrder;
import com.levi.mp.order.model.json.Fulfillment;
import com.levi.mp.order.model.json.Item;
import com.levi.mp.order.model.json.Promotion;
import com.levi.mp.order.model.xml.ObjectFactory;
import com.levi.mp.order.model.xml.TXML;
import com.levi.mp.order.model.xml.TXML.Header;
import com.levi.mp.order.model.xml.TXML.Message;
import com.levi.mp.order.model.xml.TXML.Message.Order;
import com.levi.mp.order.model.xml.TXML.Message.Order.ChargeDetails;
import com.levi.mp.order.model.xml.TXML.Message.Order.ChargeDetails.ChargeDetail;
import com.levi.mp.order.model.xml.TXML.Message.Order.CustomerInfo;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.CustomFieldList;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.CustomFieldList.CustomField;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.LineReferenceFields;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.PriceInfo;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.Quantity;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.ShippingInfo;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.ShippingInfo.ShippingAddress;
import com.levi.mp.order.model.xml.TXML.Message.Order.PaymentDetails;
import com.levi.mp.order.model.xml.TXML.Message.Order.PaymentDetails.PaymentDetail;
import com.levi.mp.order.model.xml.TXML.Message.Order.PaymentDetails.PaymentDetail.BillToDetail;
import com.levi.mp.order.model.xml.TXML.Message.Order.PaymentDetails.PaymentDetail.PaymentTransactionDetails;
import com.levi.mp.order.model.xml.TXML.Message.Order.PaymentDetails.PaymentDetail.PaymentTransactionDetails.PaymentTransactionDetail;
import com.levi.mp.order.model.xml.TXML.Message.Order.ReferenceFields;
import com.levi.mp.order.model.xml.TXML.Message.Order.TaxDetails;
import com.levi.mp.order.model.xml.TXML.Message.Order.TaxDetails.TaxDetail;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

/**
 * 
 * @author Prabir Nandi
 *
 */
@Log4j2
@Component
public class OrderImportUtil {

	static ObjectFactory factory = new ObjectFactory();
	private String createdDateCST;

	@Autowired
	SNSService snsService;

	@Autowired
	OrderImportLoadConfiguration orderImportLoadConfig;

	/**
	 * Convert UTC/GMT time to CST time
	 * 
	 * @param utcDateTimeStr
	 * @return cstDateTimeStr
	 * @throws ParseException
	 */
	public static String convertUTCtoCST(String utcDateTimeStr) throws ParseException {

		if (utcDateTimeStr == null || "".equalsIgnoreCase(utcDateTimeStr)) {
			throw new RuntimeException("Invalid date");
		}
		// remove milli sec if there is any
		if (utcDateTimeStr.contains(".")) {
			utcDateTimeStr = utcDateTimeStr.substring(0, utcDateTimeStr.indexOf("."));
			utcDateTimeStr = utcDateTimeStr + "Z";
		}

		DateFormat utcFormat = new SimpleDateFormat(IConstants.DATE_FORMART_WITHOUT_MS);
		utcFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date utcDate = utcFormat.parse(utcDateTimeStr);
		// System.out.println(utcDate);

		DateFormat cstFormat = new SimpleDateFormat(IConstants.DATE_FORMART_EOM);
		cstFormat.setTimeZone(TimeZone.getTimeZone("CST"));
		String cstDateTimeStr = cstFormat.format(utcDate);
		// System.out.println("cstDateTimeStr>>>"+cstDateTimeStr);
		return cstDateTimeStr;
	}

	/**
	 * Get Transaction Expiry Date as create date + 30 days
	 * 
	 * @param createdDate
	 * @return
	 */
	public String getTransactionExpiryDate(String createdDate) {
		DateFormat dateFormat = new SimpleDateFormat(IConstants.DATE_FORMART_EOM);

		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormat.parse(createdDate));
			cal.add(Calendar.DATE, 30);

			String convertedDate = dateFormat.format(cal.getTime());
			// System.out.println("Date increase by 30: days:"+convertedDate);
			return convertedDate;
		} catch (ParseException e) {
			log.error("***Exception while parsing the date***", e);
		}
		return createdDate;
	}

	/**
	 * Get current datetime in specified timeZone and datetime format
	 * 
	 * @param timeZone
	 * @return String
	 */
	public static String getCurrentDateTime(String timeZone, String format) {
		DateFormat formatter = new SimpleDateFormat(format);
		formatter.setTimeZone(TimeZone.getTimeZone(timeZone));
		return formatter.format(new Date());
	}

	/**
	 * convert JSON object to XML Object based on the attribute mapping between CA API Response and OMS COI XML
	 * 
	 * @param orderJson
	 * @return TXML
	 * @throws ParseException
	 */
	public TXML convertJsonToXMLObject(ChannelAdvisorOrder orderJson) {

		final String HEADER_SOURCE_GOOGLE = "Google";
		final String HEADER_SOURCE_FB = "Facebook";
		final String TRUE_VALUE = "true";
		final String FALSE_VALUE = "false";

		try {
			// build a TXML object
			TXML txml = factory.createTXML();

			String orderType = "";
			String source = "";
			String cardType = "";
			String siteOrderID = orderJson.getSiteOrderID();
			BigDecimal totalItemShippingPrice = new BigDecimal("0.00");
			BigDecimal totalItemShippingTaxPrice = new BigDecimal("0.00");

			if (orderJson.getSiteID() == IConstants.GOOGLE_SITE_ID) { // For Google
				source = HEADER_SOURCE_GOOGLE; // Source
				orderType = IConstants.ORDER_TYPE_GOOGLE; // OT_GOOGLE
				cardType = IConstants.CARD_TYPE_GOOGLE;
				// siteOrderID = IConstants.GOOGLE_ORDER_ID_PREFIX + siteOrderID;
			} else if (orderJson.getSiteID() == IConstants.FACEBOOK_SITE_ID) { // For Facebook
				source = HEADER_SOURCE_FB; // Source
				orderType = IConstants.ORDER_TYPE_FB; // OT_FB
				cardType = IConstants.CARD_TYPE_FB;
				// siteOrderID = IConstants.FACEBOOK_ORDER_ID_PREFIX + siteOrderID;

				CustomField cf = factory.createTXMLMessageOrderOrderLinesOrderLineCustomFieldListCustomField();
				cf.setName(factory.createTXMLMessageOrderOrderLinesOrderLineCustomFieldListCustomFieldName("Orderline_IsReturnable"));

			} else {
				log.warn("Invalid Site ID encountered: " + orderJson.getSiteID() + " for Order ID:" + orderJson.getID() + " and Site Order ID: " + orderJson.getSiteOrderID());
				log.info("Sending notification to support team");
				// Notify Support that an unknown siteID was encountered?
				String notificationMessage = "Invalid Site ID encountered: " + orderJson.getSiteID() + " for Order ID:" + orderJson.getID() + " and Site Order ID: "
						+ orderJson.getSiteOrderID();

				String subject = "[MP-OrderImport]:Invalid Site ID: " + orderJson.getSiteID()+ ", CA OrderID:" +
						orderJson.getID()+", MP OrderID: " + orderJson.getSiteOrderID();

				snsService.notifySupport(notificationMessage, subject);

				return null; // site ID provided is not known
			}

			String caOrderId = String.valueOf(orderJson.getID());

			createdDateCST = convertUTCtoCST(orderJson.getCreatedDateUtc());

			// set order level info
			Order order = factory.createTXMLMessageOrder();
			order.setOrderNumber(factory.createTXMLMessageOrderOrderNumber(siteOrderID)); // OrderNumber
			order.setOrderCaptureDate(factory.createTXMLMessageOrderOrderCaptureDate(createdDateCST)); // OrderCaptureDate
			order.setExternalOrderNumber(factory.createTXMLMessageOrderExternalOrderNumber(caOrderId));// ExternalOrderNumber
			order.setOrderType(factory.createTXMLMessageOrderOrderType(orderType));// OrderType

			BigDecimal orderSubtotal = new BigDecimal("0.00");
			final String ORDER_SITE = "LEVIS-US-STORE";
			final String ORDER_ENTERED_BY = "Channel Advisor";
			final String ORDER_ENTRY_TYPE_WEB = "Web";
			final String ORDER_PAYMENT_STATUS_AUTHORIZED = "AUTHORIZED";

			order.setOrderTotal(factory.createTXMLMessageOrderOrderTotal(getStringAmountValue(orderJson.getTotalPrice()))); // OrderTotal
			order.setSite(factory.createTXMLMessageOrderSite(ORDER_SITE)); // Site
			order.setOrderCurrency(factory.createTXMLMessageOrderOrderCurrency(ORDER_CURRENCY)); // OrderCurrency
			order.setEnteredBy(factory.createTXMLMessageOrderEnteredBy(ORDER_ENTERED_BY)); // EnteredBy
			order.setEntryType(factory.createTXMLMessageOrderEntryType(ORDER_ENTRY_TYPE_WEB)); // EntryType
			order.setConfirmed(factory.createTXMLMessageOrderConfirmed(TRUE_VALUE)); // Confirmed
			order.setCanceled(factory.createTXMLMessageOrderCanceled(FALSE_VALUE)); // Canceled
			order.setOnHold(factory.createTXMLMessageOrderOnHold(FALSE_VALUE)); // OnHold
			order.setPaymentStatus(factory.createTXMLMessageOrderPaymentStatus(ORDER_PAYMENT_STATUS_AUTHORIZED));// PaymentStatus

			order.setCustomerInfo(getCustomerInfo(orderJson));
			order.setPaymentDetails(getPaymentDetails(orderJson, caOrderId, cardType));

			String shippingClass = "";
			// iterate Fulfillments
			for (Fulfillment fulfillmentJson : orderJson.getFulfillments()) {
				shippingClass = fulfillmentJson.getShippingClass(); // pull from 1st Fulfillment element
				break;
			}

//			if (null != shippingClass && !"".equalsIgnoreCase(shippingClass)) {
//				if ("Standard".equalsIgnoreCase(shippingClass)) {
//					shippingClass = IConstants.SHIPPING_CLASS_STANDARD;
//				} else if ("NextDay".equalsIgnoreCase(shippingClass)) {
//					shippingClass = IConstants.SHIPPING_CLASS_NEXT_DAY;
//				} else if ("SecondDay".equalsIgnoreCase(shippingClass) || "Second".equalsIgnoreCase(shippingClass)) {
//					shippingClass = IConstants.SHIPPING_CLASS_SECOND_DAY;
//				} else if ("FreeEconomy".equalsIgnoreCase(shippingClass)) {
//					shippingClass = IConstants.SHIPPING_CLASS_FREE_ECONOMY;
//				} else { // default shipping method
//					shippingClass = IConstants.SHIPPING_CLASS_STANDARD;
//				}
//			} else {
//				shippingClass = IConstants.SHIPPING_CLASS_STANDARD;
//			}

			final String SHIPPING_CLASS_STANDARD = "EEST";
			if (StringUtils.isNullOrEmpty(shippingClass)) {
				shippingClass = SHIPPING_CLASS_STANDARD;
			}

			// set OrderLines
			OrderLines orderLines = factory.createTXMLMessageOrderOrderLines();
			OrderLine orderLine = null;
			PriceInfo priceInfo = null;
			int i = 0;

			// iterate each line items
			final String ORDER_QTY_EOM = "Each";
			for (Item itemJson : orderJson.getItems()) {

				// calculate item level sum/total
				totalItemShippingPrice = totalItemShippingPrice.add(itemJson.getShippingPrice());
				totalItemShippingTaxPrice = totalItemShippingTaxPrice.add(itemJson.getShippingTaxPrice());
				// orderSubtotal = orderSubtotal.add(itemJson.getUnitPrice().multiply(new BigDecimal(itemJson.getQuantity())));

				orderLine = factory.createTXMLMessageOrderOrderLinesOrderLine();
				orderLine.setLineNumber(String.valueOf(++i)); // LineNumber
				orderLine.setExternalLineID(factory.createTXMLMessageOrderOrderLinesOrderLineExternalLineID(String.valueOf(itemJson.getID()))); // ExternalLineID
				orderLine.setItemID(itemJson.getSku()); // ItemID
				orderLine.setExternalItemID(factory.createTXMLMessageOrderOrderLinesOrderLineExternalItemID(String.valueOf(itemJson.getProductID())));// ExternalItemID
				orderLine.setIsGift(factory.createTXMLMessageOrderOrderLinesOrderLineIsGift(FALSE_VALUE)); // IsGift
				orderLine.setLineTotal(
						factory.createTXMLMessageOrderOrderLinesOrderLineLineTotal(getStringAmountValue(itemJson.getUnitPrice().multiply(new BigDecimal(itemJson.getQuantity()))))); // LineTotal
				orderLine.setIsReturnable(factory.createTXMLMessageOrderOrderLinesOrderLineIsReturnable(TRUE_VALUE)); // IsReturnable

				priceInfo = factory.createTXMLMessageOrderOrderLinesOrderLinePriceInfo();
				priceInfo.setPrice(getBigDecimalAmountValue(itemJson.getUnitPrice())); // Price
				BigDecimal totalPromotion = new BigDecimal("0.00");
				// iterate promotion
				if (itemJson.getPromotions() != null) {
					for (Promotion promotionJson : itemJson.getPromotions()) {
						totalPromotion = totalPromotion.add(promotionJson.getAmount().abs());
					}
				}
				log.debug("totalPromotion:" + totalPromotion);
				BigDecimal totalDiscount = totalPromotion.divide(new BigDecimal(itemJson.getQuantity()), 2, RoundingMode.HALF_UP);
				log.debug("getUnitPrice:" + itemJson.getUnitPrice() + " totalDiscount:" + totalDiscount);
				BigDecimal purchasePrice = itemJson.getUnitPrice().subtract(totalDiscount);
				log.debug("purchasePrice:" + purchasePrice);
				priceInfo.setPurchasePrice(factory.createTXMLMessageOrderOrderLinesOrderLinePriceInfoPurchasePrice(getStringAmountValue(purchasePrice))); // PurchasePrice
				orderLine.setPriceInfo(priceInfo);

				BigDecimal extendedPrice = purchasePrice.multiply(new BigDecimal(itemJson.getQuantity()));
				priceInfo.setExtendedPrice(factory.createTXMLMessageOrderOrderLinesOrderLinePriceInfoExtendedPrice(getStringAmountValue(extendedPrice))); // ExtendedPrice

				orderSubtotal = orderSubtotal.add(extendedPrice);

				// set Quantity
				Quantity quantity = factory.createTXMLMessageOrderOrderLinesOrderLineQuantity();
				quantity.setOrderedQty(new BigDecimal(itemJson.getQuantity())); // OrderedQty
				quantity.setOrderedQtyUOM(ORDER_QTY_EOM); // OrderedQtyUOM
				orderLine.setQuantity(quantity);

				LineReferenceFields lineReferenceFields = factory.createTXMLMessageOrderOrderLinesOrderLineLineReferenceFields();
				String referenceField8 = "0";
				if (orderImportLoadConfig.getOrderImportConfig().getMPConfig(orderType).isFreeReturn()) {
					referenceField8 = "1";
				}
				lineReferenceFields.setReferenceField8(factory.createTXMLMessageOrderOrderLinesOrderLineLineReferenceFieldsReferenceField8(referenceField8)); // ReferenceField8
				orderLine.setLineReferenceFields(lineReferenceFields);

				orderLine.setShippingInfo(getShippingInfo(orderJson, shippingClass));
				orderLine.setTaxDetails(getOrderLineTaxDetails(orderJson, itemJson, extendedPrice));

				// Set SmartLabel="Y"
				if (orderType == IConstants.ORDER_TYPE_FB) { // For Facebook
					CustomField cf = factory.createTXMLMessageOrderOrderLinesOrderLineCustomFieldListCustomField();
					cf.setName(factory.createTXMLMessageOrderOrderLinesOrderLineCustomFieldListCustomFieldName("Orderline_IsReturnable"));
					cf.setValue(factory.createTXMLMessageOrderOrderLinesOrderLineCustomFieldListCustomFieldValue("Y"));
					CustomFieldList cfList = factory.createTXMLMessageOrderOrderLinesOrderLineCustomFieldList();
					cfList.getCustomField().add(cf);
					orderLine.setCustomFieldList(cfList);
				}

				orderLines.getOrderLine().add(orderLine);

			}
			order.setOrderLines(orderLines);
			order.setOrderSubtotal(factory.createTXMLMessageOrderOrderSubtotal(getStringAmountValue(orderSubtotal))); // OrderSubtotal
			order.setChargeDetails(getChargeDetails(orderJson, caOrderId, totalItemShippingPrice));
			order.setTaxDetails(getShippingTaxDetails(orderJson, caOrderId, totalItemShippingTaxPrice, totalItemShippingPrice));
			order.setReferenceFields(getReferenceFields(orderType));

			// generate message
			Message message = factory.createTXMLMessage();
			message.setOrder(order);
			txml.setMessage(message);
			txml.setHeader(getHeader(source, siteOrderID));
			return txml;
		} catch (Exception e) {
			log.error("***Exception occured while converting from json to xml, Order Id: " + orderJson.getID() + " and SiteOrderID:" + orderJson.getSiteOrderID(), e);

			String notificationMessage = "Exception occured while converting from json to xml, Order Id:" + orderJson.getID() + " and SiteOrderID:" + orderJson.getSiteOrderID()
					+ System.lineSeparator() + "Error Message: " + System.lineSeparator() + ExceptionUtils.getStackTrace(e);

			String subject = "[MP-OrderImport]:Exception occured while converting from json to xml, OrderId:" + orderJson.getID();

			snsService.notifySupport(notificationMessage, subject);

			return null;
		}

	}

	/**
	 * 
	 * @param orderJson
	 * @param itemJson
	 * @param extendedPrice
	 * @return
	 * @throws ParseException
	 */
	private com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.TaxDetails getOrderLineTaxDetails(ChannelAdvisorOrder orderJson, Item itemJson, BigDecimal extendedPrice)
			throws ParseException {
		final String ORDER_LINE_TAX_CATEGORY = "Sales Tax";
		final String ORDER_LINE_TAX_NAME = "State-Sales Tax";

		com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.TaxDetails orderLineTaxDetails = factory.createTXMLMessageOrderOrderLinesOrderLineTaxDetails();

		com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine.TaxDetails.TaxDetail orderLineTaxDetail = factory.createTXMLMessageOrderOrderLinesOrderLineTaxDetailsTaxDetail();

		// add tax Order Line Level
		orderLineTaxDetail.setExtTaxDetailId("Tax-" + itemJson.getID()); // ExtTaxDetailId
		orderLineTaxDetail.setTaxCategory(ORDER_LINE_TAX_CATEGORY); // TaxCategory
		orderLineTaxDetail.setTaxName(ORDER_LINE_TAX_NAME);// TaxName
		orderLineTaxDetail.setTaxAmount(getBigDecimalAmountValue(itemJson.getTaxPrice()));// TaxAmount
		orderLineTaxDetail.setTaxRate(factory.createTXMLMessageOrderOrderLinesOrderLineTaxDetailsTaxDetailTaxRate(String.valueOf(0)));// TaxRate
		orderLineTaxDetail.setTaxableAmount(factory.createTXMLMessageOrderOrderLinesOrderLineTaxDetailsTaxDetailTaxableAmount(getStringAmountValue(extendedPrice))); // TaxableAmount
		orderLineTaxDetail.setTaxDTTM(createdDateCST);

		orderLineTaxDetails.getTaxDetail().add(orderLineTaxDetail);
		return orderLineTaxDetails;

	}

	private ShippingInfo getShippingInfo(ChannelAdvisorOrder orderJson, String shippingClass) {
		final String DELIVERY_OPTION_SHIP_TO_ADDRESS = "Ship to address";

		ShippingInfo shippingInfo = factory.createTXMLMessageOrderOrderLinesOrderLineShippingInfo();
		// getting shipping class from Order level Fulfillments[]
		shippingInfo.setShipVia(factory.createTXMLMessageOrderOrderLinesOrderLineShippingInfoShipVia(shippingClass)); // ShipVia
		shippingInfo.setDeliveryOption(factory.createTXMLMessageOrderOrderLinesOrderLineShippingInfoDeliveryOption(DELIVERY_OPTION_SHIP_TO_ADDRESS)); // DeliveryOption

		ShippingAddress shippingAddress = factory.createTXMLMessageOrderOrderLinesOrderLineShippingInfoShippingAddress();
		shippingAddress.setShipToFirstName(orderJson.getShippingFirstName()); // ShipToFirstName
		shippingAddress.setShipToLastName(orderJson.getShippingLastName()); // ShipToLastName
		shippingAddress.setShipToAddressLine1(orderJson.getShippingAddressLine1()); // ShipToAddressLine1
		shippingAddress.setShipToAddressLine2(factory.createTXMLMessageOrderOrderLinesOrderLineShippingInfoShippingAddressShipToAddressLine2(orderJson.getShippingAddressLine2())); // ShipToAddressLine2
		shippingAddress.setShipToCity(orderJson.getShippingCity()); // ShipToCity
		shippingAddress.setShipToState(orderJson.getShippingStateOrProvince()); // ShipToState
		shippingAddress.setShipToPostalCode(orderJson.getShippingPostalCode()); // ShipToPostalCode
		shippingAddress.setShipToCountry(orderJson.getShippingCountry()); // ShipToCountry
		shippingAddress.setShipToPhone(factory.createTXMLMessageOrderOrderLinesOrderLineShippingInfoShippingAddressShipToPhone(orderJson.getShippingDaytimePhone())); // ShipToPhone
		shippingAddress.setShipToEmail(factory.createTXMLMessageOrderOrderLinesOrderLineShippingInfoShippingAddressShipToEmail(orderJson.getBuyerEmailAddress())); // ShipToEmail
		shippingInfo.setShippingAddress(shippingAddress);
		return shippingInfo;
	}

	/**
	 * 
	 * @return
	 */
	private ReferenceFields getReferenceFields(String orderType) {
		final String REFERENCE_FIELD_2 = "L";
		final String REFERENCE_FIELD_9 = "OMS_MANH_DOM_FULL_LC";
		final String REFERENCE_FIELD_10 = "SUBMIT_ORDER_CONFIRMED";
		String REFERENCE_NO_1 = "0.0";
		final String REFERENCE_NO_3 = "1";

		if (!orderImportLoadConfig.getOrderImportConfig().getMPConfig(orderType).isFreeReturn()) {
			REFERENCE_NO_1 = getStringAmountValue(orderImportLoadConfig.getOrderImportConfig().getMPConfig(orderType).getSmartLabelFee());
		}

		// set ReferenceFields
		ReferenceFields referenceFields = factory.createTXMLMessageOrderReferenceFields();
		referenceFields.setReferenceField2(factory.createTXMLMessageOrderReferenceFieldsReferenceField2(REFERENCE_FIELD_2)); // ReferenceField2
		referenceFields.setReferenceField9(factory.createTXMLMessageOrderReferenceFieldsReferenceField9(REFERENCE_FIELD_9)); // ReferenceField9
		referenceFields.setReferenceField10(factory.createTXMLMessageOrderReferenceFieldsReferenceField10(REFERENCE_FIELD_10)); // ReferenceField10
		referenceFields.setReferenceNumber1(factory.createTXMLMessageOrderReferenceFieldsReferenceNumber1(REFERENCE_NO_1)); // ReferenceNumber1
		referenceFields.setReferenceNumber3(factory.createTXMLMessageOrderReferenceFieldsReferenceNumber3(REFERENCE_NO_3)); // ReferenceNumber3
		return referenceFields;
	}

	/**
	 * 
	 * @param orderJson
	 * @param caOrderId
	 * @param totalItemShippingTaxPrice
	 * @param totalItemShippingPrice
	 * @return
	 * @throws ParseException
	 */
	private TaxDetails getShippingTaxDetails(ChannelAdvisorOrder orderJson, String caOrderId, BigDecimal totalItemShippingTaxPrice, BigDecimal totalItemShippingPrice) throws ParseException {
		final String TAX_CATEGORY = "Freight Tax";
		final String TAX_CHARGE_CATEGORY = "Shipping";
		final String TAX_NAMES_STATE = "State";
		final String TAX_NAME = "-Shipping Tax";
		// set TaxDetails
		TaxDetails shippingTaxDetails = factory.createTXMLMessageOrderTaxDetails();

		TaxDetail shippingTaxDetail = factory.createTXMLMessageOrderTaxDetailsTaxDetail();
		shippingTaxDetail.setExtTaxDetailId(caOrderId + "-SHIPPING-" + 1); // ExtTaxDetailId
		shippingTaxDetail.setTaxCategory(TAX_CATEGORY); // Freight Tax
		shippingTaxDetail.setChargeCategory(factory.createTXMLMessageOrderTaxDetailsTaxDetailChargeCategory(TAX_CHARGE_CATEGORY)); // ChargeCategory
		shippingTaxDetail.setTaxName(TAX_NAMES_STATE + TAX_NAME); // TaxName
		shippingTaxDetail.setTaxAmount(getBigDecimalAmountValue(orderJson.getTotalShippingTaxPrice())); // TaxAmount
		shippingTaxDetail.setTaxableAmount(factory.createTXMLMessageOrderTaxDetailsTaxDetailTaxableAmount(getStringAmountValue(orderJson.getTotalShippingPrice()))); // TaxableAmount
		shippingTaxDetail.setTaxDTTM(createdDateCST); // TaxDTTM
		shippingTaxDetails.getTaxDetail().add(shippingTaxDetail);
		return shippingTaxDetails;
	}

	/**
	 * 
	 * @param orderJson
	 * @param caOrderId
	 * @param totalItemShippingPrice
	 * @return
	 */
	private ChargeDetails getChargeDetails(ChannelAdvisorOrder orderJson, String caOrderId, BigDecimal totalItemShippingPrice) {
		final String CHARGE_CATEGORY = "Shipping";
		final String CHARGE_NAME = "Shipping-Fee";
		final String UNIT_CHARGE = "0.00";

		// set ChargeDetails
		ChargeDetails chargeDetails = factory.createTXMLMessageOrderChargeDetails();
		ChargeDetail chargeDetail = factory.createTXMLMessageOrderChargeDetailsChargeDetail();
		chargeDetail.setExtChargeDetailId("SHIPPING-FEE-" + caOrderId); // ExtChargeDetailId
		chargeDetail.setChargeCategory(CHARGE_CATEGORY); // ChargeCategory
		chargeDetail.setChargeName(factory.createTXMLMessageOrderChargeDetailsChargeDetailChargeName(CHARGE_NAME)); // ChargeName
		BigDecimal chargeAmount = orderJson.getTotalShippingPrice(); // orderJson.getTotalShippingPrice().add(totalItemShippingPrice);
		log.debug("chargeAmount>>>" + getBigDecimalAmountValue(chargeAmount));
		chargeDetail.setChargeAmount(getBigDecimalAmountValue(chargeAmount)); // ChargeAmount
		chargeDetail.setUnitCharge(factory.createTXMLMessageOrderChargeDetailsChargeDetailUnitCharge(UNIT_CHARGE)); // UnitCharge
		chargeDetails.getChargeDetail().add(chargeDetail);
		return chargeDetails;
	}

	/**
	 * 
	 * @param source
	 * @param siteOrderID
	 * @return
	 */
	private Header getHeader(String source, String siteOrderID) {
		final String ACTION_TYPE = "Update";
		final String MESSAGE_TYPE = "Customer_Order_Import";
		final String COMPANY_ID = "1";

		final String HEADER_LOCAL_MESSAGE = "English (United States)";
		final String HEADER_MESSAGE_TIME_ZONE = "Etc/UTC";
		// generate header
		Header header = factory.createTXMLHeader();
		header.setSource(source); // Source
		header.setActionType(ACTION_TYPE); // Action_Type
		header.setReferenceID(factory.createTXMLHeaderReferenceID(siteOrderID)); // Reference_ID
		header.setMessageType(MESSAGE_TYPE); // Message_Type
		header.setCompanyID(COMPANY_ID); // Company_ID
		header.setMsgLocale(factory.createTXMLHeaderMsgLocale(HEADER_LOCAL_MESSAGE)); // Msg_Locale
		header.setMsgTimeZone(factory.createTXMLHeaderMsgTimeZone(HEADER_MESSAGE_TIME_ZONE)); // Msg_Time_Zone
		return header;
	}

	/**
	 * 
	 * @param orderJson
	 * @param caOrderId
	 * @param cardType
	 * @return
	 * @throws ParseException
	 */
	private PaymentDetails getPaymentDetails(ChannelAdvisorOrder orderJson, String caOrderId, String cardType) throws ParseException {
		final String PAYMENT_ENTRY_TYPE_WEB = "Web";
		final String REQ_SETTLEMENT_AMOUT = "0.00";
		final String DATA_SECURITY = "Tokenized";
		final String PAYMENT_METHOD_CREDIT_CARD = "Credit Card";
		final String TRANSACTION_TYPE = "Authorization";
		final String ACCOUNT_DISPLAY_NO = "xxxxxxxxxxxx0000";

		// set PaymentDetails
		PaymentDetails paymentDetails = factory.createTXMLMessageOrderPaymentDetails();
		PaymentDetail paymentDetail = factory.createTXMLMessageOrderPaymentDetailsPaymentDetail();
		paymentDetail.setExternalPaymentDetailId(caOrderId);// ExternalPaymentDetailId
		paymentDetail.setPaymentMethod(PAYMENT_METHOD_CREDIT_CARD);// PaymentMethod
		paymentDetail.setCardType(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailCardType(cardType));// CardType
		paymentDetail.setAccountNumber(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailAccountNumber(caOrderId));// AccountNumber
		paymentDetail.setAccountDisplayNumber(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailAccountDisplayNumber(ACCOUNT_DISPLAY_NO)); // AccountDisplayNumber
		paymentDetail.setPaymentEntryType(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentEntryType(PAYMENT_ENTRY_TYPE_WEB));// PaymentEntryType
		paymentDetail.setReqAuthorizationAmount(getBigDecimalAmountValue(orderJson.getTotalPrice())); // ReqAuthorizationAmount
		paymentDetail.setReqSettlementAmount(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailReqSettlementAmount(REQ_SETTLEMENT_AMOUT)); // ReqSettlementAmount
		paymentDetail.setCurrencyCode(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailCurrencyCode(ORDER_CURRENCY)); // CurrencyCode
		paymentDetail.setChargeSequence(BigInteger.valueOf(1)); // ChargeSequence
		paymentDetail.setDataSecurity(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailDataSecurity(DATA_SECURITY)); // DataSecurity

		// set BillToDetail
		BillToDetail billToDetail = factory.createTXMLMessageOrderPaymentDetailsPaymentDetailBillToDetail();
		billToDetail
				.setBillToFirstName((orderJson.getBillingFirstName() != null && "" != orderJson.getBillingFirstName()) ? orderJson.getBillingFirstName() : orderJson.getShippingFirstName()); // BillToFirstName
		billToDetail.setBillToLastName((orderJson.getBillingLastName() != null && "" != orderJson.getBillingLastName()) ? orderJson.getBillingLastName() : orderJson.getShippingLastName()); // BillToLastName
		billToDetail.setBillToAddressLine1(orderJson.getBillingAddressLine1()); // BillToAddressLine1
		billToDetail.setBillToAddressLine2(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailBillToDetailBillToAddressLine2(orderJson.getBillingAddressLine2())); // BillToAddressLine2
		billToDetail.setBillToCity(orderJson.getBillingCity()); // BillToCity
		billToDetail.setBillToState(orderJson.getBillingStateOrProvince()); // BillToState
		billToDetail.setBillToPostalCode(orderJson.getBillingPostalCode()); // BillToPostalCode
		billToDetail.setBillToCountry(orderJson.getBillingCountry()); // BillToCountry
		billToDetail.setBillToPhone(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailBillToDetailBillToPhone(orderJson.getBillingDaytimePhone())); // BillToPhone
		billToDetail.setBillToEmail(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailBillToDetailBillToEmail(orderJson.getBuyerEmailAddress())); // BillToEmail
		paymentDetail.setBillToDetail(billToDetail);

		// set PaymentTransactionDetails
		final String TRANSACTION_DECISION_SUCCESS = "Success";
		final String TRANSACTION_DECISION_DESC = "100";

		PaymentTransactionDetails paymentTransactionDetails = factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentTransactionDetails();

		PaymentTransactionDetail paymentTransactionDetail = factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentTransactionDetailsPaymentTransactionDetail();
		paymentTransactionDetail.setExternalPaymentTransactionId(caOrderId); // ExternalPaymentTransactionId
		paymentTransactionDetail.setTransactionType(TRANSACTION_TYPE); // TransactionType
		paymentTransactionDetail.setRequestedAmount(getBigDecimalAmountValue(orderJson.getTotalPrice())); // RequestedAmount
		paymentTransactionDetail.setRequestId(caOrderId); // RequestId
		paymentTransactionDetail.setRequestToken(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentTransactionDetailsPaymentTransactionDetailRequestToken(caOrderId)); // RequestToken
		paymentTransactionDetail.setFollowOnId(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentTransactionDetailsPaymentTransactionDetailFollowOnId(caOrderId)); // FollowOnId
		paymentTransactionDetail.setFollowOnToken(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentTransactionDetailsPaymentTransactionDetailFollowOnToken(caOrderId)); // FollowOnToken
		paymentTransactionDetail.setRequestedDTTM(createdDateCST); // RequestedDTTM
		paymentTransactionDetail.setProcessedAmount(
				factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentTransactionDetailsPaymentTransactionDetailProcessedAmount(getStringAmountValue(orderJson.getTotalPrice()))); // ProcessedAmount
		paymentTransactionDetail.setTransactionDTTM(createdDateCST); // TransactionDTTM
		String trasacExpDateCST = getTransactionExpiryDate(createdDateCST);
		log.debug("trasacExpDateCST>>>" + trasacExpDateCST);
		paymentTransactionDetail
				.setTransactionExpiryDate(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentTransactionDetailsPaymentTransactionDetailTransactionExpiryDate(trasacExpDateCST)); // TransactionExpiryDate
		paymentTransactionDetail.setReconciliationId(factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentTransactionDetailsPaymentTransactionDetailReconciliationId(caOrderId)); // ReconciliationId
		paymentTransactionDetail.setTransactionDecision(TRANSACTION_DECISION_SUCCESS); // TransactionDecision
		paymentTransactionDetail.setTransactionDecisionDescription(
				factory.createTXMLMessageOrderPaymentDetailsPaymentDetailPaymentTransactionDetailsPaymentTransactionDetailTransactionDecisionDescription(TRANSACTION_DECISION_DESC)); // TransactionDecisionDescription

		paymentTransactionDetails.getPaymentTransactionDetail().add(paymentTransactionDetail);
		paymentDetail.setPaymentTransactionDetails(paymentTransactionDetails);

		paymentDetails.getPaymentDetail().add(paymentDetail);
		return paymentDetails;
	}

	/**
	 * 
	 * @param orderJson
	 * @return
	 */
	private CustomerInfo getCustomerInfo(ChannelAdvisorOrder orderJson) {
		CustomerInfo customerInfo = factory.createTXMLMessageOrderCustomerInfo();
		customerInfo.setCustomerFirstName(factory.createTXMLMessageOrderCustomerInfoCustomerFirstName(orderJson.getShippingFirstName())); // CustomerFirstName
		customerInfo.setCustomerLastName(factory.createTXMLMessageOrderCustomerInfoCustomerLastName(orderJson.getShippingLastName())); // CustomerLastName
		customerInfo.setCustomerPhone(factory.createTXMLMessageOrderCustomerInfoCustomerPhone(orderJson.getShippingDaytimePhone())); // CustomerPhone
		customerInfo.setCustomerEmail(factory.createTXMLMessageOrderCustomerInfoCustomerEmail(orderJson.getBuyerEmailAddress())); // CustomerEmail
		return customerInfo;
	}

	/**
	 * Convert and return BigDecimal Amount to String with 2 decimals
	 * 
	 * @param bd
	 * @return
	 */
	public String getStringAmountValue(BigDecimal bd) {
		DecimalFormat df = new DecimalFormat("0.00");
		return df.format(bd);
	}

	/**
	 * Return BigDecimal Amount with 2 decimals
	 * 
	 * @param bd
	 * @return
	 */
	public BigDecimal getBigDecimalAmountValue(BigDecimal bd) {
		return bd.setScale(2, BigDecimal.ROUND_HALF_DOWN);
	}

	private final String ORDER_CURRENCY = "USD";

}
