
package com.levi.mp.order.model.json;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Component
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ID", "Code", "Amount", "ShippingAmount" })
public class Promotion implements Serializable {

	@JsonProperty("ID")
	private long iD;
	@JsonProperty("Code")
	private String code;
	@JsonProperty("Amount")
	private BigDecimal amount;
	@JsonProperty("ShippingAmount")
	private long shippingAmount;
	private final static long serialVersionUID = -363866303941004385L;

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public Promotion() {
	}

	/**
	 * 
	 * @param amount
	 * @param shippingAmount
	 * @param code
	 * @param iD
	 */
	public Promotion(long iD, String code, BigDecimal amount, long shippingAmount) {
		super();
		this.iD = iD;
		this.code = code;
		this.amount = amount;
		this.shippingAmount = shippingAmount;
	}

	@JsonProperty("ID")
	public long getID() {
		return iD;
	}

	@JsonProperty("ID")
	public void setID(long iD) {
		this.iD = iD;
	}

	@JsonProperty("Code")
	public String getCode() {
		return code;
	}

	@JsonProperty("Code")
	public void setCode(String code) {
		this.code = code;
	}

	@JsonProperty("Amount")
	public BigDecimal getAmount() {
		return amount;
	}

	@JsonProperty("Amount")
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	@JsonProperty("ShippingAmount")
	public long getShippingAmount() {
		return shippingAmount;
	}

	@JsonProperty("ShippingAmount")
	public void setShippingAmount(long shippingAmount) {
		this.shippingAmount = shippingAmount;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("iD", iD).append("code", code).append("amount", amount).append("shippingAmount", shippingAmount)
				.toString();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(amount).append(shippingAmount).append(code).append(iD).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof Promotion) == false) {
			return false;
		}
		Promotion rhs = ((Promotion) other);
		return new EqualsBuilder().append(amount, rhs.amount).append(shippingAmount, rhs.shippingAmount).append(code, rhs.code).append(iD, rhs.iD)
				.isEquals();
	}

}
