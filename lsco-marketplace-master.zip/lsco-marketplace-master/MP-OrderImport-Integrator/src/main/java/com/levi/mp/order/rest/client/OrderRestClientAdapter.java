package com.levi.mp.order.rest.client;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.order.model.json.Orders;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class OrderRestClientAdapter {
	
	/**
	 * Get all the orders those are not exported from CA
	 * 
	 * @param accessToken
	 * @return
	 * @throws Exception
	 */
	public Orders getUnexportedOrders() {
		
		String caAccessToken = advisorTokenService.getOAuth2Token();

		final String URL = "https://api.channeladvisor.com/v1/Orders?access_token=" + caAccessToken
				+ "&exported=false&$expand=Items($expand=Promotions),Fulfillments&$filter=CheckoutStatus eq 'Completed' and PaymentStatus eq 'Cleared' and ShippingStatus eq 'Unshipped'";
		// setup header
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", org.springframework.http.MediaType.APPLICATION_JSON_VALUE);

		HttpEntity<?> httpEntityRequest = new HttpEntity<>(headers);
		// make the rest call
		ResponseEntity<String> restResponse = restTemplate.exchange(URL, HttpMethod.GET, httpEntityRequest, String.class);

		if (!restResponse.getStatusCode().equals(HttpStatus.OK)) {
			log.error("Error occured while fetching Orders from Channel Advisor, Response status: " + restResponse.getStatusCode());
			throw new RuntimeException("Error occured while fetching Orders from Channel Advisor");
		}

		//log.debug("Reponse data from Order Call>>>\n" + restResponse);
		ObjectMapper objectMapper = new ObjectMapper();

		Orders orders;
		try {
			orders = objectMapper.readValue(restResponse.getBody(), Orders.class);

		} catch (IOException e) {
			throw new RuntimeException("Could not map Channel Advisor orders to Orders class", e);
		}

		String nextLink = orders.getOdataNextLink();
		Orders nextOrders = null;
		while (!StringUtils.isEmpty(nextLink)) {
			log.debug("Invoking CA API for getting next set of Order with url: " + nextLink);
			nextOrders = getNextUnexportedOrders(nextLink);
			nextLink = nextOrders.getOdataNextLink();
			orders.getCaOrders().addAll(nextOrders.getCaOrders());
		}

		return orders;
	}

	/**
	 * Get next set of orders those are not exported from CA
	 * 
	 * @param url
	 * @return
	 */
	public Orders getNextUnexportedOrders(String url) {

		// setup header
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
		UriComponentsBuilder uriComponentsBuilder;
		try {
			uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(URLDecoder.decode(url, "UTF-8"));
		} catch (UnsupportedEncodingException e1) {
			throw new RuntimeException("Invalid URL", e1);
		}

		HttpEntity<?> httpEntityRequest = new HttpEntity<>(headers);
		// make the rest call
		ResponseEntity<String> restResponse = restTemplate.exchange(uriComponentsBuilder.build().toString(), HttpMethod.GET, httpEntityRequest, String.class);

		if (!restResponse.getStatusCode().equals(HttpStatus.OK)) {
			log.error("Error occured while fetching next set of Orders from Channel Advisor, Response status: " + restResponse.getStatusCode());
			throw new RuntimeException("Error occured while fetching next set of Orders from Channel Advisor");
		}

		//log.debug("Reponse data from next of Order Call>>>\n" + restResponse);
		ObjectMapper objectMapper = new ObjectMapper();

		Orders orders;
		try {
			orders = objectMapper.readValue(restResponse.getBody(), Orders.class);
			return orders;
		} catch (IOException e) {
			throw new RuntimeException("Could not map Channel Advisor orders to Orders class", e);
		}
	}

	/**
	 * 
	 * @param accessToken
	 * @param orderId
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public boolean updateOrderSatusFlag(String orderId, String caAccessToken) {
//		final String caAccessToken = advisorTokenService.getOAuth2Token();

		String URL = "https://api.channeladvisor.com/v1/Orders(" + orderId + ")/Export?access_token=" + caAccessToken;
		log.debug("Updating order export flag to true for CA Order id:>>>" + orderId);

		// setup header
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", org.springframework.http.MediaType.APPLICATION_JSON_VALUE);

		HttpEntity<?> httpEntityRequest = new HttpEntity<>(headers);

		// make the rest call
		ResponseEntity<String> restResponse = restTemplate.exchange(URL, HttpMethod.POST, httpEntityRequest, String.class);

		if (!restResponse.getStatusCode().equals(HttpStatus.NO_CONTENT)) {
			log.error("Error while calling CA Order status export Flag API, Response status: " + restResponse.getStatusCode());
			throw new RuntimeException("Error while calling CA Order status export Flag API");
		}

		return Boolean.TRUE;
	}

	@Autowired
	ChannelAdvisorTokenService advisorTokenService;

	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	SNSService snsService;
	
	/*@PostConstruct
	public void init() {
		try {
			caAccessToken = advisorTokenService.getOAuth2Token();
			log.debug("Setting CA Token>>>");
		} catch (Exception e) {
			String notificationMessage = 
					"Exception occured in Order Import while calling CA OAuth2Token:"
					+ System.lineSeparator()
					+"Error Message: "
					+ System .lineSeparator()
					+ExceptionUtils.getStackTrace(e);
			String subject = "[MP-OrderImport]: Exception occured in Order Import while calling CA OAuth2Token";
			snsService.notifySupport(notificationMessage, subject);
			
			throw new RuntimeException(e);
		}
		
	}*/

}
