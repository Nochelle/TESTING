
package com.levi.mp.order.model.json;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Component
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ID",
    "ProfileID",
    "OrderID",
    "CreatedDateUtc",
    "UpdatedDateUtc",
    "Type",
    "DeliveryStatus",
    "TrackingNumber",
    "ShippingCarrier",
    "ShippingClass",
    "DistributionCenterID",
    "ShippedDateUtc",
    "SellerFulfillmentID"
})
public class Fulfillment implements Serializable
{

    @JsonProperty("ID")
    private long iD;
    @JsonProperty("ProfileID")
    private long profileID;
    @JsonProperty("OrderID")
    private long orderID;
    @JsonProperty("CreatedDateUtc")
    private String createdDateUtc;
    @JsonProperty("UpdatedDateUtc")
    private String updatedDateUtc;
    @JsonProperty("Type")
    private String type;
    @JsonProperty("DeliveryStatus")
    private String deliveryStatus;
    @JsonProperty("TrackingNumber")
    private Object trackingNumber;
    @JsonProperty("ShippingCarrier")
    private Object shippingCarrier;
    @JsonProperty("ShippingClass")
    private String shippingClass;
    @JsonProperty("DistributionCenterID")
    private long distributionCenterID;
    @JsonProperty("ShippedDateUtc")
    private Object shippedDateUtc;
    @JsonProperty("SellerFulfillmentID")
    private Object sellerFulfillmentID;
    private final static long serialVersionUID = 6665673302084779702L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Fulfillment() {
    }

    /**
     * 
     * @param shippingClass
     * @param shippedDateUtc
     * @param orderID
     * @param trackingNumber
     * @param profileID
     * @param sellerFulfillmentID
     * @param distributionCenterID
     * @param shippingCarrier
     * @param updatedDateUtc
     * @param type
     * @param iD
     * @param deliveryStatus
     * @param createdDateUtc
     */
    public Fulfillment(long iD, long profileID, long orderID, String createdDateUtc, String updatedDateUtc, String type, String deliveryStatus, Object trackingNumber, Object shippingCarrier, String shippingClass, long distributionCenterID, Object shippedDateUtc, Object sellerFulfillmentID) {
        super();
        this.iD = iD;
        this.profileID = profileID;
        this.orderID = orderID;
        this.createdDateUtc = createdDateUtc;
        this.updatedDateUtc = updatedDateUtc;
        this.type = type;
        this.deliveryStatus = deliveryStatus;
        this.trackingNumber = trackingNumber;
        this.shippingCarrier = shippingCarrier;
        this.shippingClass = shippingClass;
        this.distributionCenterID = distributionCenterID;
        this.shippedDateUtc = shippedDateUtc;
        this.sellerFulfillmentID = sellerFulfillmentID;
    }

    @JsonProperty("ID")
    public long getID() {
        return iD;
    }

    @JsonProperty("ID")
    public void setID(long iD) {
        this.iD = iD;
    }

    @JsonProperty("ProfileID")
    public long getProfileID() {
        return profileID;
    }

    @JsonProperty("ProfileID")
    public void setProfileID(long profileID) {
        this.profileID = profileID;
    }

    @JsonProperty("OrderID")
    public long getOrderID() {
        return orderID;
    }

    @JsonProperty("OrderID")
    public void setOrderID(long orderID) {
        this.orderID = orderID;
    }

    @JsonProperty("CreatedDateUtc")
    public String getCreatedDateUtc() {
        return createdDateUtc;
    }

    @JsonProperty("CreatedDateUtc")
    public void setCreatedDateUtc(String createdDateUtc) {
        this.createdDateUtc = createdDateUtc;
    }

    @JsonProperty("UpdatedDateUtc")
    public String getUpdatedDateUtc() {
        return updatedDateUtc;
    }

    @JsonProperty("UpdatedDateUtc")
    public void setUpdatedDateUtc(String updatedDateUtc) {
        this.updatedDateUtc = updatedDateUtc;
    }

    @JsonProperty("Type")
    public String getType() {
        return type;
    }

    @JsonProperty("Type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("DeliveryStatus")
    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    @JsonProperty("DeliveryStatus")
    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    @JsonProperty("TrackingNumber")
    public Object getTrackingNumber() {
        return trackingNumber;
    }

    @JsonProperty("TrackingNumber")
    public void setTrackingNumber(Object trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    @JsonProperty("ShippingCarrier")
    public Object getShippingCarrier() {
        return shippingCarrier;
    }

    @JsonProperty("ShippingCarrier")
    public void setShippingCarrier(Object shippingCarrier) {
        this.shippingCarrier = shippingCarrier;
    }

    @JsonProperty("ShippingClass")
    public String getShippingClass() {
        return shippingClass;
    }

    @JsonProperty("ShippingClass")
    public void setShippingClass(String shippingClass) {
        this.shippingClass = shippingClass;
    }

    @JsonProperty("DistributionCenterID")
    public long getDistributionCenterID() {
        return distributionCenterID;
    }

    @JsonProperty("DistributionCenterID")
    public void setDistributionCenterID(long distributionCenterID) {
        this.distributionCenterID = distributionCenterID;
    }

    @JsonProperty("ShippedDateUtc")
    public Object getShippedDateUtc() {
        return shippedDateUtc;
    }

    @JsonProperty("ShippedDateUtc")
    public void setShippedDateUtc(Object shippedDateUtc) {
        this.shippedDateUtc = shippedDateUtc;
    }

    @JsonProperty("SellerFulfillmentID")
    public Object getSellerFulfillmentID() {
        return sellerFulfillmentID;
    }

    @JsonProperty("SellerFulfillmentID")
    public void setSellerFulfillmentID(Object sellerFulfillmentID) {
        this.sellerFulfillmentID = sellerFulfillmentID;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("iD", iD).append("profileID", profileID).append("orderID", orderID).append("createdDateUtc", createdDateUtc).append("updatedDateUtc", updatedDateUtc).append("type", type).append("deliveryStatus", deliveryStatus).append("trackingNumber", trackingNumber).append("shippingCarrier", shippingCarrier).append("shippingClass", shippingClass).append("distributionCenterID", distributionCenterID).append("shippedDateUtc", shippedDateUtc).append("sellerFulfillmentID", sellerFulfillmentID).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(shippedDateUtc).append(orderID).append(sellerFulfillmentID).append(type).append(iD).append(createdDateUtc).append(shippingClass).append(trackingNumber).append(profileID).append(distributionCenterID).append(shippingCarrier).append(updatedDateUtc).append(deliveryStatus).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Fulfillment) == false) {
            return false;
        }
        Fulfillment rhs = ((Fulfillment) other);
        return new EqualsBuilder().append(shippedDateUtc, rhs.shippedDateUtc).append(orderID, rhs.orderID).append(sellerFulfillmentID, rhs.sellerFulfillmentID).append(type, rhs.type).append(iD, rhs.iD).append(createdDateUtc, rhs.createdDateUtc).append(shippingClass, rhs.shippingClass).append(trackingNumber, rhs.trackingNumber).append(profileID, rhs.profileID).append(distributionCenterID, rhs.distributionCenterID).append(shippingCarrier, rhs.shippingCarrier).append(updatedDateUtc, rhs.updatedDateUtc).append(deliveryStatus, rhs.deliveryStatus).isEquals();
    }

}
