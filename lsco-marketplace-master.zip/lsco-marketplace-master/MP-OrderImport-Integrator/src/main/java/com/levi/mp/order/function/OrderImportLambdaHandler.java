package com.levi.mp.order.function;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.levi.mp.order.service.OrderImportService;
import com.levi.mp.order.util.OrderImportUtil;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

/**
 * AWS Lambda Handler that also initializes Spring's ApplicationContext for wiring beans.
 * 
 * @author Vinay A. Jain
 *
 */
@Component
@Log4j2
public class OrderImportLambdaHandler implements RequestHandler<Object, String> {

	ApplicationContext getApplicationContext() {
		return new AnnotationConfigApplicationContext("com.levi.mp");
	}

	@Override
	public String handleRequest(Object input, Context context) {
		log.debug("OrderImportLambdaHandler.handleRequest(), input:" + input);
		
		try {
			long startTime = System.nanoTime();
			
			ApplicationContext applicationContext = getApplicationContext();
			
			orderImportService = applicationContext.getBean(OrderImportService.class);
			snsService = applicationContext.getBean(SNSService.class);
			orderImportUtil = applicationContext.getBean(OrderImportUtil.class);
			
			orderImportService.processNewOrders();
			
			long difference = System.nanoTime() - startTime;
			log.info("Total time taken for OrderImportLambdaHandler (in seconds): "+ TimeUnit.MILLISECONDS.convert(difference, TimeUnit.SECONDS));
			
			//Change for printing process info in lambda output
			String processInfo = 
					"Order Import Job successfully Completed"
					+System.lineSeparator()
					+"-----OrderImport Process Statistics:-----"
					+ System.lineSeparator()
					+orderImportService.getOrderImportProcesInfo(); 
			
			return processInfo;
			
		} catch (Exception e) {
			log.error("Error occured while importing orders, "+e.getMessage());
			//Notify Support
			log.debug("Sending notification to support team");
			try {
				String notificationMessage = 
					"Exception occured while Order Import:"
					+ System.lineSeparator()
					+"Error Message: "
					+ System .lineSeparator()
					+ExceptionUtils.getStackTrace(e);
				String subject = "[MP-OrderImport]: "+e.getMessage();
				snsService.notifySupport(notificationMessage, subject);
			}catch(Exception e1) {
				log.error("Error occured while sending notification to support team", e1);
			}
			return "Error occured while importing orders" + e.getMessage();
		}
	}

	@Autowired
	private OrderImportService orderImportService;
	
	@Autowired
	SNSService snsService;
	
	OrderImportUtil orderImportUtil;
	
}
