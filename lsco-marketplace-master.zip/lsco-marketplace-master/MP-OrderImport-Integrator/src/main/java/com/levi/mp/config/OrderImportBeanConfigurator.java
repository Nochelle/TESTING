package com.levi.mp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.ibm.mq.jms.MQQueueConnectionFactory;

/**
 * Create bean for external Classes so that they can be injected using spring Autowired 
 * This is a @Configuration class
 * @author Prabir Nandi
 *
 */
@Configuration
public class OrderImportBeanConfigurator {
	
	@Bean
	MQQueueConnectionFactory mqQueueConnectionFactory(){
		return new MQQueueConnectionFactory();
	}
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
