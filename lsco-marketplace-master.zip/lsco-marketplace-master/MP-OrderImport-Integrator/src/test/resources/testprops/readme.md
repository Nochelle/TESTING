Below is the EOM details that needs to be changed for Sprint-001 in the testconfig.json file
   "EOMURL":"https://sprint-001-eom.levi-site.com",
   "EOMUSER":"aganguly1",
   "EOMPWD":"Test"

Below is the EOM details that needs to be changed for reg-100 in the testconfig.json file   
   "EOMURL":"https://reg-100-eom.levi-site.com",
   "EOMUSER":"9gang34",
   "EOMPWD":"Password14"
   
   
   
Below is the EOM details that needs to be changed for Sprint-001 in the testProp.properties files  
   test.EOMURL=https://sprint-001-eom.levi-site.com
   test.EOMUSERNAME=aganguly1
   test.EOMPASSWORD=Test
   test.SFTPLEVICAINBOUNDPATH=/Inbound/SPRINT-001
   test.SFTPLEVICAOUTBOUNDPATH=/Outbound/SPRINT-001 
    
Below is the EOM details that needs to be changed for reg-100 in the testProp.properties files    
   test.EOMURL=https://reg-100-eom.levi-site.com
   test.EOMUSERNAME=9gang34
   test.EOMPASSWORD=Password14
   test.SFTPLEVICAINBOUNDPATH=/Inbound/REG-100
   test.SFTPLEVICAOUTBOUNDPATH=/Outbound/REG-100 

Please refer the Lambda function configurations in the AWS 
https://us-west-2.console.aws.amazon.com/lambda/home?region=us-west-2#/functions/MP-OrderImport-Integrator-sit?tab=graph
https://us-west-2.console.aws.amazon.com/lambda/home?region=us-west-2#/functions/MP-OrderStatusUpdate-Integrator-sit?tab=graph

To run in Eclipse:
1.  Make sure to run the AWS CLI to have the session enabled to access AWS and its valid for 1 hour only.
	Enter the username, password - Then select option 1, the select option 3 for Full access.
	
2.  MP-Shared:
	mvn clean install
   
3. In Eclipse please add the run configurations as below when you use REG-100 for both the projects MP-Order_Import_Integrator,MP-Order_Status_Update
	bucket_name=levi-marketplace-sit 
	CONFIG_FILE_PATH=order-import/order_import_config_sit.json

   In Eclipse please add the run configurations as below when you use REG-100 for both the projects MP-Order_Import_Integrator,MP-Order_Status_Update
	bucket_name=levi-marketplaces 
	CONFIG_FILE_PATH=order-import/order_import_config_sit.json
	
Steps to Run the projects from Command Line:

1.  Make sure to run the AWS CLI to have the session enabled to access AWS.
	Enter the username, password - Then select option 1, the select option 3 for Full access.

2.  MP-Shared:
	mvn clean install

3.  Order Import integrator: 
	mvn clean install -Pacceptance-tests -Dtestdata=testProp -Dbucket_name=levi-marketplace-sit -DCONFIG_FILE_PATH=order-import/order_import_config_sit.json
	

4.  Order Status Update:
	mvn clean install -Pacceptance-tests -Dtestdata=testProp -Dbucket_name=levi-marketplace-sit -DCONFIG_FILE_PATH=order-status-update/order_status_update_config_sit.json

While running the MP-Order_Import_Integrator,MP-Order_Status_Update from command line if you face any issues like not able to get the config from s3 please add the bucket_name and Config_file_path variables to the system Variables of your system.

To run junit test:
mvn clean install





 
 
   
   
   
   