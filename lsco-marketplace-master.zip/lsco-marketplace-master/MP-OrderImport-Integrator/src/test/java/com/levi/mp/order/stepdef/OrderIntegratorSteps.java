package com.levi.mp.order.stepdef;

import io.restassured.response.Response;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.aventstack.extentreports.ExtentTest;
import com.cucumber.listener.Reporter;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.order.model.json.OrderCreationData;
import com.levi.mp.order.model.json.TestorderOut;
import com.levi.mp.order.model.json.UpdateSchemaForOrderCreate;
import com.levi.mp.order.stepmethods.AccessTokenGenerator;
import com.levi.mp.order.stepmethods.OrderIntegratorMethods;
import com.levi.mp.order.stepmethods.PushOrdersInEOM;
import com.levi.mp.order.util.CommonUtilities;
import com.levi.mp.shared.ca.util.S3Adapter;

import java.text.DecimalFormat;
import java.time.Duration;
import java.time.Instant;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class OrderIntegratorSteps {

	public OrderIntegratorMethods orderintegratormethods;
	public AccessTokenGenerator accessTokenGenerator;
	public PushOrdersInEOM pushOrdersInEOM;
	String orderId;
	String orderidres = "";
	String siteOrderId = "";
	String accessToken;
	String fullFilmentID;
	String channel;
	static List<String> doNumberList = new ArrayList<String>();
	static List<String> orderNumberList = new ArrayList<String>();
	List<OrderCreationData> orderUpdateData = new ArrayList<OrderCreationData>();
	List<TestorderOut> testorderOutData ;
	ObjectMapper objectMapper = new ObjectMapper();
	File resourcesDirectory;
	UpdateSchemaForOrderCreate createOrderDefault;
	S3Adapter adapter;
	ExtentTest extentTest;
	String outFilePath;
	static boolean flag = true;
	static boolean flagForWait = false;
	Instant start;
	Instant end;
	static long duration_in_sec;

	public OrderIntegratorSteps() throws IOException, ParseException {
		orderintegratormethods = new OrderIntegratorMethods();
		accessTokenGenerator = new AccessTokenGenerator();
		pushOrdersInEOM = new PushOrdersInEOM();
		adapter = new S3Adapter();
		accessToken = accessTokenGenerator.createNewAccessToken(
				"testprops/testconfig.json", "testprops/RefreshTokenJSON.json");
		resourcesDirectory = new File(
				"src/test/resources/testdata/testorderOut.csv");
		outFilePath = resourcesDirectory.getAbsolutePath();
		testorderOutData = new ArrayList<TestorderOut>();

	}

	public double getRoundedUptoTwo(double x) {
		DecimalFormat format = new DecimalFormat("##.00");
		String temp = format.format(x);
		return Double.parseDouble(temp);

	}

	@When("^Submit the POST request to create \"([^\"]*)\" order and validate$")
	public void submit_the_POST_request_to_create_order_and_validate(
			String option) throws Throwable {
		Response response = null;
		JSONObject jo;

		if (option.trim().equalsIgnoreCase("google"))

		{

			jo = orderintegratormethods
					.getJSONAttributeVal("testdata/order_create_google_multi.json");
			response = orderintegratormethods
					.submit_the_POST_request_to_create_order_from_JSONOBJ(
							"testprops/testconfig.json", accessToken, "", jo,
							"google");

		}

		else {
			if (option.trim().equalsIgnoreCase("facebook"))

			{
				jo = orderintegratormethods
						.getJSONAttributeVal("testdata/order_create_facebook_multi.json");
				response = orderintegratormethods
						.submit_the_POST_request_to_create_order_from_JSONOBJ(
								"testprops/testconfig.json", accessToken, "",
								jo, "facebook");

			}

		}

		orderidres = response.jsonPath().getString("SiteOrderID");
		siteOrderId = response.jsonPath().getString("ID");
		channel = response.jsonPath().getString("SiteName");
	}

	@Then("^Update the shipment details of the orders$")
	public void patch_order_details_JSON_to_update_nodes() throws Throwable {

		try {
			if (!StringUtils.isBlank(siteOrderId)) {
				fullFilmentID = orderintegratormethods.getFulfilmentID(
						"testprops/testconfig.json", siteOrderId, accessToken);

				orderintegratormethods.update_Patch(
						"testprops/testconfig.json", fullFilmentID,
						accessToken, "testdata/fulfilment_patch.json");

				orderintegratormethods.validate_after_Patch(
						"testprops/testconfig.json", siteOrderId, accessToken,
						"testdata/fulfilment_patch.json");

			} else if (!orderUpdateData.isEmpty()) {

				for (int i = 0; i < orderUpdateData.size(); i++) {

					try {
						fullFilmentID = orderintegratormethods.getFulfilmentID(
								"testprops/testconfig.json", orderUpdateData
										.get(i).getOrderNumber(), accessToken);
						if (orderUpdateData.get(i).getSiteOrderID().toString()
								.contains("AUT")) {
							orderintegratormethods.update_Patch(
									"testprops/testconfig.json", fullFilmentID,
									accessToken,
									"testdata/fulfilment_patch.json");

							orderintegratormethods.validate_after_Patch(
									"testprops/testconfig.json",
									orderUpdateData.get(i).getOrderNumber(),
									accessToken,
									"testdata/fulfilment_patch.json");

							Reporter.addStepLog("Shipment details successfully updated for order id "
									+ orderUpdateData.get(i).getSiteOrderID());

						} else {
							orderintegratormethods.update_Patch(
									"testprops/testconfig.json", fullFilmentID,
									accessToken,
									"testdata/fullfillment_patch_fb.json");

							orderintegratormethods.validate_after_Patch(
									"testprops/testconfig.json",
									orderUpdateData.get(i).getOrderNumber(),
									accessToken,
									"testdata/fullfillment_patch_fb.json");
							Reporter.addStepLog("Shipment details successfully updated for order id "
									+ orderUpdateData.get(i).getSiteOrderID());
						}

					}

					catch (Exception e) {
						Reporter.addStepLog("Shipment details update failed for order id  "
								+ orderUpdateData.get(i).getSiteOrderID()
								+ " Reason " + ExceptionUtils.getStackTrace(e));

					}
				}

			} else {

			}

		} catch (Exception e) {

			e.printStackTrace();
		}

		CommonUtilities.writeToCSV(outFilePath, testorderOutData);
	}

	@Then("^I validate order generated$")
	public void i_validate_order_generated() throws Throwable {
		orderintegratormethods.validate_order_generated();
	}

	@Then("^validate the exported status of order$")
	public void validate_order_exported_status() throws Throwable {
		Response res = null;

		if (!orderUpdateData.isEmpty()) {

			for (int i = 0; i < orderUpdateData.size(); i++) {
				boolean flag=false;
				int count=0;

				try {
					pushOrdersInEOM.getExportedOrdersDetails(orderUpdateData
							.get(i).getOrderNumber(), accessToken);
					flag=true;
				} catch (Exception e) {
					
				while (flag==false&&count<3) {
					count++;
					pushOrdersInEOM.getExportedOrdersDetails(orderUpdateData
							.get(i).getOrderNumber(), accessToken);
					flag=true;
					
				}	
					

					e.printStackTrace();
				}

			}
		}
	}

	@Then("^the order details should be successfully validated in OMS$")
	public void validate_the_order_in_EOM() throws Throwable {
		Response res = null;

		System.err.println(">>>>>>>>>>>>>>>>>>>orderUp "+orderUpdateData.size());
		System.err.println(">>>>>>>>>>>>>>>>>>flag is"+flag);
		if (orderidres != "") {
			res = orderintegratormethods.validate_order_status_in_EOM(
					"testprops/testconfig.json", orderidres, channel, "");
			orderNumberList.add(res.jsonPath().getString(
					"customerOrder.orderNumber"));
			doNumberList.add(res.jsonPath().getString(
					"customerOrder.doDetails.doDetail.doNbr"));
		} else if (!orderUpdateData.isEmpty()) {
			for (int i = 0; i < orderUpdateData.size(); i++) {
				flagForWait = false;
				start = Instant.now();

				try {
			
						while (flagForWait == false) {
							end = Instant.now();
							Duration duration = Duration.between(start, end);
							duration_in_sec = (duration.toMillis() / 1000);

							log.info("Time taken: " + duration_in_sec + " secs");

							if (duration_in_sec > 400) {
								break;
							}

							flagForWait = orderintegratormethods
									.orderStatusValidator(
											"testprops/testconfig.json",
											orderUpdateData.get(i)
													.getSiteOrderID());

						}
						res = orderintegratormethods
								.validate_order_status_in_EOM(
										"testprops/testconfig.json",
										orderUpdateData.get(i).getSiteOrderID(),
										orderUpdateData.get(i).getSiteName(),
										"");
						orderNumberList.add(res.jsonPath().getString(
								"customerOrder.orderNumber"));
						doNumberList.add(res.jsonPath().getString(
								"customerOrder.doDetails.doDetail.doNbr"));
						orderUpdateData
								.get(i)
								.setDoNbr(
										res.jsonPath()
												.getString(
														"customerOrder.doDetails.doDetail.doNbr"));
						testorderOutData
								.get(i)
								.setDoNbr(
										res.jsonPath()
												.getString(
														"customerOrder.doDetails.doDetail.doNbr"));
						Reporter.addStepLog("do number "
								+ res.jsonPath()
										.getString(
												"customerOrder.doDetails.doDetail.doNbr")
								+ " generated for the order no "
								+ res.jsonPath().getString(
										"customerOrder.orderNumber"));
					
				} catch (Exception e) {

					Reporter.addStepLog("DONumber creation failed "
							+ "for the order no "
							+ orderUpdateData.get(i).getOrderNumber()
							+ " Reason " + ExceptionUtils.getStackTrace(e));
				}
			}

		}

		CommonUtilities.writeToCSV(outFilePath, testorderOutData);
	}

	@When("^Create new access token$")
	public void create_new_access_token() throws IOException, ParseException {
		accessTokenGenerator.createNewAccessToken("testprops/testconfig.json",
				"testprops/RefreshTokenJSON.json");
	}

	@When("^Read order input data from CSV and place orders and validate$")
	public void read_data_from_CSV() throws Exception {
		resourcesDirectory = new File(
				"src/test/resources/testdata/testorder.csv");
		String filepath = resourcesDirectory.getAbsolutePath();
		orderUpdateData = CommonUtilities.readNodesFromCSV(filepath);

		for (int i = 0; i < orderUpdateData.size(); i++) {
			try {
				if (orderUpdateData.get(i).getSiteName().toLowerCase()
						.contains("google")) {
					placeOrder(i, "google");
				} else if (orderUpdateData.get(i).getSiteName().toLowerCase()
						.contains("facebook")) {
					placeOrder(i, "facebook");

				} else {

				}
				Reporter.addStepLog("Order creation successful "
						+ "CA Order No is "
						+ orderUpdateData.get(i).getOrderNumber()
						+ "and Site order id is "
						+ orderUpdateData.get(i).getSiteOrderID());

			} catch (Exception e) {
testorderOutData.add(i,null);
				Reporter.addStepLog("Order creation Failed "
						+ "check for the input details in tesorder.csv" + " Reason "
						+ ExceptionUtils.getStackTrace(e));
			}

		}

		CommonUtilities.writeToCSV(outFilePath, testorderOutData);
	}

	private void placeOrder(int i, String channel) throws IOException,
			JsonParseException, JsonMappingException, JsonProcessingException,
			ParseException, InterruptedException {
		Response res;
		String orderId;
		String siteOrderID;

		if (Integer.parseInt(orderUpdateData.get(i).getLineItems()) == 1) {

			createOrderDefault = objectMapper.readValue(
					new InputStreamReader(this
							.getClass()
							.getClassLoader()
							.getResourceAsStream(
									"testdata/order_create_" + channel
											+ "_single" + ".json")),
					UpdateSchemaForOrderCreate.class);

			int qty = Integer.parseInt(orderUpdateData.get(i).getQty1());
			Double unitPrice1 = Double.parseDouble(orderUpdateData.get(i)
					.getUnitPrice1());
			Double ShippingPrice1 = Double.parseDouble(orderUpdateData.get(i)
					.getShippingPrice1());
			Double totalShippingPrice = ShippingPrice1;
			createOrderDefault.getItemList().get(0)
					.setSku(orderUpdateData.get(i).getItem1());
			createOrderDefault.getItemList().get(0).setQuantity(qty);
			createOrderDefault.getItemList().get(0).setUnitPrice(unitPrice1);
			createOrderDefault.getItemList().get(0)
					.setShippingPrice(ShippingPrice1);
			createOrderDefault.setTotalShippingPrice(totalShippingPrice);

			Double taxPrice = (qty * unitPrice1) * 0.10;
			Double shippingTaxPrice = (ShippingPrice1) * 0.10;

			createOrderDefault.getItemList().get(0).setTaxPrice(taxPrice);
			createOrderDefault.getItemList().get(0)
					.setShippingTaxPrice(shippingTaxPrice);

			Double totalPrice = (qty * unitPrice1) + taxPrice
					+ shippingTaxPrice + ShippingPrice1;
			Double totalTaxPrice = taxPrice + shippingTaxPrice;

			Double totalShippingTaxPrice = shippingTaxPrice;

			createOrderDefault.setTotalPrice(totalPrice);
			createOrderDefault.setTotalTaxPrice(totalTaxPrice);
			createOrderDefault.setTotalShippingPrice(totalShippingPrice);
			createOrderDefault.setTotalShippingTaxPrice(totalShippingTaxPrice);

		} else

		if (Integer.parseInt(orderUpdateData.get(i).getLineItems()) > 1) {

			try {

				createOrderDefault = objectMapper.readValue(
						new InputStreamReader(this
								.getClass()
								.getClassLoader()
								.getResourceAsStream(
										"testdata/order_create_" + channel
												+ "_multi" + ".json")),
						UpdateSchemaForOrderCreate.class);

				int qty1 = Integer.parseInt(orderUpdateData.get(i).getQty1());
				int qty2 = Integer.parseInt(orderUpdateData.get(i).getQty2());
				Double unitPrice1 = Double.parseDouble(orderUpdateData.get(i)
						.getUnitPrice1());
				Double unitPrice2 = Double.parseDouble(orderUpdateData.get(i)
						.getUnitPrice2());
				Double ShippingPrice1 = Double.parseDouble(orderUpdateData.get(
						i).getShippingPrice1());
				Double ShippingPrice2 = Double.parseDouble(orderUpdateData.get(
						i).getShippingPrice2());
				Double totalShippingPrice1 = ShippingPrice1;
				Double totalShippingPrice2 = ShippingPrice2;
				createOrderDefault.getItemList().get(0)
						.setSku(orderUpdateData.get(i).getItem1());
				createOrderDefault.getItemList().get(0).setQuantity(qty1);
				createOrderDefault.getItemList().get(0)
						.setUnitPrice(unitPrice1);
				createOrderDefault.getItemList().get(0)
						.setShippingPrice(ShippingPrice1);

				createOrderDefault.getItemList().get(1)
						.setSku(orderUpdateData.get(i).getItem2());
				createOrderDefault.getItemList().get(1).setQuantity(qty2);
				createOrderDefault.getItemList().get(1)
						.setUnitPrice(unitPrice2);
				createOrderDefault.getItemList().get(1)
						.setShippingPrice(ShippingPrice2);

				createOrderDefault.setTotalShippingPrice(totalShippingPrice1
						+ totalShippingPrice2);

				Double taxPrice1 = (qty1 * unitPrice1) * 0.10;
				Double taxPrice2 = (qty2 * unitPrice2) * 0.10;
				Double shippingTaxPrice1 = (ShippingPrice1) * 0.10;
				Double shippingTaxPrice2 = (ShippingPrice2) * 0.10;

				createOrderDefault.getItemList().get(0).setTaxPrice(taxPrice1);
				createOrderDefault.getItemList().get(1).setTaxPrice(taxPrice2);
				createOrderDefault.getItemList().get(0)
						.setShippingTaxPrice(shippingTaxPrice1);
				createOrderDefault.getItemList().get(1)
						.setShippingTaxPrice(shippingTaxPrice2);

				Double totalPrice1 = (qty1 * unitPrice1) + taxPrice1
						+ shippingTaxPrice1 + ShippingPrice1;
				Double totalPrice2 = (qty2 * unitPrice2) + taxPrice2
						+ shippingTaxPrice2 + ShippingPrice2;
				Double totalTaxPrice1 = taxPrice1 + shippingTaxPrice1;
				Double totalTaxPrice2 = taxPrice2 + shippingTaxPrice2;

				Double totalShippingTaxPrice = shippingTaxPrice1
						+ shippingTaxPrice2;

				createOrderDefault.setTotalPrice(totalPrice1 + totalPrice2);
				createOrderDefault.setTotalTaxPrice(totalTaxPrice1
						+ totalTaxPrice2);
				createOrderDefault.setTotalShippingPrice(totalShippingPrice1
						+ totalShippingPrice2);
				createOrderDefault
						.setTotalShippingTaxPrice(totalShippingTaxPrice);
			} catch (Exception e) {
				e.printStackTrace();

			}

		}
		createOrderDefault.setShippingAddressLine1(orderUpdateData.get(i)
				.getShippingAddress().toString().replaceAll(",", ""));
		createOrderDefault
				.getItemList()
				.get(0)
				.setSku(orderUpdateData.get(i).getItem1().toString()
						.replaceAll(",", ""));

		String jsonData = objectMapper.writeValueAsString(createOrderDefault);

		Object configobj = new JSONParser().parse(jsonData);
		JSONObject jconfigobj = (JSONObject) configobj;

		res = orderintegratormethods
				.submit_the_POST_request_to_create_order_from_JSONOBJ(
						"testprops/testconfig.json", accessToken, "",
						jconfigobj, channel);
		orderId = res.jsonPath().getString("ID");
		siteOrderID = res.jsonPath().getString("SiteOrderID");
		orderUpdateData.get(i).setOrderNumber(orderId);
		orderUpdateData.get(i).setSiteOrderID(siteOrderID);
		TestorderOut out = new TestorderOut();
		out.setSiteName(orderUpdateData.get(i).getSiteName());
		out.setItem1((orderUpdateData.get(i).getItem1()));
		out.setQty1((orderUpdateData.get(i).getQty1()));
		out.setItem2((orderUpdateData.get(i).getItem2()));
		out.setQty2((orderUpdateData.get(i).getQty2()));
		out.setSiteOrderID(orderUpdateData.get(i).getSiteOrderID());
		out.setOrderNumber(orderUpdateData.get(i).getOrderNumber());
		out.setDoNbr(orderUpdateData.get(i).getDoNbr());
		out.setShipment_type(orderUpdateData.get(i).getShipment_type());
		testorderOutData.add(i, out);
	}

	@Then("^trigger lambda function to push orders to EOM$")
	public void push_auto_generated_orders_to_EOM_triggiring_lambdaDevCode()
			throws Exception {

		if (!StringUtils.isBlank(siteOrderId)) {
			pushOrdersInEOM.processNewAutomatedOrders(siteOrderId, accessToken);
		} else if (!orderUpdateData.isEmpty()) {
			for (int i = 0; i < orderUpdateData.size(); i++) {
				try {
					pushOrdersInEOM.processNewAutomatedOrders(orderUpdateData
							.get(i).getOrderNumber(), accessToken);
					Reporter.addStepLog("successfully pushed the orders to EOM for the order id "
							+ orderUpdateData.get(i).getOrderNumber());

				}

				catch (Exception e) {
				
					Reporter.addStepLog("Lambda failed to push the orders to EOM "
							+ orderUpdateData.get(i).getOrderNumber()
							+ " Reason " + ExceptionUtils.getStackTrace(e));

				}

			}
		}
		CommonUtilities.writeToCSV(outFilePath, testorderOutData);
	}

	@Then("^upload output csv files to S3$")
	public void upload_files_to_S3() throws IOException, ParseException {

		String fileName = outFilePath;
		adapter.uploadFile("levi-marketplaces",
				"qadatafactory/testorderOut.csv", new File(fileName));
	}

}
