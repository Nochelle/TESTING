package com.levi.mp.order.service;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.levi.mp.OrderImportSharedTestConfig;
import com.levi.mp.config.OrderImportLoadConfiguration;
import com.levi.mp.order.model.json.ChannelAdvisorOrder;
import com.levi.mp.order.model.json.Orders;
import com.levi.mp.order.model.xml.TXML;
import com.levi.mp.order.rest.client.OrderRestClientAdapter;
import com.levi.mp.order.util.IConstants;
import com.levi.mp.order.util.MQMsgSender;
import com.levi.mp.order.util.OrderImportUtil;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;
import com.levi.mp.shared.ca.util.MPSharedUtil;

/**
 * @author Prabir Nandi
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = OrderImportSharedTestConfig.class)
public class OrderImportServiceTest {

	@Autowired
	OrderImportService orderImportService;

	@MockBean
	ChannelAdvisorTokenService advisorTokenService;

	@MockBean
	MPSharedUtil mpSharedUtil;

	@MockBean
	OrderImportUtil orderImportUtil;

	@MockBean
	OrderRestClientAdapter restClientAdaptor;

	@MockBean
	MQMsgSender mqMsgSender;

	@MockBean
	OrderImportLoadConfiguration orderImportLoadConfig;

	@Mock
	private Orders orders;

	@Mock
	private TXML txml;

	private Map<String, String> resultMap;

	@Test
	public void processNewOrdersTest_HappyPath() {

		try {
			// String caAccessToken = "D_CAAccessToken";

			// when(advisorTokenService.getOAuth2Token()).thenReturn(caAccessToken);

			when(restClientAdaptor.getUnexportedOrders()).thenReturn(orders);

			when(orderImportUtil.convertJsonToXMLObject(ArgumentMatchers.<ChannelAdvisorOrder>any()))
					.thenReturn(txml);

			when(mqMsgSender.sendMsg(ArgumentMatchers.<Map<String,String>>any())).thenReturn(
					resultMap);

			when(
					restClientAdaptor.updateOrderSatusFlag(ArgumentMatchers
							.anyString(), ArgumentMatchers.anyString())).thenReturn(Boolean.TRUE);

			orderImportService.processNewOrders(); // call orderservice

			when(restClientAdaptor.getUnexportedOrders()).thenReturn(null);

			orderImportService.processNewOrders(); // test with null orders
													// object

			when(restClientAdaptor.getUnexportedOrders()).thenReturn(
					new Orders());

			orderImportService.processNewOrders(); // test with no orders object

		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}

	@Test
	public void processNewOrdersTest_Error() {

		try {
			// String caAccessToken = "D_CAAccessToken";

			// when(advisorTokenService.getOAuth2Token()).thenReturn(caAccessToken);

			when(restClientAdaptor.getUnexportedOrders()).thenReturn(orders);

			when(orderImportUtil.convertJsonToXMLObject(ArgumentMatchers.<ChannelAdvisorOrder>any()))
					.thenReturn(txml);

			when(mqMsgSender.sendMsg(ArgumentMatchers.<Map<String, String>>any())).thenReturn(
					resultMap);

			when(
					restClientAdaptor.updateOrderSatusFlag(ArgumentMatchers
							.anyString(), ArgumentMatchers.anyString())).thenThrow(new RuntimeException());

			orderImportService.processNewOrders(); // call orderservice
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}

	}

	@Before
	public void setUp() {
		final String CHECKOUT_STATUS_COMPLETED = "Completed";
		final String PAYMENT_STATUS_CLEARED = "Cleared";
		final String SHIPMENT_STATUS_UNSHIPPED = "Unshipped";

		orders = new Orders();
		List<ChannelAdvisorOrder> caOrders = new ArrayList<>();
		ChannelAdvisorOrder channelAdvisorOrder = new ChannelAdvisorOrder();
		channelAdvisorOrder.setID(12345);
		channelAdvisorOrder.setSiteOrderID("SITE-12345");
		channelAdvisorOrder.setCheckoutStatus(CHECKOUT_STATUS_COMPLETED);
		channelAdvisorOrder.setPaymentStatus(PAYMENT_STATUS_CLEARED);
		channelAdvisorOrder.setShippingStatus(SHIPMENT_STATUS_UNSHIPPED);
		caOrders.add(channelAdvisorOrder);

		channelAdvisorOrder = new ChannelAdvisorOrder();
		channelAdvisorOrder.setID(67890);
		channelAdvisorOrder.setSiteOrderID("SITE-67890");
		channelAdvisorOrder.setCheckoutStatus(CHECKOUT_STATUS_COMPLETED);
		channelAdvisorOrder.setPaymentStatus("Posted");
		channelAdvisorOrder.setShippingStatus(SHIPMENT_STATUS_UNSHIPPED);
		caOrders.add(channelAdvisorOrder);

		orders.setCaOrders(caOrders);

		txml = new TXML();

		resultMap = new HashMap<>();
		resultMap.put("12345", IConstants.STATUS_SUCCESS);
	}

}
