package com.levi.mp.order.stepmethods;

import static org.junit.Assert.assertTrue;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import com.cucumber.listener.Reporter;

import java.io.IOException;

import lombok.extern.log4j.Log4j2;

import org.json.simple.parser.ParseException;

import com.levi.mp.order.util.CommonUtilities;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.order.function.OrderImportAutomationHandler;
import com.levi.mp.order.model.json.ChannelAdvisorOrder;
import com.levi.mp.order.model.json.Orders;
import com.levi.mp.order.util.IConstants;

@Log4j2
public class PushOrdersInEOM {
	ObjectMapper objectMapper = new ObjectMapper();
	Orders orders = null;

	public void processNewAutomatedOrders(String CAID, String AccessToken)
			throws IOException, ParseException {

		orders = getOrdersDetails(CAID, AccessToken);
		log.info("Orders>>>>>>>>>" + orders);
		OrderImportAutomationHandler orderImportAutomationHandler = new OrderImportAutomationHandler();

		orderImportAutomationHandler.handleAutomationRequest(orders);
	}

	public Orders getOrdersDetails(String CAID, String accessToken) {

		String URL = "https://api.channeladvisor.com/v1/Orders?access_token="
				+ accessToken
				+ "&exported=false&$expand=Items($expand=Promotions),Fulfillments&$filter=CheckoutStatus eq 'Completed' and PaymentStatus eq 'Cleared' and ShippingStatus eq 'Unshipped'and ID eq "
				+ Integer.parseInt(CAID);

		Response response;
		RequestSpecification request;
		request = RestAssured.given();

		response = request
				.headers("Content-Type", ContentType.JSON, "Accept",
						ContentType.JSON).when().get(URL).then()
				.contentType(ContentType.JSON).extract().response();

		assertTrue(response != null);
		assertTrue(response.statusCode() == 200);
		try {
			orders = objectMapper.readValue(response.getBody().asString(),
					Orders.class);
			for (ChannelAdvisorOrder order : orders.getCaOrders()) {
				System.out.println(order.getSiteOrderID());
				if (order.getSiteName().contains("Google Express")
						&& order.getSiteID() == 587) {
					order.setSiteID(IConstants.GOOGLE_SITE_ID);

				} else if (order.getSiteName().contains("Facebook")
						&& order.getSiteID() == 587) {
					order.setSiteID(IConstants.FACEBOOK_SITE_ID);
				}
				System.out.println(order.getSiteID());
			}

			return orders;
		} catch (Exception e) {
			throw new RuntimeException(
					"Could not map Channel Advisor orders to Orders class", e);
		}
	}
	
public void getExportedOrdersDetails(String CAID, String accessToken) throws InterruptedException {
		
		
		String URL = "https://api.channeladvisor.com/v1/Orders?access_token="
				+ accessToken
				+ "&exported=true&$expand=Items($expand=Promotions),Fulfillments&$filter=CheckoutStatus eq 'Completed' and PaymentStatus eq 'Cleared' and ShippingStatus eq 'Unshipped'and ID eq "
				+ (CAID);

		Response response;
		RequestSpecification request;
		request = RestAssured.given();

		response = request
				.headers("Content-Type", ContentType.JSON, "Accept",
						ContentType.JSON).when().get(URL).then()
				.contentType(ContentType.JSON).extract().response();

		Thread.sleep(2000);
		try {
			assertTrue(response != null);
			assertTrue(response.statusCode() == 200);
			orders = objectMapper.readValue(response.getBody().asString(),
					Orders.class);
			for (ChannelAdvisorOrder order : orders.getCaOrders()) {
				
				assertTrue(Long.toString(order.getID()).contains(CAID));
				
				Reporter.addStepLog("The Exported status validated successfully for the CA Order "+ CAID);
				
			}

			
		} catch (AssertionError  | Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.addStepLog(ExceptionUtils.getStackTrace(e));
			
		}
	}

}
