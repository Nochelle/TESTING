package com.levi.mp.order.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyLoader {

	Properties property = new Properties();
	InputStream inputStream  = null;
	String path="testprops/";
	String filename;
	
	public Properties getProperty(String fileName){		
		try {
			inputStream = getClass().getClassLoader().getResourceAsStream(fileName);
			property.load(inputStream);
		} catch (IOException e) {
			System.err.println("Inside: propertyLoader: FileName: "+fileName+" "+e.getMessage());
			e.printStackTrace();
		}
		return property;		
	}
			
	public Properties getProperty(){		
		try {
			String testdata = System.getProperty("testdata");
			filename = "testprops/"+testdata+".properties";
			inputStream = getClass().getClassLoader().getResourceAsStream(filename);
			property.load(inputStream);
		} catch (Exception e) {
			System.err.println("Inside: propertyLoader: FileName: "+ filename +" "+e.getMessage());
			e.printStackTrace();
		}
		return property;		
	}
	
}
