package com.levi.mp.order.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import javax.jms.QueueConnection;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;

import lombok.extern.log4j.Log4j2;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.ibm.mq.jms.MQQueue;
import com.levi.mp.OrderImportSharedTestConfig;
import com.levi.mp.config.MQBeanHelper;
import com.levi.mp.config.OrderImportLoadConfiguration;
import com.levi.mp.order.model.json.MQConfig;
import com.levi.mp.order.model.json.OrderImportConfig;
import com.levi.mp.order.model.xml.ObjectFactory;
import com.levi.mp.order.model.xml.TXML;
import com.levi.mp.order.model.xml.TXML.Header;
import com.levi.mp.order.model.xml.TXML.Message;
import com.levi.mp.order.model.xml.TXML.Message.Order;
import com.levi.mp.order.model.xml.TXML.Message.Order.CustomerInfo;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine;
import com.levi.mp.order.model.xml.TXML.Message.Order.PaymentDetails;
import com.levi.mp.order.model.xml.TXML.Message.Order.PaymentDetails.PaymentDetail;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;
import com.levi.mp.shared.sns.SNSService;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = OrderImportSharedTestConfig.class)
@Log4j2
public class MQMsgSenderTest {
	
	@MockBean
	ChannelAdvisorTokenService advisorTokenService;
	
	@MockBean
	MQBeanHelper beanHelper;
	
	@MockBean
	OrderImportLoadConfiguration orderImportIntegratorConfiguration;
	
	@MockBean
	TXML txml;
	
	@Autowired
	MQMsgSender mqMsgSender;
	
	@MockBean
	MQMsgBuilder mqMsgBuilder;
	
	@Mock
	QueueConnection queueConnection;
	
	@Mock
	QueueSession queueSession;
	
	@Mock
	QueueSender queueSender ;
	
	@Mock
	MQQueue mqQueue;
	
	@Mock
	TextMessage textMessage;
	
	@MockBean
	SNSService snsService;
	
	private OrderImportConfig orderImportConfig = new OrderImportConfig();
	
	@Before
    public void setUp() {
		MQConfig mqConfig= new MQConfig();
		mqConfig.setMQHOST("D_HOST");
		mqConfig.setMQPORT(1500);
		mqConfig.setMQCHANNEL("D_Channel");
		mqConfig.setMQQMGR("D_QMGR");
		mqConfig.setMQSENDQNAME("D_QUEUE");
		
		orderImportConfig.setMqConfig(mqConfig);
    }
	
	@Test
	public void sendMsgTest_HappyPath() {
		try {
			
			String xmlMsg = mqMsgBuilder.buildSendMsg(txml);
			if(xmlMsg==null)
				xmlMsg=""; //Dummy not null messsage
			Map<String, String> msgMap = new HashMap<String, String>();
			msgMap.put("test_1234556789", xmlMsg);
			
			Map<String, String> resMap = new HashMap<>();
			//TODO: Mock the below line?
			
			when(beanHelper.getConfig()).thenReturn(orderImportIntegratorConfiguration);
			
			when(beanHelper.getConfig().getOrderImportConfig()).thenReturn(orderImportConfig);
			
			
			when(beanHelper.getQueueConnection()).thenReturn(queueConnection);
			
			Mockito.doNothing().when(queueConnection).start();
			
			when(queueConnection.createQueueSession(ArgumentMatchers.anyBoolean(), ArgumentMatchers.anyInt()))
			.thenReturn(queueSession);
			
			when(queueSession.createSender(mqQueue)).thenReturn(queueSender);
			
			when(beanHelper.getMQQueue()).thenReturn(mqQueue);
			
			when(queueSession.createTextMessage(ArgumentMatchers.anyString())).
			thenReturn(textMessage);
			
			Mockito.doNothing().when(queueSender).send(ArgumentMatchers.any());
			
			resMap = mqMsgSender.sendMsg(msgMap);
			log.debug("resMap>>>" + resMap);
			assertNotNull("Map is null", resMap);
			assertEquals("Map has success status", IConstants.STATUS_SUCCESS, resMap.get("test_1234556789"));
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}
	
	@Test
	public void sendMsgTest_Error() {
		try {
			
			String xmlMsg = mqMsgBuilder.buildSendMsg(txml);
			
			Map<String, String> msgMap = new HashMap<String, String>();
			msgMap.put("test_1234556789", xmlMsg);
			
			Map<String, String> resMap = new HashMap<>();
			//TODO: Mock the below line?
			
			when(beanHelper.getConfig()).thenReturn(orderImportIntegratorConfiguration);
			orderImportConfig.getMqConfig().setMQHOST("");
			when(beanHelper.getConfig().getOrderImportConfig()).thenReturn(orderImportConfig);
			
			when(beanHelper.getQueueConnection()).thenReturn(queueConnection);
			
			Mockito.doNothing().when(queueConnection).start();
			
			when(queueConnection.createQueueSession(ArgumentMatchers.anyBoolean(), ArgumentMatchers.anyInt()))
			.thenReturn(queueSession);
			
			when(queueSession.createSender(mqQueue)).thenReturn(queueSender);
			
			when(beanHelper.getMQQueue()).thenReturn(mqQueue);
			
			when(queueSession.createTextMessage(ArgumentMatchers.anyString())).
			thenReturn(null); // setting message null to fail MQ send
			
			Mockito.doNothing().when(queueSender).send(ArgumentMatchers.any());
			
			resMap = mqMsgSender.sendMsg(msgMap);
			log.debug("resMap>>>" + resMap);
			assertNotNull("Map is null", resMap);
			assertEquals("Map has error status", IConstants.STATUS_ERROR, resMap.get("test_1234556789"));
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}

	//@Test
	public void sendMsgTest() {
		try {
			ObjectFactory factory = new ObjectFactory();
			// build a TXML object
			TXML txml = factory.createTXML();

			Header header = factory.createTXMLHeader();
			header.setSource("Google");
			header.setActionType("Update");
			header.setMessageType("Customer_Order_Import");
			header.setReferenceID(factory.createTXMLHeaderReferenceID("test_1234556789_4"));

			Message message = factory.createTXMLMessage();
			Order order = factory.createTXMLMessageOrder();
			order.setOrderNumber(factory.createTXMLMessageOrderOrderNumber("test_1234556789_4"));
			order.setOrderType(factory.createTXMLMessageOrderOrderType("OT_GOOGLE"));
			order.setOrderTotal(factory.createTXMLMessageOrderOrderTotal("82.45"));
			order.setPaymentStatus(factory.createTXMLMessageOrderPaymentStatus("AUTHORIZED"));

			CustomerInfo customerInfo = factory.createTXMLMessageOrderCustomerInfo();
			customerInfo.setCustomerEmail(factory.createTXMLMessageOrderCustomerInfoCustomerEmail("a.b@gmail.com"));
			order.setCustomerInfo(customerInfo);
			message.setOrder(order);

			PaymentDetails paymentDetails = factory.createTXMLMessageOrderPaymentDetails();

			PaymentDetail paymentDetail = factory.createTXMLMessageOrderPaymentDetailsPaymentDetail();
			paymentDetail.setPaymentMethod("Credit Card");
			paymentDetail.setNameAsOnCard(
					factory.createTXMLMessageOrderPaymentDetailsPaymentDetailNameAsOnCard("Prabir Nandi"));
			paymentDetails.getPaymentDetail().add(paymentDetail);

			paymentDetail = factory.createTXMLMessageOrderPaymentDetailsPaymentDetail();
			paymentDetail.setPaymentMethod("Gift Card");
			paymentDetail.setAccountNumber(
					factory.createTXMLMessageOrderPaymentDetailsPaymentDetailAccountNumber("7899874698747385"));

			paymentDetails.getPaymentDetail().add(paymentDetail);
			order.setPaymentDetails(paymentDetails);

			OrderLines orderLines = factory.createTXMLMessageOrderOrderLines();

			OrderLine orderLine = factory.createTXMLMessageOrderOrderLinesOrderLine();
			orderLine.setLineNumber("1");
			orderLine.setItemID("4568928308289");
			orderLine.setIsGift(factory.createTXMLMessageOrderOrderLinesOrderLineIsGift("true"));
			orderLine.setIsReturnable(factory.createTXMLMessageOrderOrderLinesOrderLineIsReturnable("true"));
			orderLines.getOrderLine().add(orderLine);

			orderLine = factory.createTXMLMessageOrderOrderLinesOrderLine();
			orderLine.setLineNumber("2");
			orderLine.setItemID("5633443034402");
			orderLine.setIsReturnable(factory.createTXMLMessageOrderOrderLinesOrderLineIsReturnable("false"));
			orderLines.getOrderLine().add(orderLine);
			order.setOrderLines(orderLines);

			txml.setHeader(header);
			txml.setMessage(message);

			String xmlMsg = mqMsgBuilder.buildSendMsg(txml);

			Map<String, String> msgMap = new HashMap<String, String>();

			
			msgMap.put("test_1234556789", xmlMsg);
			
			Map<String, String> resMap = new HashMap<>();
			
			
			log.debug("resMap>>>" + resMap);
			assertNotNull("Map is null", resMap);
		
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}

}
