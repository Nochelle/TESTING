package com.levi.mp.order.util;

import java.util.Properties;

public class TestDataProvider {
	public static Properties property = new PropertyLoader().getProperty();

	public enum TestData {

		EOMURL("test.EOMURL"), EOMUSERNAME("test.EOMUSERNAME"), EOMPASSWORD(
				"test.EOMPASSWORD"), EOMORDERNUMBER("test.EOMORDERNUMBER"), EOMDONUMBER(
						"test.EOMDONUMBER"), SFTPCASERVER("test.SFTPCASERVER"), SFTPLEVICAUSER(
								"test.SFTPLEVICAUSER"), SFTPLEVICAPASSWORD(
										"test.SFTPLEVICAPASSWORD"), SFTPLEVICAINBOUNDPATH(
												"test.SFTPLEVICAINBOUNDPATH"), SFTPLEVICAOUTBOUNDPATH(
														"test.SFTPLEVICAOUTBOUNDPATH");

		private String value;

		TestData(String value) {
			this.value = value;
		}

		public String val() {
			try {
				return property.getProperty(value).toString();
			} catch (Exception e) {
				return null;
			}
		}
	}
}
