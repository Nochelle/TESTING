package com.levi.mp.order.stepmethods;

import static org.junit.Assert.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

import lombok.extern.log4j.Log4j2;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.aventstack.extentreports.ExtentTest;
import com.cucumber.listener.Reporter;
import com.levi.mp.order.util.CommonUtilities;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.assertj.core.api.SoftAssertions;

@Log4j2
public class OrderIntegratorMethods {

	Response response;
	RequestSpecification request;
	ExtentTest extlogger;
	private SoftAssertions softAssertions = new SoftAssertions();

	public Response submit_the_POST_request_to_create_order_from_JSONOBJ(
			String CONFIG_FILE, String ACCESS_TOKEN, String CONTENT_TYPE,
			JSONObject JO, String CHANNEL) throws IOException, ParseException, InterruptedException {

		String SERVICE_ENDPOINT = getBaseURL(CONFIG_FILE).concat("/v1/Orders?")
				.concat("access_token=" + ACCESS_TOKEN);

		request = RestAssured.given();

		String orderid_in = "";
		if (CHANNEL.contains("google")) {
			orderid_in = "G-AUT-9876-55-" + CommonUtilities.generateRandomNum();
		} else if (CHANNEL.contains("facebook")) {
			orderid_in = "1771809936" + CommonUtilities.generateRandomNum();
		}
		JO.put("SiteOrderID", orderid_in);

		request = request.body(JO);
		log.info(JO.toString());
		
		response = request
				.headers("Content-Type", ContentType.JSON, "Accept",
						ContentType.JSON).when().post(SERVICE_ENDPOINT).then()
				.contentType(ContentType.JSON).extract().response();
		
		log.info("RESPONSE>>>>>>>>>>>>>>>>RESPONSE"+response.body().asString());
				
		String responseData1=response.body().asString();
				
		if (responseData1.contains("SiteID and SiteOrderID already exists"))
		{
		submit_the_POST_request_to_create_order_from_JSONOBJ(CONFIG_FILE, ACCESS_TOKEN, CONTENT_TYPE, JO, CHANNEL);
		
		}
		List<String> nodenames = Arrays.asList("SiteOrderID", "ProfileID",
				"SiteName", "TotalPrice", "TotalTaxPrice", "CheckoutStatus",
				"PaymentStatus", "ShippingStatus", "BuyerEmailAddress",
				"BuyerUserId", "PaymentMethod", "PaymentCreditCardLast4",
				"PaymentMerchantReferenceNumber", "ShippingTitle",
				"ShippingLastName", "ShippingAddressLine1", "ShippingCity",
				"ShippingStateOrProvince", "ShippingPostalCode",
				"ShippingCountry", "BillingFirstName", "BillingLastName",
				"BillingAddressLine1", "BillingCity", "BillingStateOrProvince",
				"BillingPostalCode", "BillingCountry");
		Thread.sleep(2000);
		try {
//			CommonUtilities.assertJsonRes_byNodeNames(response, JO, nodenames);
		} catch (AssertionError |Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String CAId = response.jsonPath().getString("ID");
		
		return response;
	}

	public String getFulfilmentID(String CONFIG_FILE, String CAID,
			String ACCESS_TOKEN) throws IOException, ParseException {
		String SERVICE_ENDPOINT = getBaseURL(CONFIG_FILE)
				.concat("/v1/Orders(" + CAID + ")?")
				.concat("access_token=" + ACCESS_TOKEN)
				.concat("&$expand=Fulfillments");

		request = RestAssured.given();
		log.info(request.toString());
		response = request
				.headers("Content-Type", ContentType.JSON, "Accept",
						ContentType.JSON).when().get(SERVICE_ENDPOINT).then()
				.contentType(ContentType.JSON).extract().response();

		log.info(response.body().asString());
		return response.jsonPath().getString("Fulfillments.ID");
	}

	public void update_Patch(String CONFIG_FILE, String FUFULMENTID,
			String ACCESS_TOKEN, String ORDER_PATCH_FILE) throws IOException,
			ParseException {
		String SERVICE_ENDPOINT = getBaseURL(CONFIG_FILE).concat(
				"/v1/Fulfillments("
						+ FUFULMENTID.replace("[", "").replace("]", "") + ")?")
				.concat("access_token=" + ACCESS_TOKEN);
		request = RestAssured.given();

		JSONObject jo = getJSONAttributeVal(ORDER_PATCH_FILE);

		request = request.body(jo);
		log.info(request.toString());
		response = request.headers("Content-Type", "application/json").when()
				.patch(SERVICE_ENDPOINT);
		log.info(response.body().asString());

	}

	public void validate_after_Patch(String CONFIG_FILE, String CAID,
			String ACCESS_TOKEN, String ORDER_PATCH_FILE) throws IOException,
			ParseException {
		try {
			String SERVICE_ENDPOINT = getBaseURL(CONFIG_FILE)
					.concat("/v1/Orders(" + CAID + ")?")
					.concat("access_token=" + ACCESS_TOKEN)
					.concat("&$expand=Fulfillments");
			JSONObject jo = getJSONAttributeVal(ORDER_PATCH_FILE);

			request = RestAssured.given();
			log.info(request.toString());
			response = request
					.headers("Content-Type", ContentType.JSON, "Accept",
							ContentType.JSON).when().get(SERVICE_ENDPOINT)
					.then().contentType(ContentType.JSON).extract().response();

			List<String> in_nodenames = Arrays.asList("ShippingCarrier",
					"ShippingClass");
			List<String> out_nodenames = Arrays.asList(
					"Fulfillments.ShippingCarrier",
					"Fulfillments.ShippingClass");
			CommonUtilities.assertJsonRes_byNodeNames(response, jo,
					in_nodenames, out_nodenames);
			log.info(response.body().asString());

			try {
				assertTrue(response.jsonPath()
						.getString("Fulfillments.ShippingCarrier")
						.contains("Google")
						|| response.jsonPath()
								.getString("Fulfillments.ShippingCarrier")
								.contains("Facebook"));
				assertTrue(response.jsonPath()
						.getString("Fulfillments.ShippingClass")
						.contains("EEST"));

			} catch (AssertionError | Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				Reporter.addStepLog(ExceptionUtils.getStackTrace(e));

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void validate_order_generated() {
		int statusCode = response.getStatusCode();
		String body = response.body().asString();
		assertTrue(statusCode == 200);
	}

	public boolean orderStatusValidator(String CONFIG_FILE,
			String ORDERNUM)
			throws IOException, ParseException {
		Object configobj = new JSONParser().parse(new InputStreamReader(this
				.getClass().getClassLoader().getResourceAsStream(CONFIG_FILE)));
		boolean resposeFlag=false;
		JSONObject jconfigobj = (JSONObject) configobj;
		String EOMURL = (String) jconfigobj.get("EOMURL");
		String EOMUSER = (String) jconfigobj.get("EOMUSER");
		String EOMPWD = (String) jconfigobj.get("EOMPWD");
		String ENDPOINTURL = EOMURL
						.concat("/services/olm/customerorder/customerOrderDetails?responseType=FullCustomerOrder&customerOrderNumber=")
				.concat(ORDERNUM);
		request = RestAssured.given();
		request = request.auth().preemptive().basic(EOMUSER, EOMPWD);
		response = request.when().get(ENDPOINTURL).then()
				.contentType(ContentType.JSON).extract().response();

		String orderNum = response.jsonPath().getString(
				"customerOrder.orderNumber");
		try {
			if (orderNum.contains(ORDERNUM)) {
				resposeFlag = true;

			} else {
				resposeFlag = false;
			}

		} catch (Exception e) {

		}

		return resposeFlag;

	}

	public Response validate_order_status_in_EOM(String CONFIG_FILE,
			String ORDERNUM, String CHENNEL, String ORDERSTATUS)
			throws IOException, ParseException {
		Object configobj = new JSONParser().parse(new InputStreamReader(this
				.getClass().getClassLoader().getResourceAsStream(CONFIG_FILE)));
		JSONObject jconfigobj = (JSONObject) configobj;
		String EOMURL = (String) jconfigobj.get("EOMURL");
		String EOMUSER = (String) jconfigobj.get("EOMUSER");
		String EOMPWD = (String) jconfigobj.get("EOMPWD");
		String ENDPOINTURL = EOMURL
				.concat("/services/olm/customerorder/customerOrderDetails?responseType=FullCustomerOrder&customerOrderNumber=")
				.concat(ORDERNUM);

		request = RestAssured.given();
		request = request.auth().preemptive().basic(EOMUSER, EOMPWD);
		response = request.when().get(ENDPOINTURL).then()
				.contentType(ContentType.JSON).extract().response();
		try {
			assertTrue(response.statusCode() == 200);
			log.info(response.asString());
			assertTrue(response.jsonPath()
					.getString("customerOrder.orderStatus")
					.contains("Released"));
			Reporter.addStepLog("Current status of the order is "
					+ response.jsonPath()
							.getString("customerOrder.orderStatus"));
			assertTrue(response.jsonPath()
					.getString("customerOrder.orderNumber").contains(ORDERNUM));

			Reporter.addStepLog("The order Number is "
					+ response.jsonPath()
							.getString("customerOrder.orderNumber"));

			assertTrue(response.jsonPath().getString("customerOrder.enteredBy")
					.contains("Channel Advisor"));

			Reporter.addStepLog("The Automation order Number is created in "
					+ response.jsonPath().getString("customerOrder.enteredBy"));

			assertTrue(response
					.jsonPath()
					.getString(
							"customerOrder.orderLines.orderLine.shippingInfo.shipVia")
					.contains("EE2D")
					|| response
							.jsonPath()
							.getString(
									"customerOrder.orderLines.orderLine.shippingInfo.shipVia")
							.contains("EEND")
					|| response
							.jsonPath()
							.getString(
									"customerOrder.orderLines.orderLine.shippingInfo.shipVia")
							.contains("EEST"));
			Reporter.addStepLog("The Ship Via for the order is "
					+ response
							.jsonPath()
							.getString(
									"customerOrder.orderLines.orderLine.shippingInfo.shipVia"));
		} catch (AssertionError | Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.addStepLog(ExceptionUtils.getStackTrace(e));

		}
		try {
			if (CHENNEL.contains("google")) {
				assertTrue(response
						.jsonPath()
						.getString(
								"customerOrder.paymentDetails.paymentDetail.cardType")
						.contains("Google"));
				Reporter.addStepLog("The payment card type is "
						+ response
								.jsonPath()
								.getString(
										"customerOrder.paymentDetails.paymentDetail.cardType"));

				assertTrue(response
						.jsonPath()
						.getString("customerOrder.doDetails.doDetail.orderType")
						.contains("OT_Google"));

				Reporter.addStepLog("The DO Order type is "
						+ response.jsonPath().getString(
								"customerOrder.doDetails.doDetail.orderType"));

			} else if (CHENNEL.contains("facebook")) {
				assertTrue(response
						.jsonPath()
						.getString(
								"customerOrder.paymentDetails.paymentDetail.cardType")
						.contains("Facebook"));
				Reporter.addStepLog("The payment card type is "
						+ response
								.jsonPath()
								.getString(
										"customerOrder.paymentDetails.paymentDetail.cardType"));

				assertTrue(response
						.jsonPath()
						.getString("customerOrder.doDetails.doDetail.orderType")
						.contains("OT_FB"));

				Reporter.addStepLog("The DO Order type is "
						+ response.jsonPath().getString(
								"customerOrder.doDetails.doDetail.orderType"));

			}

			if (!ORDERSTATUS.contains("")) {
				assertTrue(response.jsonPath()
						.getString("customerOrder.orderStatus")
						.contains(ORDERSTATUS));

				Reporter.addStepLog("The Order Status is "
						+ response.jsonPath().getString(
								"customerOrder.doDetails.doDetail.orderType"));

			}
		} catch (AssertionError | Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.addStepLog(ExceptionUtils.getStackTrace(e));

		}
		log.info(response.body().asString());
		return response;
	}

	public JSONObject getJSONAttributeVal(String filename) throws IOException,
			ParseException {
		Object configobj = new JSONParser().parse(new InputStreamReader(this
				.getClass().getClassLoader().getResourceAsStream(filename)));
		JSONObject jconfigobj = (JSONObject) configobj;
		return jconfigobj;
	}

	public String getBaseURL(String CONFIG_FILE) throws IOException,
			ParseException {
		JSONObject jconfigobj = getJSONAttributeVal(CONFIG_FILE);
		String BaseURL = (String) jconfigobj.get("BaseURL");
		return BaseURL;
	}

}
