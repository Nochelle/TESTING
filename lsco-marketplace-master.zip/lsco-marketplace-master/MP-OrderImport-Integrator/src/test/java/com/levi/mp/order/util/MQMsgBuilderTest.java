package com.levi.mp.order.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.levi.mp.OrderImportSharedTestConfig;
import com.levi.mp.config.OrderImportLoadConfiguration;
import com.levi.mp.order.model.xml.TXML;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;
import com.levi.mp.shared.sns.SNSService;


@RunWith(SpringRunner.class)
@SpringBootTest(classes=OrderImportSharedTestConfig.class)
public class MQMsgBuilderTest {
	
	@MockBean
	ChannelAdvisorTokenService advisorTokenService;

	@Autowired
	MQMsgBuilder mqMsgBuilder;
	
	@MockBean
	OrderImportLoadConfiguration orderImportLoadConfiguration;
	
	@MockBean
	TXML txml;
	
	@MockBean
	SNSService snsService;
	
	@Test
	public void buildSendMsgTest_HappyPath() {
		String jsonString = mqMsgBuilder.buildSendMsg(txml);
		assertNotNull("jsonString is null", jsonString);
	}
	
	@Test
	public void buildSendMsgTest_Error() {
		
		Mockito.when(snsService.notifySupport(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(Boolean.TRUE);
		String jsonString = mqMsgBuilder.buildSendMsg(null);
		assertNull("jsonString is null", jsonString);
	}
}
