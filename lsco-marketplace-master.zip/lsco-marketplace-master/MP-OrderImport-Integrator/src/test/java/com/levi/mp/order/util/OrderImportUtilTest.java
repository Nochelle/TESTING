package com.levi.mp.order.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.io.File;
import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.OrderImportSharedTestConfig;
import com.levi.mp.config.OrderImportLoadConfiguration;
import com.levi.mp.order.model.json.ChannelAdvisorOrder;
import com.levi.mp.order.model.json.FacebookConfig;
import com.levi.mp.order.model.json.GoogleConfig;
import com.levi.mp.order.model.json.MQConfig;
import com.levi.mp.order.model.json.OrderImportConfig;
import com.levi.mp.order.model.json.Orders;
import com.levi.mp.order.model.xml.TXML;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;
import com.levi.mp.shared.sns.SNSService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = OrderImportSharedTestConfig.class)
public class OrderImportUtilTest {
	
	@MockBean
	ChannelAdvisorTokenService advisorTokenService;
	
	@Autowired
	OrderImportUtil orderImportUtil;
	
	@MockBean
	OrderImportLoadConfiguration orderImportLoadConfig;
	
	@MockBean
	SNSService snsService;
	
	private OrderImportConfig orderImportConfig = new OrderImportConfig();
	
	@Before
    public void setUp() {
		//System.out.println("inside setup");
		MQConfig mqConfig= new MQConfig();
		
		FacebookConfig facebookConfig = new FacebookConfig();
		facebookConfig.setFreeReturn(true);
		facebookConfig.setSmartLabelFee(new BigDecimal("0.00"));
		
		GoogleConfig googleConfig = new GoogleConfig();
		googleConfig.setFreeReturn(false);
		googleConfig.setSmartLabelFee(new BigDecimal("5.8"));
		
		orderImportConfig.setGoogle(googleConfig );;
		orderImportConfig.setFacebook(facebookConfig);
		orderImportConfig.setMqConfig(mqConfig);
		
    }
	
	@Test
	public void convertUTCtoCSTTest() {
		try {
			String currentTimeWithMS = "2018-11-21T19:42:05.07688Z";
			String convertedDate  = OrderImportUtil.convertUTCtoCST(currentTimeWithMS);
			assertNotNull("Converted Date is null", convertedDate);
			assertTrue("Converted Date is enpty", !convertedDate.isEmpty());
			
			String currentTimeWithOutMS = "2018-11-21T19:42:05Z";
			
			assertNotNull("2nd Converted Date is null", currentTimeWithOutMS);
			assertTrue("2nd Converted Date is enpty", !convertedDate.isEmpty());
			
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}
	
	@Test
	public void convertUTCtoCSTTest_Error_With_invalid_date() {
		try {
			String invalidCurrentTime = "2018-11-21T19:42:05";
			OrderImportUtil.convertUTCtoCST(invalidCurrentTime);
		} catch (Exception e) {
			//e.printStackTrace();
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
			return;
		}
		assertTrue("Expected the test case to fail for invalid currentTime, but it did not!", true == !true);
	}
	
	@Test
	public void convertUTCtoCSTTest_Error_With_Null_Date() {
		try {
			String invalidCurrentTime = null;
			OrderImportUtil.convertUTCtoCST(invalidCurrentTime);
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
			return;
		}
		assertTrue("Expected the test case to fail for null, but it did not!", true == !true);
	}
	
	@Test
	public void getCurrentDateTimeTest() {
		String timeZone="CST";
		String dateFormat = "MM/dd/yyyy HH:mm:ss";
		
		try {
			String convertedDate  = OrderImportUtil.getCurrentDateTime(timeZone, dateFormat);
			assertNotNull("converted current Date is null", convertedDate);
			assertTrue("converted current Date is enpty", !convertedDate.isEmpty());
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}
	
	@Test
	public void covertJsonToXMLObjectTest_HappyPath() {
		
		when(orderImportLoadConfig.getOrderImportConfig()).thenReturn(orderImportConfig);
		
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			//read from a static json file
			//Orders orders = objectMapper.readValue(new File("src/main/resources/OrderImports2.json"), Orders.class);
			Orders orders = objectMapper.readValue(
					new File(this.getClass().getClassLoader().getResource("FB.json").getFile())
					,Orders.class);
			
			//Orders orders = objectMapper.readValue(new File("src/main/resources/FB.json"), Orders.class);
			TXML txml = null;
			
			for (ChannelAdvisorOrder order : orders.getCaOrders()) {
				//System.out.println("ordeID:"+order.getID());
				txml = orderImportUtil.convertJsonToXMLObject(order);
				//String txmlSting = MQMsgBuilder.buildSendMsg(txml);
				////System.out.println("txmlSting:\n"+txmlSting);
				assertNotNull("xml is null", txml);
				assertNotNull("Header is null", txml.getHeader());
				assertNotNull("xMessage is null", txml.getMessage());
				assertEquals("OrderID is not matching in json vs XML", String.valueOf(order.getID()), 
						txml.getMessage().getOrder().getExternalOrderNumber().getValue());
			}
			
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}
	
	@Test
	public void covertJsonToXMLObjectTest_Error() {
		
		try {
			Mockito.when(orderImportLoadConfig.getOrderImportConfig()).thenReturn(orderImportConfig);
			Mockito.when(snsService.notifySupport(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			ObjectMapper objectMapper = new ObjectMapper();

			Orders orders = objectMapper.readValue(
					new File(this.getClass().getClassLoader().getResource("OrderImports-error.json").getFile())
					,Orders.class);
		
			TXML txml = null;
			
	
			
			for (ChannelAdvisorOrder order : orders.getCaOrders()) {
			
				txml = orderImportUtil.convertJsonToXMLObject(order);
				assertEquals(null, txml);
			}
			
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}
	
}
