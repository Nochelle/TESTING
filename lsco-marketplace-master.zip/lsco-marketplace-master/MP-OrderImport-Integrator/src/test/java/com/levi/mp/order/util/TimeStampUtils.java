package com.levi.mp.order.util;

import java.text.SimpleDateFormat;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class TimeStampUtils {


	public String getFileNameWithTime(String fileName) {

		String timeStamp = new SimpleDateFormat("yyyy_MM_dd_HH:mm").format(new java.util.Date());
		String finalFileName=fileName.replaceAll("testorderOut","testorderOut"+timeStamp);		
		return finalFileName;

	}

} 