package com.levi.mp.order.function;

import java.io.IOException;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;

/**
 * A simple test harness for locally invoking your Lambda function handler.
 */
public class OrderImportFunctionHandlerTest {

	private static Object input;

	@BeforeClass
	public static void createInput() throws IOException {
		// TODO: set up your sample input object here.
		input = "{\"key1\":\"val1\"}";
	}

	private Context createContext() {
		TestContext ctx = new TestContext();

		// TODO: customize your context here if needed.
		ctx.setFunctionName("MP-OrderImport-Ingegrator");

		return null;
	}
	
	//@Test
	//@Ignore
  	public void testOrderImportHandler() {
		OrderImportLambdaHandler handler = new OrderImportLambdaHandler();
  		 Context ctx = createContext();
  		 String output = handler.handleRequest(input, ctx);

  		// TODO: validate output here if needed.
  		 Assert.assertNotNull(output);
  	}
}
