package com.levi.mp.order.rest.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.io.File;
import java.nio.charset.StandardCharsets;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.OrderImportSharedTestConfig;
import com.levi.mp.config.OrderImportLoadConfiguration;
import com.levi.mp.order.model.json.Orders;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;
import com.levi.mp.shared.sns.SNSService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = OrderImportSharedTestConfig.class)
public class OrderRestClientAdapterTest {

	@Autowired
	OrderRestClientAdapter orderRestClientAdapter;

	@MockBean
	RestTemplate restTemplate;

	@MockBean
	SNSService snsService;

	@MockBean
	OrderImportLoadConfiguration orderimportLoadConfiguration;

	final String accessToken = "dummyToken123";
	
	@MockBean
	ChannelAdvisorTokenService advisorTokenService;

	@Test
	public void getUnexportedOrdersTest_HappyPath() {
		try {
			ResponseEntity<String> responseEntity = ResponseEntity.ok(getDummyOrders());

			when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.<Class<String>>any()))
					.thenReturn(responseEntity);

			Orders orders = orderRestClientAdapter.getUnexportedOrders();
			assertNotNull("orders is null", orders);
			assertTrue("order list is enpty", !orders.getCaOrders().isEmpty());
			assertEquals("order list is not equal to 2", 2, orders.getCaOrders().size());
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}
	
	@Test
	public void getUnexportedOrdersTest_Not200Response() {
		try {
			ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
			when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.<Class<String>>any()))
					.thenReturn(responseEntity);

			Orders orders = orderRestClientAdapter.getUnexportedOrders();
			assertNotNull("orders is null", orders);
			assertTrue("order list is enpty", !orders.getCaOrders().isEmpty());
			assertEquals("order list is not equal to 2", 2, orders.getCaOrders().size());
		} catch (Exception e) {
			// e.printStackTrace();
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
			return;
		}
		assertTrue("Expected the test case to fail for Unauthorized, but it did not!", true == !true);
	}
	
	@Test(expected=Exception.class)
	public void getUnexportedOrdersTest_Error() {
		ResponseEntity<String> responseEntity = ResponseEntity.ok(getDummyInvalidOrders());// OrderImports_invalid_response.json
		when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.<Class<String>>any()))
				.thenReturn(responseEntity);

		orderRestClientAdapter.getUnexportedOrders();
	}

	@Test
	public void updateOrderSatusFlagTest_HappyPath() {
		try {
			String orderId = "dummyOrderId123";
			ResponseEntity<String> responseEntity = ResponseEntity.noContent().build();

			when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.<Class<String>>any()))
					.thenReturn(responseEntity);

			boolean successFlag = orderRestClientAdapter.updateOrderSatusFlag(orderId, accessToken);
			assertNotNull("successFlag is null", successFlag);
			assertTrue("successFlag is false", successFlag);
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}

	@Test
	public void updateOrderSatusFlagTest_Not204Response() {
		try {
			String orderId = "dummyOrderId123";
			ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();

			when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.<Class<String>>any()))
					.thenReturn(responseEntity);

			boolean successFlag = orderRestClientAdapter.updateOrderSatusFlag(orderId, accessToken);
			assertNotNull("successFlag is null", !successFlag);
		} catch (Exception e) {
			// e.printStackTrace();
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
			return;
		}
		assertTrue("Expected the test case to fail for not a 204 response, but it did not!", true == !true);
	}

	public String getDummyOrders() {
		ObjectMapper objectMapper = new ObjectMapper();
		String jsonString = "{}";
		try {

			Orders orders = objectMapper.readValue(new File(this.getClass().getClassLoader().getResource("OrderImports2.json").getFile()), Orders.class);
			// Orders orders = objectMapper.readValue(new File("src/main/resources/OrderImports2.json"), Orders.class);

			jsonString = objectMapper.writeValueAsString(orders);
			// //System.out.println(jsonString);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: what is the purpose of this test?
		}
		return jsonString;
	}
	
	public String getDummyInvalidOrders() {
		String jsonString = "";
		try {
			jsonString = StreamUtils.copyToString(this.getClass().getClassLoader().getResourceAsStream("OrderImports_invalid_response.json"), StandardCharsets.UTF_8);
			//jsonString = new String(Files.readAllBytes(Paths.get(this.getClass().getClassLoader().getResource("OrderImports_invalid_response.json").getFile())), StandardCharsets.UTF_8);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: what is the purpose of this test?
		}
		return jsonString;
	}
	
	
	
	@Test
	public void getNextUnexportedOrdersTest_HappyPath() {
		try {
			ResponseEntity<String> responseEntity = ResponseEntity.ok(getDummyOrders());

			when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.<Class<String>>any()))
					.thenReturn(responseEntity);

			Orders orders = orderRestClientAdapter.getNextUnexportedOrders("https://google.com");
			assertNotNull("orders is null", orders);
			assertTrue("order list is enpty", !orders.getCaOrders().isEmpty());
			assertEquals("order list is not equal to 2", 2, orders.getCaOrders().size());
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}
	
	@Test(expected=RuntimeException.class)
	public void getNextUnexportedOrdersTest_Not200Response() {
		ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

		when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.<Class<String>>any()))
				.thenReturn(responseEntity);

		orderRestClientAdapter.getNextUnexportedOrders("https://google.com");
	}

}
