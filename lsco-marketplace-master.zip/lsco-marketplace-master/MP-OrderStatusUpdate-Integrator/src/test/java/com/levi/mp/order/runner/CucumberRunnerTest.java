package com.levi.mp.order.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(  
features = "src/test/resources/features/OrderStatusUpdate.feature",  
glue={"com.levi.mp.order.stepdef"},  
plugin = {"pretty","html:target/cucumber/report.html","com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/extentReport.html"},
	monochrome = true,  
	tags="@E2E"  
	)  
	
public class CucumberRunnerTest {

} 