package com.levi.mp.order.util;

import static org.junit.Assert.assertTrue;
import io.restassured.response.Response;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import org.json.simple.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
//import com.levi.mp.order.model.json.OrderCreationData;

public class CommonUtilities {


public static void updateXMLTagText(String filepath, String tagName, String tagText) throws ParserConfigurationException, SAXException, IOException, TransformerException{
                    
    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
    Document doc = docBuilder.parse(filepath);
    Node node = doc.getElementsByTagName(tagName).item(0);
                    
    node.setTextContent(tagText);                                  

    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(new File(filepath));
    transformer.transform(source, result);

}
public static String getXMLTagText(String filepath, String tagName) throws ParserConfigurationException, SAXException, IOException, TransformerException{
                
    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
    Document doc = docBuilder.parse(filepath);
    Node node = doc.getElementsByTagName(tagName).item(0);
    
    return node.getTextContent();  
}
public static String generateRandomNum(){
                String Randomresult = RandomStringUtils.random(64, false, true);
                Randomresult = RandomStringUtils.random(4,0, 9, false, false, "123456789".toCharArray());
                return Randomresult;
}
public static void assertJsonRes_byNodeNames(Response response, JSONObject jo, List<String> nodenames){
                for(int i =0; i < nodenames.size(); i++){
                                assertTrue(response.jsonPath().getString(nodenames.get(i)).contains(jo.get(nodenames.get(i)).toString()));}
}
public static void assertJsonRes_byNodeNames(Response response, JSONObject jo, List<String> in_nodenames,List<String> out_nodenames){
                for(int i =0; i < out_nodenames.size(); i++){
                     assertTrue(response.jsonPath().getString(out_nodenames.get(i)).contains(jo.get(in_nodenames.get(i)).toString()));}
}
public static void assertJsonRes_byOutput(Response response, List<String> nodenames, List<String> outputs){
                for(int i =0; i < nodenames.size(); i++){   
                                assertTrue(response.jsonPath().getString(nodenames.get(i)).contains(outputs.get(i)));
                }
                
}
public static void assertSoftJsonRes_byNodeNames(Response response, JSONObject jo, List<String> nodenames){
                SoftAssertions softly = new SoftAssertions();
                for(int i =0; i < nodenames.size(); i++){
                        softly.assertThat(response.jsonPath().getString(nodenames.get(i)).contains(jo.get(nodenames.get(i)).toString()));}
}
                
//public static List<OrderCreationData> readNodesFromCSV(String csvFilePath) throws  IOException{       
//	CsvMapper csvMapper = new CsvMapper();
//	CsvSchema schema = csvMapper.schemaFor(OrderCreationData.class).withHeader();       
//	ObjectReader oReader = csvMapper.reader(OrderCreationData.class).with(schema);
//	 MappingIterator<OrderCreationData> mit = oReader.readValues(new FileReader(csvFilePath));
//	 List<OrderCreationData> orderCtreationDataList = new ArrayList<OrderCreationData>();
//	 
//	 while (mit.hasNext()) {                        
//	        orderCtreationDataList.add(mit.next());              
//	    }
//	                return orderCtreationDataList;
//	}
//
//public static void writeToCSV(String csvFilePath, List<OrderCreationData> data) throws  Exception{
//File outputFile = null;
//                ObjectWriter writer = null;
//                CsvMapper csvMapper = new CsvMapper();
//                CsvSchema schema = csvMapper.schemaFor(OrderCreationData.class)
//                                                .withHeader();
//
//                try {
//                                outputFile = new File(csvFilePath);
//                                if (!outputFile.exists()) {
//                                                outputFile.createNewFile();
//                                }
//
//                                writer = csvMapper.writer(schema);
//                                csvMapper.writer(schema).writeValue(outputFile, data);
//                } catch (Exception e) {
//                                e.printStackTrace();
//                }
//                            
//}
public static void sleep(int seconds){
                try {
                                Thread.sleep(seconds * 1000);
                } catch (InterruptedException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                }
}
    
   
}
