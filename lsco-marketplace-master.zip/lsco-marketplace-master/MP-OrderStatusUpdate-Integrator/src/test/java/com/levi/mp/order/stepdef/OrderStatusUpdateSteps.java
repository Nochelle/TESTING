package com.levi.mp.order.stepdef;

import io.restassured.response.Response;

import java.io.IOException;
import java.util.List;

import junit.framework.Assert;
import lombok.extern.log4j.Log4j2;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.json.simple.parser.ParseException;

import com.cucumber.listener.Reporter;
import com.aventstack.extentreports.ExtentTest;
import com.levi.mp.order.model.json.OrderDownloadData;
import com.levi.mp.order.stepmethods.AccessTokenGenerator;
import com.levi.mp.order.stepmethods.DownloadFileFromS3;
import com.levi.mp.order.stepmethods.UpdateOrderStatusInCA;
import com.levi.mp.order.stepmethods.UpdateOrderStatusMethods;
import com.levi.mp.order.util.TestDataProvider.TestData;

import cucumber.api.java.en.Then;

@Log4j2
public class OrderStatusUpdateSteps {

	public AccessTokenGenerator accessTokenGenerator;
	public UpdateOrderStatusInCA updateOrderStatusInCA;
	public UpdateOrderStatusMethods updateOrderStatusMethods;
	public DownloadFileFromS3 downloadFileFromS3;
	public static List<OrderDownloadData> orderDownloadDataList;
	String accessToken;
	Response response;
	ExtentTest extentTest;
	String clientRegion = TestData.REGION.val();
	String bucketName = TestData.BUCKETNAME.val();
	String key = TestData.FILENAME.val();

	public OrderStatusUpdateSteps() throws IOException, ParseException {
		accessTokenGenerator = new AccessTokenGenerator();
		updateOrderStatusInCA = new UpdateOrderStatusInCA();
		updateOrderStatusMethods = new UpdateOrderStatusMethods();
		downloadFileFromS3 = new DownloadFileFromS3();
		accessToken = accessTokenGenerator.createNewAccessToken(
				"testprops/testconfig.json", "testprops/RefreshTokenJSON.json");
		orderDownloadDataList=downloadFileFromS3
				.downloadFileFromS3(clientRegion, bucketName, key);
	}

	@Then("^trigger order status update lambda funtion$")
	public void trigger_order_staus_update_lambda_funtion() throws Throwable {
		try {
			Thread.sleep(10000);

			log.info("access token:" + accessToken);
			updateOrderStatusInCA.updateOrderStatusInCA();
			log.info("Order status updated>>>");
			Reporter.addStepLog("Order Status Update lambda function has been triggred");

		}

		catch (Exception e) {

			Reporter.addStepLog("Step Failed" + ExceptionUtils.getStackTrace(e));
		}
	}

	@Then("^verify order status in Channel Advisor$")
	public void verify_order_status_as_in_CA() throws Throwable {
		for (OrderDownloadData OrderDownloadData : orderDownloadDataList) {
			try {
				List<String> channelAdvisorStatus=updateOrderStatusMethods.getOrderResponse(
						OrderDownloadData.getOrderNumber(), accessToken,
						OrderDownloadData.getShipment_type());

				Reporter.addStepLog("Shipping Status is validated as "+channelAdvisorStatus.get(0).toString() +" in channel advisor "+" for the order "+OrderDownloadData.getSiteOrderID());
				Reporter.addStepLog("Fulfillment type is validated as "+channelAdvisorStatus.get(1).toString() +" in channel advisor "+" for the order "+OrderDownloadData.getSiteOrderID());
				Reporter.addStepLog("==========================================================================");

			}
			catch (Exception e) {
				Reporter.addStepLog("Unable to retrieve status from channel advisor for "
						+ OrderDownloadData.getSiteOrderID());

				e.printStackTrace();
			}

		}
		log.info("Shipping status verified>>");
	}

	@Then("^download the released automation orders from S3 bucket$")
	public List<OrderDownloadData> Download_the_released_automation_orders_from_S3_bucket()
			throws Throwable {

		String clientRegion = TestData.REGION.val();
		String bucketName = TestData.BUCKETNAME.val();
		String key = TestData.FILENAME.val();
try{
		orderDownloadDataList = downloadFileFromS3
				.downloadFileFromS3(clientRegion, bucketName, key);
}

catch(Exception ex)
{
	Reporter.addStepLog("Order download from S3 failed");
	}
		log.info("Orders are downloaded successfully>>");
		for (OrderDownloadData OrderDownloadData : orderDownloadDataList) {
			try {

				Reporter.addStepLog("Order downloaded from S3 and the site order id  is  "
						+ OrderDownloadData.getSiteOrderID()
						+ " and DO Number is " + OrderDownloadData.getDoNbr());
			} catch (Exception e) {
				Reporter.addStepLog("Order download from S3 failed");
				
			}

		}
		return orderDownloadDataList;

	}

}
