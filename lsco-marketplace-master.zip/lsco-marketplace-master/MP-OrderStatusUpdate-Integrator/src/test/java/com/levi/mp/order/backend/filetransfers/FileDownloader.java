package com.levi.mp.order.backend.filetransfers;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.cucumber.listener.Reporter;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;


public class FileDownloader  {

public FileDownloader() {

}

public static  ArrayList<String> SFTP_DownloadOTF(String SFTPHOST,int SFTPPORT,String SFTPUSER,String SFTPPASS,String SFTPWORKINGDIR,
		String FilePath , String ThreeDigitNum) throws JSchException, SftpException {

		JSch jsch = new JSch();
		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;
		ArrayList<String> OTFfiles = new ArrayList<String>();


		ArrayList<String> returnOTFfiles = new ArrayList<String>();
		session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
		session.setPassword(SFTPPASS);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		session.setConfig(config);                                            
		session.connect();
		channel = session.openChannel("sftp");
		channel.connect();
		channelSftp = (ChannelSftp) channel;
		channelSftp.cd(SFTPWORKINGDIR.trim());
		@SuppressWarnings("rawtypes")
		Vector filelist = channelSftp.ls(SFTPWORKINGDIR);

		ChannelSftp sftpChannel = (ChannelSftp) channel;
		try {
		for (int i = 0; i < filelist.size(); i++) {
		LsEntry entry = (LsEntry) filelist.get(i);
		if (entry.toString().endsWith(ThreeDigitNum + ".xml")&&entry.toString().contains("CLTO")
										|| entry.toString().endsWith(ThreeDigitNum + ".XML")&&entry.toString().contains("CLTO")) {

						OTFfiles.add(entry.getFilename());
						System.err.println(">>>>"+entry.getFilename());
						
		} else {
						continue;
		}
		}

		for (int i = 0; i < OTFfiles.size(); i++) {
		sftpChannel.get(SFTPWORKINGDIR + "/" + OTFfiles.get(i),FilePath);
		returnOTFfiles.add(FilePath+"/"+OTFfiles.get(i)) ;
						
						
						
		}

		sftpChannel.exit();
		session.disconnect();
		
		Reporter.addStepLog("CLTOTF File downloaded for the DO Number ending with "+ThreeDigitNum);
		
		} catch (Exception e) {
				e.printStackTrace();
		}finally {
		try {
		if (sftpChannel.isConnected()) {
		sftpChannel.disconnect();
		}
		} catch (Exception ex) {
		ex.printStackTrace();
		}
		}
				return returnOTFfiles;
		}
}



