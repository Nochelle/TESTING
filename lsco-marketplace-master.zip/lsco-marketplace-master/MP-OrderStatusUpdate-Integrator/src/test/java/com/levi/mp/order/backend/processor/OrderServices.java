package com.levi.mp.order.backend.processor;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;




public class OrderServices {
	
	
	public String getOrderStatus(String EomUrl,String EOMSuer, String Password, String ordernum)   {
		String orderstatus="";
		CredentialsProvider provider = new BasicCredentialsProvider();
		UsernamePasswordCredentials credentials= new UsernamePasswordCredentials(EOMSuer,Password);
		provider.setCredentials(AuthScope.ANY, credentials);
		HttpClient httpclient = HttpClientBuilder.create().setDefaultCredentialsProvider(provider).build();
		try {
			HttpGet getRequest = new HttpGet(EomUrl+"/services/olm/customerorder/customerOrderDetails?responseType=FullCustomerOrder&customerOrderNumber="+ordernum);
			HttpResponse httpResponse = httpclient.execute(getRequest);
			HttpEntity entity = httpResponse.getEntity();
			
			Header[] headers = httpResponse.getAllHeaders();
			for (int i = 0; i < headers.length; i++) {
			}
			
			String responseJson = null;
			if (entity != null) {
				responseJson=EntityUtils.toString(entity);	
			}
			if(responseJson.toLowerCase().contains("DO Created".toLowerCase())){
				orderstatus= "do created";
			}
			else if(responseJson.toLowerCase().contains("DO Released".toLowerCase()))
			{
				orderstatus= "do released";
			}
			else if(responseJson.toLowerCase().contains("\"orderStatus\":\"Completed\"".toLowerCase()))
			{
				orderstatus= "completed";
			
			}
			else if(responseJson.toLowerCase().contains("\"orderStatus\":\"Canceled\"".toLowerCase()))
			{
				orderstatus= "canceled";
		
			}
			else if(responseJson.toLowerCase().contains("\"orderStatus\":\"Released\"".toLowerCase()))
			{
				orderstatus= "released";
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			httpclient.getConnectionManager().shutdown();
			 
		}
		return orderstatus;
	}
	

}
