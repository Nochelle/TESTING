package com.levi.mp.order.stepmethods;

import static org.junit.Assert.assertTrue;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import lombok.extern.log4j.Log4j2;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.cucumber.listener.Reporter;
//import com.cucumber.listener.Reporter;


@Log4j2
public class UpdateOrderStatusMethods {
	RequestSpecification request; 
	Response response;
	String status;
	String CheckoutStatus;
	String ShippingStatus;
public  List<String> getOrderResponse(String CAID,String accessToken,String shipmentType) throws IOException, ParseException, InterruptedException
    {
	Thread.sleep(8000);
List<String>orderDetailsInCA=new ArrayList<String>();
		status=null;
		 CheckoutStatus=null;
		if(shipmentType.contains("full shipment"))
		{
		status="Shipped";
		CheckoutStatus="Completed";
		ShippingStatus="shipped";
		}
		else
		{
		
		if(shipmentType.contains("cancel"))
		{
		status="Canceled";
		CheckoutStatus="Disabled";
		ShippingStatus="Canceled";
		}
		}
		Thread.sleep(4000);
		String URL = "https://api.channeladvisor.com/v1/Orders?access_token="
				+ accessToken
				+ "&exported=true&$expand=Items($expand=Promotions),Fulfillments&$filter=CheckoutStatus eq "+"\'"+CheckoutStatus+"\'"+" and PaymentStatus eq 'Cleared' and ShippingStatus eq "+"\'"+ShippingStatus+"\'"+" and ID eq "
				+ Integer.parseInt(CAID);
		System.out.println(">>>>>>>>>>>>   "+URL);
		Response response;
		RequestSpecification request;
		request = RestAssured.given();
		response = request
				.headers("Content-Type", ContentType.JSON, "Accept",
						ContentType.JSON).when().get(URL).then()
				.contentType(ContentType.JSON).extract().response();
		  log.info(request.toString());
	      try {
			assertTrue(response.statusCode()==200);
			  log.info(response.body().asString());
			  log.info(">>>>>>>>>"+response.jsonPath().getString("value.ShippingStatus"));
			  log.info(">>>>>>>>>"+response.jsonPath().getString("value.Fulfillments.Type"));
			  System.out.println(CAID);
			  System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>"+status);
			  assertTrue(response.jsonPath().getString("value.ShippingStatus").contains(status));
			  assertTrue(response.jsonPath().getString("value.Fulfillments.Type").contains("Ship"));
			  
			  orderDetailsInCA.add(response.jsonPath().getString("value.ShippingStatus"));
			  orderDetailsInCA.add(response.jsonPath().getString("value.Fulfillments.Type"));
		} catch (AssertionError |Exception e) {
			// TODO Auto-generated catch block
			Reporter.addStepLog("Step Failed "+ ExceptionUtils.getStackTrace(e)); 
			e.printStackTrace();
		}	
     return orderDetailsInCA;
	} 
	

	public JSONObject getJSONAttributeVal(String filename) throws IOException, ParseException{
		Object configobj = new JSONParser().parse(new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream(filename)));
	    JSONObject jconfigobj = (JSONObject) configobj; 
		return jconfigobj;
	}
	public String getBaseURL(String CONFIG_FILE) throws IOException, ParseException{
		JSONObject jconfigobj= getJSONAttributeVal(CONFIG_FILE);	      
	    String BaseURL = (String) jconfigobj.get("BaseURL");
		return BaseURL;
	}
	
}
