package com.levi.mp.order.stepdef;

import io.restassured.response.Response;

import java.io.File;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.cucumber.listener.Reporter;
import com.levi.mp.order.backend.processor.BackendStarter;
import com.levi.mp.order.model.json.OrderDownloadData;
import com.levi.mp.order.stepmethods.AccessTokenGenerator;
import com.levi.mp.order.stepmethods.DownloadFileFromS3;
import com.levi.mp.order.stepmethods.OrderIntegratorMethods;
import com.levi.mp.order.stepmethods.UpdateOrderStatusMethods;
import com.levi.mp.order.util.TestDataProvider.TestData;

import cucumber.api.java.en.Then;

public class BackendStep {
    public AccessTokenGenerator accessTokenGenerator;
    public OrderIntegratorMethods orderintegratormethods;
    public OrderStatusUpdateSteps orderStatusUpdateSteps;
    public DownloadFileFromS3 downloadFileFromS3;
    public static String orderNum = "";
    public static String doNum = "";
    public BackendStarter backEnd;
    public static List<OrderDownloadData> orderDownloadDataList;
    public UpdateOrderStatusMethods updateOrderStatusMethods;
    String accessToken;
    String orderStatus_new;
    Response response;

    File shipmentFile;

    public BackendStep() throws Throwable {
                    accessTokenGenerator = new AccessTokenGenerator();
                    backEnd = new BackendStarter();
                    orderintegratormethods = new OrderIntegratorMethods();
                    orderStatusUpdateSteps = new OrderStatusUpdateSteps();
                    orderDownloadDataList = OrderStatusUpdateSteps.orderDownloadDataList;
                    updateOrderStatusMethods = new UpdateOrderStatusMethods();
                    accessToken = accessTokenGenerator.createNewAccessToken(
                                                    "testprops/testconfig.json", "testprops/RefreshTokenJSON.json");
    }

    @Then("^create order shipment files and upload to sftp$")
    public void create_order_shipment_files_and_upload_to_sftp()
                                    throws Throwable {

    try {

    if (!orderDownloadDataList.isEmpty()) {
for (int i = 0; i < orderDownloadDataList.size(); i++) {
    System.out.println(orderDownloadDataList.get(i)+ "do order list is printed");
    System.out.println(orderDownloadDataList.get(i).getOrderNumber());

    String substr = orderDownloadDataList.get(i).getDoNbr().substring(orderDownloadDataList.get(i).getDoNbr().length() - 3);

    System.err.println("do no data " + substr);
    String ordernum = orderDownloadDataList.get(i)
                                    .getSiteOrderID();
    System.out.println(ordernum);

    File resourcesDirectory = new File("src/test/resources/orderxmls");
    String filepath = resourcesDirectory.getAbsolutePath();

    if (i == 0) {

    if (resourcesDirectory.isDirectory()) {
    for (File fileToBeDeleted : resourcesDirectory.listFiles())
                    if (fileToBeDeleted.getAbsolutePath().contains("xml"))fileToBeDeleted.delete();
    }

    }

    System.out.println(filepath);

    String caserver = TestData.SFTPCASERVER.val();
    String leviuser = TestData.SFTPLEVICAUSER.val();
    String levipassword = TestData.SFTPLEVICAPASSWORD.val();
    String inboundpath = TestData.SFTPLEVICAINBOUNDPATH.val();
try{
    shipmentFile = backEnd.createShipment(caserver, 22,leviuser, levipassword, inboundpath, filepath,substr, ordernum, orderDownloadDataList.get(i).getShipment_type());

    String outboundpath = TestData.SFTPLEVICAOUTBOUNDPATH.val();
      
    backEnd.uploadShipment(caserver, 22, leviuser,levipassword, outboundpath, filepath, "",shipmentFile,ordernum);
}

catch(Exception e)
{
	}

    Reporter.addStepLog("Shipment Creation & SFTP Upload Completed for orderId "+orderDownloadDataList.get(i).getDoNbr()+" and site order id  "+orderDownloadDataList.get(i).getSiteOrderID()); 
    Reporter.addStepLog("======================================================================================"); 
 
    
}
    }
    } catch (Exception e) {
    Reporter.addStepLog("Exception occured during the Shipment Creation Process " + ExceptionUtils.getStackTrace(e)); 
    e.printStackTrace();
    
                }

}

@Then("^Wait for \"([^\"]*)\" mins to prepare for next step$")
public void wait_for_sync(int waittime) throws Throwable {
}

@Then("^Verify order status in EOM$")
public void verifyOrderStatus_in_EOM() throws Throwable {
try {
	String orderstatus=null;
    for (int i = 0; i < orderDownloadDataList.size(); i++) {
                    String orderNum = orderDownloadDataList.get(i).getSiteOrderID()
                                                    .toString().trim();

                    String status = orderDownloadDataList.get(i).getShipment_type();
                    if (status.contains("full shipment")||status.contains("full")) {
                    orderstatus = "Completed";
    } else {
                    if (status.contains("cancel shipment")||status.contains("cancel")) {
                    orderstatus = "Canceled";
                    }
    }
   
   
    orderStatus_new= backEnd.verifyOrderStatus(orderstatus, orderNum);
    Reporter.addStepLog("Validated order status in EOM as  "+orderStatus_new +" for the site order id "+orderDownloadDataList.get(i).getSiteOrderID()+" and the do number "+orderDownloadDataList.get(i).getDoNbr());
}
} catch (Exception e) {
                e.printStackTrace();
                Reporter.addStepLog("Step failed "+ ExceptionUtils.getStackTrace(e));
                }

}

}
