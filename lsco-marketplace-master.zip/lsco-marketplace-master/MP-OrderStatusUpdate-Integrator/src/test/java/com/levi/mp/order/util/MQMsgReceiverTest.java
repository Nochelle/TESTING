package com.levi.mp.order.util;

import javax.jms.JMSException;
import javax.jms.QueueConnection;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.TextMessage;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.ibm.mq.jms.MQQueue;
import com.levi.mp.OrderStatusUpdateTestConfig;
import com.levi.mp.config.MQBeanHelper;
import com.levi.mp.config.OrderStatusUpdateLoadConfiguration;
import com.levi.mp.order.model.json.MQConfig;
import com.levi.mp.order.model.json.OrderStatusUpdateConfig;
import com.levi.mp.shared.sns.SNSService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = OrderStatusUpdateTestConfig.class)
public class MQMsgReceiverTest {
	
	@MockBean
	MQBeanHelper mQBeanHelper;
	
	@MockBean
	QueueConnection queueConnection;
	
	@MockBean
	QueueSession queueSession;
	
	@MockBean
	MQQueue mqQueue;
	
	@MockBean
	QueueReceiver queueReceiver;	
	
	@MockBean
	TextMessage message;
	
	@MockBean
	OrderStatusUpdateLoadConfiguration orderStatusUpdateLoadConfiguration;

	@Autowired
	MQMsgReceiver mqMsgReceiver;
	
	@MockBean
	SNSService snsService;
	
	static final MQConfig mqConfig = new MQConfig(); 
	static final OrderStatusUpdateConfig orderStatusUpdateConfig = new OrderStatusUpdateConfig(); 
	@BeforeClass
	public static void setUp() {
		createMockMQConfig();
	}


	@Test
	public void receiveMQMsgTest() {
		
		try {
			
			Mockito.when(mQBeanHelper.getConfig()).thenReturn(orderStatusUpdateLoadConfiguration);
			Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig()).thenReturn(orderStatusUpdateConfig);
			
			Mockito.when(mQBeanHelper.getQueueConnection()).thenReturn(queueConnection);
			Mockito.doNothing().when(queueConnection).start();
			Mockito.when(queueConnection.createQueueSession(Mockito.anyBoolean(), Mockito.anyInt()))
				.thenReturn(queueSession);
			Mockito.when(mQBeanHelper.getMQQueue()).thenReturn(mqQueue);
			Mockito.when(queueSession.createReceiver(Mockito.any(MQQueue.class)))
				.thenReturn(queueReceiver);
			
			message.setText("Dumy_Message");
			
			//cannot test while(true) so have to return null Message instance
			Mockito.when(queueReceiver.receive(Mockito.anyLong())).thenReturn(null);
			Mockito.doNothing().when(queueConnection).close();
			
			mqMsgReceiver.receiveMQMsg();
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	@Test
	public void receiveMQMsgTest_QueueReceiverJMSException() {
		
		try {
			
			Mockito.when(mQBeanHelper.getConfig()).thenReturn(orderStatusUpdateLoadConfiguration);
			Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig()).thenReturn(orderStatusUpdateConfig);
			
			Mockito.when(mQBeanHelper.getQueueConnection()).thenReturn(queueConnection);
			Mockito.doNothing().when(queueConnection).start();
			Mockito.when(queueConnection.createQueueSession(Mockito.anyBoolean(), Mockito.anyInt()))
				.thenReturn(queueSession);
			Mockito.when(mQBeanHelper.getMQQueue()).thenReturn(mqQueue);
			Mockito.when(queueSession.createReceiver(Mockito.any(MQQueue.class)))
				.thenThrow(new JMSException("DUMMY JMSException"));
			
			//message.setText("Dumy_Message");
			
			//cannot test while(true) so have to return null Message instance
			//Mockito.when(queueReceiver.receive(Mockito.anyLong())).thenReturn(null);
			Mockito.doNothing().when(queueConnection).close();
			
			mqMsgReceiver.receiveMQMsg();
			
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage()!=null);
		}
	}
	
	
	
	@Test
	public void receiveMQMsgTest_receiveMessageJMSException() {
		
		try {
			
			Mockito.when(mQBeanHelper.getConfig()).thenReturn(orderStatusUpdateLoadConfiguration);
			Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig()).thenReturn(orderStatusUpdateConfig);
			
			Mockito.when(mQBeanHelper.getQueueConnection()).thenReturn(queueConnection);
			Mockito.doNothing().when(queueConnection).start();
			Mockito.when(queueConnection.createQueueSession(Mockito.anyBoolean(), Mockito.anyInt()))
				.thenReturn(queueSession);
			Mockito.when(mQBeanHelper.getMQQueue()).thenReturn(mqQueue);
			Mockito.when(queueSession.createReceiver(Mockito.any(MQQueue.class)))
				.thenReturn(queueReceiver);
			
			//message.setText("Dumy_Message");
			
			//cannot test while(true) so have to return null Message instance
			Mockito.when(queueReceiver.receive(Mockito.anyLong())).thenThrow(new JMSException("Dummy JSMException"));
			Mockito.doNothing().when(queueConnection).close();
			
			mqMsgReceiver.receiveMQMsg();
			
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void receiveMQMsgTest_queueConnectionCloseException() {
		
		try {
			
			Mockito.when(mQBeanHelper.getConfig()).thenReturn(orderStatusUpdateLoadConfiguration);
			Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig()).thenReturn(orderStatusUpdateConfig);
			
			Mockito.when(mQBeanHelper.getQueueConnection()).thenReturn(queueConnection);
			Mockito.doNothing().when(queueConnection).start();
			Mockito.when(queueConnection.createQueueSession(Mockito.anyBoolean(), Mockito.anyInt()))
				.thenReturn(queueSession);
			Mockito.when(mQBeanHelper.getMQQueue()).thenReturn(mqQueue);
			Mockito.when(queueSession.createReceiver(Mockito.any(MQQueue.class)))
				.thenReturn(queueReceiver);
			
			//message.setText("Dumy_Message");
			
			//cannot test while(true) so have to return null Message instance
			Mockito.when(queueReceiver.receive(Mockito.anyLong())).thenThrow(new JMSException("Dummy JSMException"));
			Mockito.doThrow(new JMSException("Error while closing JMS Connection")).when(queueConnection).close();
			
			mqMsgReceiver.receiveMQMsg();
			
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage()!=null);
		}
	}
	
	
	private static void createMockMQConfig() {
		mqConfig.setMQHOST("DUMMY_HOST");
		mqConfig.setMQPORT(100);
		mqConfig.setMQAPPUSER("DUMMY_USER");
		mqConfig.setMQAPPPWD("DUMMY_PASSWORD");
		mqConfig.setMQCHANNEL("DUMMY_CHANNEL");
		mqConfig.setMQQMGR("DUMMY_QUEUE_MGR");
		mqConfig.setMQRECVQNAME("DUMMY_QUEUE_RECVQNAME");
		mqConfig.setWaitSecond("10");
		
		orderStatusUpdateConfig.setMqConfig(mqConfig);
	}
}
