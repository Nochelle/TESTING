package com.levi.mp.order.backend.orderxmls;

import java.util.ArrayList;

public class OrdersToFulfill {
	public Header h;
	public ArrayList<Detail> d;

	@Override
	public String toString(){
		if(h==null)
			return null;
		String result="Header"+String.format("%n");
		result="Client ID"+h.ClientId+String.format("%n");
		result=result+"Client Order Number"+h.LSCoDistributionOrderNum+String.format("%n");
		result=result+"Warehouse ID"+h.WarehouseId+String.format("%n");
		result=result+"Entry Date"+h.OrderEntryDate+String.format("%n");
		result=result+"Client Order Number US "+h.ClientOrderNum+String.format("%n");
		result=result+"\nDetails:\n";
		for(Detail d:d){
			result=result+d.toString();
		}
		return result;


	}
}





