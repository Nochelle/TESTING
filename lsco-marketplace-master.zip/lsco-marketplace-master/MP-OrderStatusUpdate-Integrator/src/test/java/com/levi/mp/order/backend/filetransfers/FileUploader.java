package com.levi.mp.order.backend.filetransfers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.SAXException;

import lombok.extern.log4j.Log4j2;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.levi.mp.order.backend.processor.BackendStarter;
import com.levi.mp.order.util.CommonUtilities;
@Log4j2
public class FileUploader {

static boolean flagForUploaded=false;

public FileUploader() {


}
public static void SFTP_UploadOTF(String SFTPHOST,int SFTPPORT ,String SFTPUSER, String SFTPPASS, String SFTPWORKINGDIR,
String FilePath,String FileName , File ShippmentFile,String orderNum) throws InterruptedException {
				
				JSch jsch = new JSch();
				Session session = null;
				Channel channel = null;
				ChannelSftp channelSftp = null;
				
				try {                                        
				session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
				session.setPassword(SFTPPASS);
				java.util.Properties config = new java.util.Properties();
				config.put("StrictHostKeyChecking", "no");
				session.setConfig(config);
				session.connect();
				channel = session.openChannel("sftp");
				channel.connect();
				channelSftp = (ChannelSftp) channel;
Thread.sleep(2000);
				channelSftp.cd("/Outbound/REG-100");//changed


				System.out.println(SFTPWORKINGDIR);
				File f = ShippmentFile;

		try {

				String filename= "ORDSHP"+ShippmentFile.getPath().split("ORDSHP")[1];
				
				if(flagForUploaded==false)
				channelSftp.put(new FileInputStream(f), f.getName());
				
				Date now = new Date();
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyymmddhhmmssSSS");
				String time = dateFormat.format(now); 
				log.info(filename+" file name before rename");
				String newfile=null;
					if(filename.contains("/"))
					{
					int begIndex=filename.indexOf("ORDSHP");
					int lastIndex=filename.length();
					newfile=filename.substring(begIndex, lastIndex);
					channelSftp.rename(newfile, "ORDSHP"+time+".xml");
					
					}
					else{
					// channelSftp.rename(filename, "ORDSHP"+time+".xml");
					filename=filename.replaceAll(filename, filename);
					log.info(filename+"  file name after rename");
					//Thread.sleep(15000);
			}
					
					
					if(flagForUploaded==true)
					{
					Vector filelist = channelSftp.ls(SFTPWORKINGDIR);
					
					ChannelSftp sftpChannel = (ChannelSftp) channel;
					flagForUploaded=false;
					Thread.sleep(8000);
					for (int i = 0; i < filelist.size(); i++) {
					LsEntry entry = (LsEntry) filelist.get(i);
					System.err.println("File present in Outbound Folder"+entry.toString());
					
					if (entry.toString().contains("ORD")) {
									flagForUploaded=true;
									
					System.err.println(orderNum);
					System.err.println(" Shipment file still in Outbound folder, waiting for the processing");
					break;
					} 
					}
					while (flagForUploaded==true) {
					
					
					SFTP_UploadOTF(SFTPHOST, SFTPPORT , SFTPUSER,  SFTPPASS,  SFTPWORKINGDIR,
									FilePath, FileName ,  ShippmentFile, orderNum);
					
					
					}
					}

				
				/*REASON FOR RENAME
				
				 Whenever the ORDSHP file is uploaded to SFTP server, the server is not recognizing the uploded file as an XML file. A simple RENAME is 
				 required to make SFTP server to recognize XML file as XML Document 

				 */
				
				} catch (FileNotFoundException e) {
								e.printStackTrace();
				}
				
			
				
												
				
				}  catch (JSchException e) {
				e.printStackTrace();
				
				
				
				} catch (SftpException e) {
				e.printStackTrace();


}

				finally{
					
					channelSftp.exit();
					session.disconnect();
				}
				
}

}
