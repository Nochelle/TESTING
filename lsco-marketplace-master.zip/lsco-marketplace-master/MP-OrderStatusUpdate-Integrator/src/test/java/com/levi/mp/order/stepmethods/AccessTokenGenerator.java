package com.levi.mp.order.stepmethods;

import java.io.IOException;
import java.io.InputStreamReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;



public class AccessTokenGenerator {

	
	Response response;
	RequestSpecification request; 
	String orderId;
	String orderidres;
	
	public String createNewAccessToken(String CONFIG_FILE, String RefreshTokenJSON) throws IOException, ParseException{
        JSONObject jconfigobj= getJSONAttributeVal(CONFIG_FILE);
        String BaseURL = (String) jconfigobj.get("BaseURL");
        String AppID = (String) jconfigobj.get("Application_ID");
        String Shared_Secret = (String) jconfigobj.get("Shared_Secret");
        jconfigobj= getJSONAttributeVal(RefreshTokenJSON);
        String Grant_Type = (String) jconfigobj.get("grant_type");
        String Refresh_token = (String) jconfigobj.get("Refresh_token");
        
        String SERVICE_ENDPOINT=BaseURL+"/oauth2/token";
        
         request = RestAssured.given();
         request = request.auth().preemptive().basic(AppID,Shared_Secret);
   
         response=request.config(RestAssured.config()
        			     .encoderConfig(EncoderConfig.encoderConfig()
        			     .encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC)))
        			     .contentType("x-www-form-urlencoded; charset=UTF-8")
        			     .formParam("grant_type", Grant_Type)
        			     .formParam("Refresh_token", Refresh_token)
        			     .when().post(SERVICE_ENDPOINT)
        			     .then().extract().response();
        
         String access_token= response.jsonPath().getString("access_token");
         return access_token;
    }
	
	public JSONObject getJSONAttributeVal(String filename) throws IOException, ParseException{
		Object configobj = new JSONParser().parse(new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream(filename)));
	    JSONObject jconfigobj = (JSONObject) configobj; 
		return jconfigobj;
	}
	
}
