package com.levi.mp.order.backend.orderxmls;

import java.util.ArrayList;

public class ShipmentInfo {
	/*
	 * <WarehouseId>385</WarehouseId>
<ClientId>100080</ClientId>
<ClientOrderNum>20692050</ClientOrderNum>
<DCOrderNum>F100067656001</DCOrderNum>
	 *
	 */
	public String WarehouseId;
	public String ClientId;
	public String OriginalLSCoDistributionOrderNum;
	public String DCOrderNum;
	public String ClientOrderNum;
	public String OriginalClientOrderNum;
	public String SmartLabelNum;
	public ArrayList<ShippingDetail> d;

	/*@Override
	public String toString(){
		if(h==null)
			return null;
		String result="Header"+String.format("%n");
		result="Client ID"+h.ClientId+String.format("%n");
		result=result+"Client Order Number"+h.ClientOrderNum+String.format("%n");
		result=result+"Warehouse ID"+h.WarehouseId+String.format("%n");
		result=result+"Entry Date"+h.OrderEntryDate+String.format("%n");
		result=result+"\nDetails:\n";
		for(Detail d:d){
			result=result+d.toString();
		}
		return result;


	}*/
}





