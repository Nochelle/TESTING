package com.levi.mp.order.function;

import java.io.IOException;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.web.client.RestTemplate;

import com.levi.mp.config.OrderStatusUpdateLoadConfiguration;
import com.levi.mp.order.service.OrderStatusService;

/**
 * A simple test harness for locally invoking your Lambda function handler.
 */

//@RunWith(SpringRunner.class)
//@SpringBootTest(classes = OrderStatusUpdateTestConfig.class)
public class OrderStatusUpdateHandlerTest {
	
	@MockBean
	OrderStatusUpdateLoadConfiguration orderStatusUpdateLoadConfiguration;
	
	@MockBean
	RestTemplate restTemplate;
	
	@Autowired
	OrderStatusUpdateHandler handler;
	
	@MockBean
	OrderStatusService orderStatusService;
	
	@MockBean
	ApplicationContext applicationContext;

    private static Object input;

    @BeforeClass
    public static void createInput() throws IOException {
        // TODO: set up your sample input object here.
        input = "ReprocessStatusUpdate";
    }

    /*private Context createContext() {
        TestContext ctx = new TestContext();

        // TODO: customize your context here if needed.
        ctx.setFunctionName("MP-OrderImport-Ingegrator");

        return null;
    }*/
    
  //@Test
  	/*public void testOrderImportHandler() {
  		OrderStatusUpdateHandler handler = new OrderStatusUpdateHandler();
  		 Context ctx = createContext();
  		 String output = handler.handleRequest(input, ctx);

  		// TODO: validate output here if needed.
  		 Assert.assertNotNull(output);
  	}*/

   // @Test
    public void testOrderImportHandler() {
    	System.out.println("testOrderImportHandler>>>>>>");
        try {
        	
			Mockito.when(applicationContext.getBean(OrderStatusService.class)).thenReturn(orderStatusService);
        
			Mockito.doNothing().when(orderStatusService).updateOrderStatus();
			
			String output = handler.handleRequest(input, null);
			Assert.assertEquals("OrderStatusUpdateHandler successfully executed", output);
        }catch (Exception e) {
        	Assert.assertFalse(e.getMessage()!=null);
		}
    }
}
