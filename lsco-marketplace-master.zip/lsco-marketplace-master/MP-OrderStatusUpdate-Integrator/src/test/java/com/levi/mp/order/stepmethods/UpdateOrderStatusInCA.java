package com.levi.mp.order.stepmethods;

import java.io.IOException;

import lombok.extern.log4j.Log4j2;

import org.json.simple.parser.ParseException;

import com.levi.mp.order.function.OrderStatusUpdateAutomationHandler;

@Log4j2
public class UpdateOrderStatusInCA {
	
	public void updateOrderStatusInCA() throws IOException, ParseException {	
		log.info("trigger lambda function>>");	
		OrderStatusUpdateAutomationHandler orderStatusUpdateAutomationHandler= new OrderStatusUpdateAutomationHandler();
		orderStatusUpdateAutomationHandler.handleRequest();
		//OrderStatusUpdateHandler orderStatusUpdateHandler= new OrderStatusUpdateHandler();
		//orderStatusUpdateHandler.handleRequest(null, null);
		log.info("lambda function triggered>>");	
		}
	
}
