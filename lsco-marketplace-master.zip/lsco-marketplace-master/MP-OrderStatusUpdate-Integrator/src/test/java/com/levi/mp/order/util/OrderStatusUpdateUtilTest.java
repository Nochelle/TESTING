package com.levi.mp.order.util;

import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.order.model.json.Adjustment;
import com.levi.mp.order.model.json.CustomerOrderDetail;
import com.levi.mp.order.model.json.OrderStatusUpdateProcessInfo;
import com.levi.mp.order.model.json.OrderUpdateInfo;
import com.levi.mp.order.model.json.Shipment;
import com.levi.mp.order.model.xml.TXML;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines;
import com.levi.mp.order.service.OrderStatusServiceTest;


public class OrderStatusUpdateUtilTest {
	
	static OrderLines orderLines; 
	TXML txml;
	static Map<String, String> itemIDToExtLineIDMap = new HashMap<>();
	
	@BeforeClass
	public static void setUp() {

		initializeMockItemIDToExtLineIDMap();
	}
	
	
	@Test
	//@Ignore //Ignoring as of of now, since we are not using it at the moment.
	public void readFileTest_Success() {
		
		String filePath = getAbsoluteFileName("Ship_Order_Status.xml");
		if(filePath.startsWith("file:/")) {
			filePath = filePath.substring(5);//Windows and MAC issue. For MAC need a / at beginning
		}
		String fileContent = OrderStatusUpdateUtil.readFile(filePath);
		//System.out.println(fileContent);
		Assert.assertNotNull(fileContent);
		Assert.assertNotEquals("", fileContent);
	}
	
	@Test
	public void convertDateToDateTimeTest() {
		String inputDateString = "10/25/2018";
		SimpleDateFormat inputDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			String dateTime = OrderStatusUpdateUtil.convertDateToDateTime(inputDateString, inputDateFormat);
		} catch (ParseException e) {
			Assert.assertFalse(e.getMessage() !=null);
		}
	}
	
	@Test
	public void getCancellationsTest() {
		
		try {
			if(txml == null) {
				txml = createTXMLObject("Cancel_FB_2.xml");
			}
			
			OrderUpdateInfo orderUpdateInfo = new OrderUpdateInfo();
			orderUpdateInfo.setCaOrderID("102938");
			orderUpdateInfo.setMarketPlaceOrderID("FB_42365416454543");
			orderUpdateInfo.setMarketPlaceorderType(IConstants.ORDER_TYPE_FB);

			OrderStatusUpdateUtil orderStatusUpdateUtil = new OrderStatusUpdateUtil();
			
			List<Adjustment> adjustmentList = orderStatusUpdateUtil
					.getCancellations(orderUpdateInfo, txml.getMessage().getOrder().getOrderLines());
			
			Assert.assertNotNull(adjustmentList);
			Assert.assertNotEquals(0, adjustmentList.size());
			
		} catch (JAXBException e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
		
	}
	
	@Test
	public void getShipmentsTest() {
		try {
			if(txml == null) {
				txml = createTXMLObject("Ship_Order_Status.xml");
			}

			OrderStatusUpdateUtil orderStatusUpdateUtil = new OrderStatusUpdateUtil();
			

			OrderUpdateInfo orderUpdateInfo = new OrderUpdateInfo();
			orderUpdateInfo.setCaOrderID("103732");
			orderUpdateInfo.setMarketPlaceOrderID("G-SHP-1157-33-1111");
			orderUpdateInfo.setMarketPlaceorderType(IConstants.ORDER_TYPE_GOOGLE);
			
			List<Shipment> shipmentList = orderStatusUpdateUtil
					.getShipments(orderUpdateInfo, txml.getMessage().getOrder().getShipmentDetails().getShipmentDetail());
			
			Assert.assertNotNull(shipmentList);
			Assert.assertNotEquals(0, shipmentList.size());
			
		} catch (JAXBException e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	@Test
	public void getExtOrderLineIdFromCustomerDetail() {
		
		try {
			CustomerOrderDetail customerOrderDetail = new ObjectMapper()
					.readValue(getFileContent("EOM_Customer_OrderDetails_GL.json"), CustomerOrderDetail.class);
			
			Map<String, String> pc13ToExtLineIdMap = new OrderStatusUpdateUtil()
					.getExtOrderLineIdFromCustomerDetail(customerOrderDetail);
			
			Assert.assertNotNull(pc13ToExtLineIdMap);
			Assert.assertEquals(4, pc13ToExtLineIdMap.size()); // each order lines + ShippingAdjustment + ShippingTaxAdjustment
			
		}catch(Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void getReturnsTest() {
		try {
			com.levi.mp.order.retn.model.xml.TXML  returnTxml = createReturnTXMLObject();
			
			OrderStatusUpdateUtil orderStatusUpdateUtil = new OrderStatusUpdateUtil();
			
			OrderUpdateInfo orderUpdateInfo = new OrderUpdateInfo();
			orderUpdateInfo.setCaOrderID("108486");
			orderUpdateInfo.setMarketPlaceOrderID("G-SHP-1219-94-1313");
			orderUpdateInfo.setMarketPlaceorderType(IConstants.ORDER_TYPE_GOOGLE);
			orderUpdateInfo.setReturnOrderNo("000511419");
			
			List<Adjustment> responseList = orderStatusUpdateUtil.getReturns(
											orderUpdateInfo,
											returnTxml.getMessage().getReturnOrder().getReturnOrderLines()
											,itemIDToExtLineIDMap);
			Assert.assertNotNull(responseList);
			Assert.assertEquals(1, responseList.size());
			Assert.assertNotNull(responseList.get(0));
			//Assert.assertNotNull(responseMap.get("3795"));
			Assert.assertEquals(1, responseList.get(0).getQuantity().intValue());
			//Assert.assertEquals(2, responseMap.get("3795").getQuantity().intValue());
			
			
		}catch(JAXBException jaxbe) {
			Assert.assertFalse(jaxbe.getMessage()!=null);
		}
	}
	

	private TXML createTXMLObject(String xmlFileName) throws JAXBException {
		
		String filePath = getAbsoluteFileName(xmlFileName);
		if(filePath.startsWith("file:/")) {
			filePath = filePath.substring(5);//Windows and MAC filepath hack. For MAC need a / at beginning, so use substring(5)
		}
		String xmlString = OrderStatusUpdateUtil.readFile(filePath);		
		
		JAXBContext context = JAXBContext.newInstance(TXML.class);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		
		return txml = (TXML) unmarshaller.unmarshal(new StringReader(xmlString));
	}
	
	private com.levi.mp.order.retn.model.xml.TXML createReturnTXMLObject() throws JAXBException {
		
		String content = getFileContent("ReturnOrder_Message_GL.xml");
		
		JAXBContext jaxbContext = JAXBContext.newInstance(com.levi.mp.order.retn.model.xml.TXML.class);

		return (com.levi.mp.order.retn.model.xml.TXML) jaxbContext.createUnmarshaller()
				.unmarshal(new StringReader(content));
	}
	
	
	private static String getAbsoluteFileName(String fileName) {
		
		String os = System.getProperty("os.name");
		String filePath = OrderStatusUpdateUtil.class.getClassLoader().getResource(fileName).toString();
		if (filePath.startsWith("file:/")) {
			
			// Windows and MAC issue. For MAC need a / at beginning
			if(!StringUtils.isEmpty(os)) {
				if(os.indexOf("win")>=0 || os.indexOf("Win")>=0) {
					filePath = filePath.substring(6);
				}else if(os.indexOf("mac")>=0 || os.indexOf("Mac")>=0) {
					filePath = filePath.substring(5);
				}else {
					//Not handling at the moment
				}
			}
			
		}
		
		return filePath;
	}
	
	
	public static String getFileContent(String fileName) {
		
		String os = System.getProperty("os.name");
		String filePath = OrderStatusServiceTest.class.getClassLoader().getResource(fileName).toString();
		if (filePath.startsWith("file:/")) {
			
			// Windows and MAC issue. For MAC need a / at beginning
			if(!StringUtils.isEmpty(os)) {
				if(os.indexOf("win")>=0 || os.indexOf("Win")>=0) {
					filePath = filePath.substring(6);
				}else if(os.indexOf("mac")>=0 || os.indexOf("Mac")>=0) {
					filePath = filePath.substring(5);
				}else {
					//Not handling at the moment
				}
			}
			
		}
		return OrderStatusUpdateUtil.readFile(filePath);
	}
	
	private static void initializeMockItemIDToExtLineIDMap() {
		
		itemIDToExtLineIDMap.put("00501011502832", "3794");
		itemIDToExtLineIDMap.put("00501000003434", "3795");
		itemIDToExtLineIDMap.put(IConstants.SHIPPING_ADJUSTMENT, "6.25");
		itemIDToExtLineIDMap.put(IConstants.SHIPPING_TAX_ADJUSTMENT, "0.00");
	}
	
}	
