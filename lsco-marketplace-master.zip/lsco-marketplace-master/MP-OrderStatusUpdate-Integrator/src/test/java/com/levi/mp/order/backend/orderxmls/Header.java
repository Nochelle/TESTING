package com.levi.mp.order.backend.orderxmls;

public class Header {// Taking only information required to generate Shipment file from
	// Header Node
public String WarehouseId;
public String ClientId;
public String LSCoDistributionOrderNum;
public String OrderType;
public String OrderEntryDate;
public String OrderNumber;
public String MessageStatus = "SC";
public String ShippingCarrierGroup;
public String ClientOrderNum;
}
