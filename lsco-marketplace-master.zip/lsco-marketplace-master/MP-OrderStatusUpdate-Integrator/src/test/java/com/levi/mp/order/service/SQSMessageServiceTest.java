package com.levi.mp.order.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.DeleteMessageResult;
import com.amazonaws.services.sqs.model.GetQueueUrlResult;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageResult;
import com.levi.mp.OrderStatusUpdateTestConfig;
import com.levi.mp.config.OrderStatusUpdateLoadConfiguration;
import com.levi.mp.order.model.json.OrderStatusUpdateConfig;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= OrderStatusUpdateTestConfig.class)
public class SQSMessageServiceTest {
	
	@MockBean
	OrderStatusUpdateLoadConfiguration orderStatusUpdateLoadConfiguration;
	
	@MockBean
	AmazonSQS sqs;
	
	@MockBean
	GetQueueUrlResult getQueueUrlResult;
	
	@MockBean
	SendMessageResult sendMessageResult;
	
	@MockBean
	ReceiveMessageResult receiveMessageResult;
	
	@MockBean
	DeleteMessageResult deleteMessageResult;
	
	@Autowired
	SQSMessageService sqsMessageService;
	
	private static final OrderStatusUpdateConfig orderStatusUpdateConfig = new OrderStatusUpdateConfig();
	private static final String sqsQueueName = "DUMMY_SQS_QUEUE_NAME";
	private static final String message = "DUMMY_MESSAGE";
	
	private static final List<Message> messageList = new ArrayList<>();
	
	@BeforeClass
	public static void setUp() {
		createConfig();
		createMockMessageList();
	}

	@Test
	public void sendMessageTest() {
		Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig())
				.thenReturn(orderStatusUpdateConfig);
		Mockito.when(sqs.getQueueUrl(Mockito.anyString())).thenReturn(getQueueUrlResult);
		Mockito.when(getQueueUrlResult.getQueueUrl()).thenReturn(sqsQueueName);
		Mockito.when(sqs.sendMessage(Mockito.any(SendMessageRequest.class))).thenReturn(sendMessageResult);

		sqsMessageService.sendMessages(message);

		Mockito.verify(sqs, Mockito.times(1)).sendMessage(Mockito.any(SendMessageRequest.class));

	}
	
	
	@Test
	public void getMessagesTest() {
		Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig())
				.thenReturn(orderStatusUpdateConfig);
		Mockito.when(sqs.receiveMessage(Mockito.any(ReceiveMessageRequest.class))).thenReturn(receiveMessageResult);
		Mockito.when(receiveMessageResult.getMessages()).thenReturn(new ArrayList<Message>());

		Map<String, String> sqsMsgMap = sqsMessageService.getMessages();

		Assert.assertNotNull(sqsMsgMap);
		Assert.assertEquals(0, sqsMsgMap.size());

	}
	
	
	@Test
	public void deleteMessageTest() {
		Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig())
				.thenReturn(orderStatusUpdateConfig);
		Mockito.when(sqs.getQueueUrl(Mockito.anyString())).thenReturn(getQueueUrlResult);
		Mockito.when(getQueueUrlResult.getQueueUrl()).thenReturn(sqsQueueName);

		Mockito.when(sqs.deleteMessage(Mockito.anyString(), Mockito.anyString())).thenReturn(deleteMessageResult);

		boolean deleteMessageStatus = sqsMessageService.deleteMessage("DUMMY_RECIPIENT_HANDLE");
		Assert.assertTrue(deleteMessageStatus);

	}
	
	
	private static void createConfig() {
		orderStatusUpdateConfig.setSqsQueueName(sqsQueueName);
		orderStatusUpdateConfig.setSqsMsgDelaySec("30");
		
	}
	
	private static void createMockMessageList() {
		
		Message message = new Message();
		message.setReceiptHandle("DUMMY_RECIPIENT_HANDLE");
		message.setBody("DUMMY_BODY");
		
		messageList.add(message);
		
	}
}
