package com.levi.mp.order.backend.processor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;


import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.levi.mp.order.backend.orderxmls.Detail;
import com.levi.mp.order.backend.orderxmls.Header;
import com.levi.mp.order.backend.orderxmls.OrdersToFulfill;


public class OTFHandler extends DefaultHandler  {
	SAXParserFactory factory;
	OrdersToFulfill order = null;
	Header header = null;
	Detail d = null;
	ArrayList<Detail> detlist = null;
	String text="";
	List<OrdersToFulfill> orderlist;

	public OTFHandler(){

	}

	public void processFile(File filename,List<OrdersToFulfill> orderlist)
	{
		this.orderlist=orderlist;
		factory= SAXParserFactory.newInstance();
		try {
			SAXParser parser=factory.newSAXParser();
			parser.parse(filename, this);
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//System.out.println(e);
		}
	}


	@Override
	public void startElement(String uri, String localname, String qname,
			Attributes attributes) throws SAXException {
		switch (qname) {
		case "OrdersToFulfill":
			order = new OrdersToFulfill();
			detlist = new ArrayList<Detail>();
			break;

		case "Header":
			header = new Header();
			break;

		case "Detail":
			d = new Detail();
			break;

		}
	}

	@Override
	public void endElement(String uri, String localname, String qname) throws SAXException {
		switch (qname) {
		case "OrdersToFulfill":
			order.h=header;
			order.d=detlist;
			orderlist.add(order);

			break;
		case "AltOrderNum1":
			header.OrderNumber=text;
			break;

		case "WarehouseId":
			header.WarehouseId=text;
			break;

		case "ClientId":
			header.ClientId=text;
			break;

		case "LSCoDistributionOrderNum":
			header.LSCoDistributionOrderNum=text;
			break;

		case "OrderEntryDate":
			header.OrderEntryDate=text;
			break;

		case "OrderType":
			header.OrderType=text;
			break;

		case "Detail":
			detlist.add(d);
			break;

		case "OrderLineSeq":
			d.OrderLineSeq=text;
			break;

		case "LSCoPartNum":
			d.LSCoPartNum=text;
			break;

		case "QuantityOrdered":
			d.QuantityOrdered=Integer.parseInt(text);
			break;

		case "ShippingCarrierGroup":
			header.ShippingCarrierGroup=text;
			break;

		case "ClientOrderNum":
			header.ClientOrderNum=text;
			break;

		case "ClientPartNum":
			d.ClientPartNum=text;
			break;

		}
	}
	@Override
	public void characters(char ch[],int start,int length){
		text=new String(ch,start,length);
	}

}
