package com.levi.mp.order.backend.orderxmls;

public class Detail {

	// Taking only information required to generate Shipment file from Details
	// Node
	public String OrderLineSeq;
	public String LSCoPartNum;
	public int QuantityOrdered;
	public int QuantityCancelled;
	public String InventoryStatusShp = "AVL";
	public String InventoryStatusCan = "";
	public String CancelReasonCode = "";
	public String ShippingCarrierGroup;
	public String ClientPartNum;
	@Override
	public String toString(){
		return "OrderLineSequence: "+OrderLineSeq+"\nLSCoPartNum: "+LSCoPartNum+"\nQuantityOrdered: "
				+QuantityOrdered+"\nQuantityCancelled: "+QuantityCancelled +"\nInventoryStatusShp: "+InventoryStatusShp+"\nInventoryStatusCan: "
				+InventoryStatusCan+"\nCancelReasonCode: "+CancelReasonCode+"\nShippingCarrierGroup" + ShippingCarrierGroup +"\nClientPartNum: " + ClientPartNum +"\n ";
	}
}

