package com.levi.mp.order.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.amazonaws.services.sqs.model.Message;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.OrderStatusUpdateTestConfig;
import com.levi.mp.config.OrderStatusUpdateLoadConfiguration;
import com.levi.mp.order.model.json.Adjustment;
import com.levi.mp.order.model.json.CustomerOrderDetail;
import com.levi.mp.order.model.json.OrderStatusUpdateConfig;
import com.levi.mp.order.model.json.OrderStatusUpdateProcessInfo;
import com.levi.mp.order.model.json.OrderUpdateInfo;
import com.levi.mp.order.rest.client.OrderStatusRestClientAdapter;
import com.levi.mp.order.util.IConstants;
import com.levi.mp.order.util.MQMsgReceiver;
import com.levi.mp.order.util.OrderStatusUpdateUtil;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;
import com.levi.mp.shared.ca.util.MPSharedUtil;
import com.levi.mp.shared.sns.SNSService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = OrderStatusUpdateTestConfig.class)
public class OrderStatusServiceTest {	

	@MockBean
	//@Autowired
	OrderStatusUpdateLoadConfiguration orderStatusUpdateLoadConfiguration;

	@MockBean
	//@Autowired
	ChannelAdvisorTokenService channelAdvisorTokenService;

	@MockBean
	//@Autowired
	MPSharedUtil mpSharedUtil;

	//@MockBean
	@Autowired
	OrderStatusUpdateUtil orderStatusUpdateUtil;

	@MockBean
	//@Autowired
	OrderStatusRestClientAdapter orderStatusRestClientAdapter;

	@MockBean
	MQMsgReceiver mQMsgReceiver;
	
	@MockBean
	SQSMessageService sqsMessageService;
	
	@Autowired
	OrderStatusService orderStatusService;
	
	@MockBean
	SNSService snsService;
	
	private final static String caAccessToken = "DUMMY_ACCESS_TOKEN";
	private static final String sqsQueueName = "DUMMY_SQS_QUEUE_NAME";
	private static final OrderStatusUpdateConfig orderStatusUpdateConfig = new OrderStatusUpdateConfig();
	private static final Map<String, String> messageMap = new HashMap<>();
	private static final Map<String, String> tokenMap = new HashMap<>();
	
	@BeforeClass
	public static void setUp() {
		createConfig();
		createMockMessageMap();
		createMockTokenMap();
	}

	/*// @Test
	public void postAdjustmentsToCA() {
		Map<String, Adjustment> adjustmentMap = new HashMap<>();
		try {
			orderStatusService.postAdjustmentsToCA(adjustmentMap, "caAccessToken");
			assertTrue("Updated Cancel Status successfull", true);
		} catch (Exception e) {
			assertTrue(e.getMessage(), !e.getMessage().isEmpty());
		}
	}

	@Test
	public void updateOrderStatusTest() {
		try {
			List<String> msgList = new ArrayList<>();
			msgList.add(getStaticXMLContent());
			when(mQMsgReceiver.receiveMQMsg()).thenReturn(msgList);

			//when(mpSharedUtil.getConfigValues(Mockito.anyString())).thenReturn(configString);

			orderStatusService.updateOrderStatus();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	@Test
	public void updateRetrunOrderStatusTest_GL_Success() {
		
		orderStatusService.setOrderStatusUpdateProcessInfo(new OrderStatusUpdateProcessInfo());
		
		List<String> msgList = new ArrayList<>();
		msgList.add(getFileContent("ReturnOrder_Message_GL.xml"));

		Mockito.when(mQMsgReceiver.receiveMQMsg()).thenReturn(msgList);
		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(caAccessToken);
		Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig())
		.thenReturn(orderStatusUpdateConfig);

		try {
			
			Mockito.when(orderStatusRestClientAdapter.fetchCustomerOrderDetailsFromEOM(Mockito.anyString()))
			.thenReturn(getMockCustomerOrderDetailForGoogleOrder());
			
			Mockito.when(orderStatusRestClientAdapter
					.updateReturnOrderStatus(Mockito.any(OrderUpdateInfo.class),Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			orderStatusService.updateOrderStatus();

		} catch (Exception e) {
			Assert.assertFalse(e.getMessage() != null);
		}

	}
	
	
	@Test
	public void updateRetrunOrderStatusTest_FB_Success() {
		
		orderStatusService.setOrderStatusUpdateProcessInfo(new OrderStatusUpdateProcessInfo());
		
		List<String> msgList = new ArrayList<>();
		msgList.add(getFileContent("ReturnOrder_Message_FB.xml"));
		
		Mockito.when(mQMsgReceiver.receiveMQMsg()).thenReturn(msgList);
		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(caAccessToken);
		Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig())
				.thenReturn(orderStatusUpdateConfig);

		try {
			
			Mockito.when(orderStatusRestClientAdapter.fetchCustomerOrderDetailsFromEOM(Mockito.anyString()))
				.thenReturn(getMockCustomerOrderDetailForFacebookOrder());
			
			
			Mockito.when(orderStatusRestClientAdapter.updateFullReturnOrderStatus(
					getMockAdjustmentForFullReturn()
					,caAccessToken))
			.thenReturn(Boolean.TRUE);
			
			/*Mockito.when(
					orderStatusRestClientAdapter.updateFullOrderCancelStatus(Mockito.anyString(), Mockito.anyString()))
					.thenReturn(Boolean.TRUE);*/
			
			orderStatusService.updateOrderStatus();

		} catch (Exception e) {
			Assert.assertFalse(e.getMessage() != null);
		}

	}
	
	@Test
	public void updateOrderStatusTest_GL_Success() {
		
		orderStatusService.setOrderStatusUpdateProcessInfo(new OrderStatusUpdateProcessInfo());
		
		List<String> msgList = new ArrayList<>();
		msgList.add(getFileContent("Ship_Order_Status.xml"));

		Mockito.when(mQMsgReceiver.receiveMQMsg()).thenReturn(msgList);
		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(caAccessToken);

		try {
			Mockito.when(orderStatusRestClientAdapter
					.updateShipStatus(Mockito.any(OrderUpdateInfo.class),Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			Mockito.when(orderStatusRestClientAdapter
					.updatePartialOrderCancelStatus(Mockito.any(OrderUpdateInfo.class), Mockito.anyString()))
				.thenReturn(Boolean.TRUE);

			orderStatusService.updateOrderStatus();

		} catch (Exception e) {
			Assert.assertFalse(e.getMessage() != null);
		}

	}
	
	
	@Test
	public void updateOrderStatusTest_GL_NoShip_NoCancel() {
		
		orderStatusService.setOrderStatusUpdateProcessInfo(new OrderStatusUpdateProcessInfo());
		
		List<String> msgList = new ArrayList<>();
		msgList.add(getFileContent("NoCancel_NoShip_Order_Status.xml"));

		Mockito.when(mQMsgReceiver.receiveMQMsg()).thenReturn(msgList);
		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(caAccessToken);

		try {
			Mockito.when(orderStatusRestClientAdapter
					.updateShipStatus(Mockito.any(OrderUpdateInfo.class),Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			Mockito.when(orderStatusRestClientAdapter
					.updatePartialOrderCancelStatus(Mockito.any(OrderUpdateInfo.class), Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			Mockito.when(snsService.notifySupport(Mockito.anyString(), Mockito.anyString())).thenReturn(Boolean.TRUE);

			orderStatusService.updateOrderStatus();

		} catch (Exception e) {
			Assert.assertFalse(e.getMessage() != null);
		}

	}
	
	
	@Test
	public void updateOrderStatusTest_WrongXmls() {
		
		orderStatusService.setOrderStatusUpdateProcessInfo(new OrderStatusUpdateProcessInfo());
		
		List<String> msgList = new ArrayList<>();
		
		msgList.add(getFileContent("FB_No_Ship_Valid_Cancel.xml"));
		msgList.add(getFileContent("FB_NoShip_ValidCancel.xml"));
		
		msgList.add(getFileContent("FB_Ship_NoCancel.xml"));
		msgList.add(getFileContent("GL_No_Ship_Cancel.xml"));
		msgList.add(getFileContent("GL_NoShip_Already_Cancelled.xml"));
		msgList.add(getFileContent("GL_NoShip_NoCancel.xml"));
		msgList.add(getFileContent("GL_Ship_No_Cancel.xml"));
		

		Mockito.when(mQMsgReceiver.receiveMQMsg()).thenReturn(msgList);
		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(caAccessToken);

		try {
			
			//Google return order, as per ReturnOrder_Message_GL.xml and EOM_Customer_OrderDetails_GL.json
			Mockito.when(orderStatusRestClientAdapter.fetchCustomerOrderDetailsFromEOM("G-SHP-1219-94-1313"))
			.thenReturn(getMockCustomerOrderDetailForGoogleOrder());
			
			//Facebook return order, as per ReturnOrder_Message_FB.xml and EOM_Customer_OrderDetails_FB.json
			Mockito.when(orderStatusRestClientAdapter.fetchCustomerOrderDetailsFromEOM("11240015750101"))
			.thenReturn(getMockCustomerOrderDetailForFacebookOrder());
			
			//Facebook full return order update
			Mockito.when(orderStatusRestClientAdapter.updateFullReturnOrderStatus(
					Mockito.any(Adjustment.class)
					,Mockito.anyString()))
			.thenReturn(Boolean.TRUE);
			
			//Google return order
			Mockito.when(orderStatusRestClientAdapter
					.updateReturnOrderStatus(Mockito.any(OrderUpdateInfo.class),Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			Mockito.when(orderStatusRestClientAdapter
					.updateShipStatus(Mockito.any(OrderUpdateInfo.class),Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			Mockito.when(orderStatusRestClientAdapter.updateFullOrderCancelStatus(
					Mockito.any(OrderUpdateInfo.class),
					Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			Mockito.when(orderStatusRestClientAdapter
					.updatePartialOrderCancelStatus(Mockito.any(OrderUpdateInfo.class), Mockito.anyString()))
				.thenReturn(Boolean.TRUE);

			orderStatusService.updateOrderStatus();

		} catch (Exception e) {
			e.printStackTrace();
			Assert.assertFalse(e.getMessage() != null);
		}

	}
	
	
	@Test
	public void updateOrderStatusTest_Success() {
		
		orderStatusService.setOrderStatusUpdateProcessInfo(new OrderStatusUpdateProcessInfo());
		
		List<String> msgList = new ArrayList<>();
		
		msgList.add(getFileContent("ReturnOrder_Message_FB.xml"));
		msgList.add(getFileContent("ReturnOrder_Message_GL.xml"));
		
		msgList.add(getFileContent("Ship_Order_Status.xml"));
		msgList.add(getFileContent("Cancel_FB_1.xml"));
		msgList.add(getFileContent("Cancel_FB_2.xml"));
		msgList.add(getFileContent("Cancel_GL_All_Lines.xml"));
		

		Mockito.when(mQMsgReceiver.receiveMQMsg()).thenReturn(msgList);
		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(caAccessToken);

		try {
			
			//Google return order, as per ReturnOrder_Message_GL.xml and EOM_Customer_OrderDetails_GL.json
			Mockito.when(orderStatusRestClientAdapter.fetchCustomerOrderDetailsFromEOM("G-SHP-1219-94-1313"))
			.thenReturn(getMockCustomerOrderDetailForGoogleOrder());
			
			//Facebook return order, as per ReturnOrder_Message_FB.xml and EOM_Customer_OrderDetails_FB.json
			Mockito.when(orderStatusRestClientAdapter.fetchCustomerOrderDetailsFromEOM("11240015750101"))
			.thenReturn(getMockCustomerOrderDetailForFacebookOrder());
			
			//Facebook full return order update
			Mockito.when(orderStatusRestClientAdapter.updateFullReturnOrderStatus(
					Mockito.any(Adjustment.class)
					,Mockito.anyString()))
			.thenReturn(Boolean.TRUE);
			
			//Google return order
			Mockito.when(orderStatusRestClientAdapter
					.updateReturnOrderStatus(Mockito.any(OrderUpdateInfo.class),Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			Mockito.when(orderStatusRestClientAdapter
					.updateShipStatus(Mockito.any(OrderUpdateInfo.class),Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			Mockito.when(orderStatusRestClientAdapter.updateFullOrderCancelStatus(
					Mockito.any(OrderUpdateInfo.class), Mockito.anyString()))
				.thenReturn(Boolean.TRUE);
			
			Mockito.when(orderStatusRestClientAdapter
					.updatePartialOrderCancelStatus(Mockito.any(OrderUpdateInfo.class), Mockito.anyString()))
				.thenReturn(Boolean.TRUE);

			orderStatusService.updateOrderStatus();

		} catch (Exception e) {
			e.printStackTrace();
			Assert.assertFalse(e.getMessage() != null);
		}

	}
	
	
	@Test
	public void reprocessUpdateOrderStatusTest_Success() {
		
		orderStatusService.setOrderStatusUpdateProcessInfo(new OrderStatusUpdateProcessInfo());
		
		Mockito.when(channelAdvisorTokenService.getOAuth2Token()).thenReturn(caAccessToken);
		Mockito.when(sqsMessageService.getMessages()).thenReturn(messageMap);
		Mockito.when(orderStatusRestClientAdapter
				.updateShipStatus(Mockito.any(OrderUpdateInfo.class),Mockito.anyString()))
			.thenReturn(Boolean.TRUE);
		Mockito.when(orderStatusRestClientAdapter
				.updatePartialOrderCancelStatus(Mockito.any(OrderUpdateInfo.class), Mockito.anyString()))
			.thenReturn(Boolean.TRUE);
		Mockito.when(orderStatusRestClientAdapter.updateFullOrderCancelStatus(Mockito.any(OrderUpdateInfo.class)
				,Mockito.anyString()))
			.thenReturn(Boolean.TRUE);
		Mockito.when(sqsMessageService.deleteMessage(Mockito.anyString())).thenReturn(Boolean.TRUE);
		
		try {
			orderStatusService.reprocessUpdateOrderStatus();
		} catch (IOException e) {
			Assert.assertFalse(e.getMessage()!=null);
		}

	}
	
	
	private static void createConfig() {
		orderStatusUpdateConfig.setSqsQueueName(sqsQueueName);
		orderStatusUpdateConfig.setLeviEOMHost("Dummy Host");
		orderStatusUpdateConfig.setLeviEOMUserName("Dummy User");
		
	}
	
	private static void createMockMessageMap() {

		Message partialShipMessage = new Message();
		partialShipMessage.setReceiptHandle("PARTIAL_SHIP_UPDATE_RECIPIENT_HANDLE");
		partialShipMessage.setBody(getMockShipmentSQSMessage());

		messageMap.put(partialShipMessage.getReceiptHandle(), partialShipMessage.getBody());

		Message partialCancelMessage = new Message();
		partialCancelMessage.setReceiptHandle("PARTIAL_CANCEL_UPDATE_RECIPIENT_HANDLE");
		partialCancelMessage.setBody(getMockAdjustmentSQSMessage());

		messageMap.put(partialCancelMessage.getReceiptHandle(), partialCancelMessage.getBody());
		
		Message fullCancelMessage = new Message();
		fullCancelMessage.setReceiptHandle("FULL_CANCEL_UPDATE_RECIPIENT_HANDLE");
		fullCancelMessage.setBody(getMockAdjustmentSQSFullCancelMessage());
		
		messageMap.put(fullCancelMessage.getReceiptHandle(), fullCancelMessage.getBody());
		
		
		Message partialReturnUpdateMessage = new Message();
		partialReturnUpdateMessage.setReceiptHandle("PARTIAL_RETURN_UPDATE_RECIPIENT_HANDLE");
		partialReturnUpdateMessage.setBody(getMockAdjustmentSQSPartialReturnMessage());
		
		messageMap.put(partialReturnUpdateMessage.getReceiptHandle(), partialReturnUpdateMessage.getBody());
		
		
		Message fullReturnUpdateMessage = new Message();
		fullReturnUpdateMessage.setReceiptHandle("FULL_RETURN_UPDATE_RECIPIENT_HANDLE");
		fullReturnUpdateMessage.setBody(getMockAdjustmentSQSFullReturnMessage());
		
		messageMap.put(fullReturnUpdateMessage.getReceiptHandle(), fullReturnUpdateMessage.getBody());

	}
	
	/**
	 * Mock ShipmentSQS message as per {@code ShipmentSQS}
	 * 
	 * @return
	 */
	private static String getMockShipmentSQSMessage() {
		
		return  
				/*"{"
					+ "\"MessageType\":\"PARTIAL_SHIP_UPDATE\","
					+ "\"CAOrderID\":\"102913\","
					+ "\"Shipment\":{"
						+ "\"Value\":{"
							+ "\"ShippedDateUtc\":\"2018-10-25T13:38:47.1Z\","
							+ "\"TrackingNumber\":\"1Z867F6RP200183731\","
							+ "\"SellerFulfillmentID\":\"EELPN20181024183730841458\","
							+ "\"DistributionCenterID\":0,"
							+ "\"DeliveryStatus\":\"Complete\","
							+ "\"ShippingCarrier\":\"UPS\","
							+ "\"ShippingClass\":\"GROUND\","
							+ "\"Items\":["
								+ "{"
									+ "\"Sku\":\"04511092502830\","
									+ "\"Quantity\":1}"
								+ "]"
							+ ""
						+ "}"
					+ "}"
				+ "}";*/
				
				"{\r\n" + 
				"  \"caOrderID\": \"102913\",\r\n" + 
				"  \"caOrderLineID\": null,\r\n" + 
				"  \"marketPlaceOrderID\": \"G-SHP-1157-33-1111\",\r\n" + 
				"  \"marketPlaceorderType\": \"OT_GOOGLE\",\r\n" + 
				"  \"returnOrderNo\": null,\r\n" + 
				"  \"messageType\": \"PARTIAL_SHIP_UPDATE\",\r\n" + 
				"  \"value\": {\r\n" + 
				"    \"shippedDateUtc\": \"2018-12-08T12:58:47.1Z\",\r\n" + 
				"    \"trackingNumber\": \"1Z999AA10123456765\",\r\n" + 
				"    \"sellerFulfillmentID\": \"ship-kdjslj\",\r\n" + 
				"    \"distributionCenterID\": \"0\",\r\n" + 
				"    \"deliveryStatus\": \"Complete\",\r\n" + 
				"    \"shippingCarrier\": \"UPS\",\r\n" + 
				"    \"shippingClass\": \"Ground\",\r\n" + 
				"    \"items\": [\r\n" + 
				"      {\r\n" + 
				"        \"sku\": \"00501011502830\",\r\n" + 
				"        \"quantity\": 1\r\n" + 
				"      }\r\n" + 
				"    ]\r\n" + 
				"  }\r\n" + 
				"}";
				
	}
	
	
	/**
	 * Mock AdjustmentSQS message as per {@code AdjustmentSQS}
	 * 
	 * @return
	 */
	private static String getMockAdjustmentSQSMessage() {
		
		return  
				/*"{"
					+ "\"MessageType\":\"PARTIAL_CANCEL_UPDATE\","
					+ "\"CAOrderLineId\":\"2964\","
					+ "\"CAOrderID\":\"102913\","
					+ "\"Adjustment\":{"
						+ "\"Reason\":\"BuyerCancelled\","
						+ "\"SellerAdjustmentID\":\"AdjustmentID-2964\","
						+ "\"Quantity\":1"
					+ "}"
				+ "}";*/
				
				"{\r\n" + 
				"  \"caOrderID\": \"102913\",\r\n" + 
				"  \"caOrderLineID\": \"2964\",\r\n" + 
				"  \"marketPlaceOrderID\": \"G-SHP-1157-33-1111\",\r\n" + 
				"  \"marketPlaceorderType\": \"OT_GOOGLE\",\r\n" + 
				"  \"returnOrderNo\": \"000511419\",\r\n" + 
				"  \"messageType\": \"PARTIAL_CANCEL_UPDATE\",\r\n" + 
				"  \"reason\": \"BuyerCancelled\",\r\n" + 
				"  \"sellerAdjustmentID\": \"AdjustmentID-2964\",\r\n" + 
				"  \"quantity\": 1,\r\n" + 
				"  \"shippingAdjustment\": null,\r\n" + 
				"  \"shippingTaxAdjustment\": null,\r\n" + 
				"  \"forceCalculateOmittedAmounts\": null,\r\n" + 
				"  \"adjustmentAmount\": null\r\n" + 
				"}";
	}
	
	
	/**
	 * Mock AdjustmentSQS message as per {@code AdjustmentSQS}
	 * 
	 * @return
	 */
	private static String getMockAdjustmentSQSFullCancelMessage() {
		
		return  
				/*"{"
					+ "\"MessageType\":\"FULL_CANCEL_UPDATE\","
					+ "\"CAOrderLineId\":\"2964\","
					+ "\"CAOrderID\":\"102913\","
					+ "\"Adjustment\":{"
						+ "\"Reason\":\"BuyerCancelled\","
						+ "\"SellerAdjustmentID\":\"AdjustmentID-2964\","
						+ "\"Quantity\":1"
					+ "}"
				+ "}";*/
				
				"{\r\n" + 
				"  \"caOrderID\": \"102913\",\r\n" + 
				"  \"caOrderLineID\": \"2964\",\r\n" + 
				"  \"marketPlaceOrderID\": \"G-SHP-1157-33-1111\",\r\n" + 
				"  \"marketPlaceorderType\": \"OT_GOOGLE\",\r\n" + 
				"  \"returnOrderNo\": \"000511419\",\r\n" + 
				"  \"messageType\": \"FULL_CANCEL_UPDATE\",\r\n" + 
				"  \"reason\": \"BuyerCancelled\",\r\n" + 
				"  \"sellerAdjustmentID\": \"AdjustmentID-2964\",\r\n" + 
				"  \"quantity\": 1,\r\n" + 
				"  \"shippingAdjustment\": null,\r\n" + 
				"  \"shippingTaxAdjustment\": null,\r\n" + 
				"  \"forceCalculateOmittedAmounts\": null,\r\n" + 
				"  \"adjustmentAmount\": null\r\n" + 
				"}\r\n" + 
				"";
	}
	
	
	/**
	 * Mock AdjustmentSQS message as per {@code AdjustmentSQS}
	 * 
	 * @return
	 */
	private static String getMockAdjustmentSQSPartialReturnMessage() {
		
		return  
				/*"{"
					+ "\"MessageType\":\"PARTIAL_RETURN_UPDATE\","
					+ "\"CAOrderLineId\":\"2964\","
					+ "\"CAOrderID\":\"102913\","
					+ "\"Adjustment\":{"
						+ "\"Reason\":\"BuyerCancelled\","
						+ "\"SellerAdjustmentID\":\"AdjustmentID-2964\","
						+ "\"Quantity\":1"
					+ "}"
				+ "}";*/
				
				"{\r\n" + 
				"  \"caOrderID\": \"102913\",\r\n" + 
				"  \"caOrderLineID\": \"2964\",\r\n" + 
				"  \"marketPlaceOrderID\": \"G-SHP-1157-33-1111\",\r\n" + 
				"  \"marketPlaceorderType\": \"OT_GOOGLE\",\r\n" + 
				"  \"returnOrderNo\": \"000511419\",\r\n" + 
				"  \"messageType\": \"PARTIAL_RETURN_UPDATE\",\r\n" + 
				"  \"reason\": \"BuyerCancelled\",\r\n" + 
				"  \"sellerAdjustmentID\": \"AdjustmentID-2964\",\r\n" + 
				"  \"quantity\": 1,\r\n" + 
				"  \"shippingAdjustment\": null,\r\n" + 
				"  \"shippingTaxAdjustment\": null,\r\n" + 
				"  \"forceCalculateOmittedAmounts\": null,\r\n" + 
				"  \"adjustmentAmount\": null\r\n" + 
				"}";
	}
	
	
	/**
	 * Mock AdjustmentSQS message as per {@code AdjustmentSQS}
	 * 
	 * @return
	 */
	private static String getMockAdjustmentSQSFullReturnMessage() {
		
		return  
				/*"{"
					+ "\"MessageType\":\"FULL_RETURN_UPDATE\","
					+ "\"CAOrderLineId\":\"2964\","
					+ "\"CAOrderID\":\"102913\","
					+ "\"Adjustment\":{"
						+ "\"Reason\":\"BuyerCancelled\","
						+ "\"SellerAdjustmentID\":\"AdjustmentID-2964\","
						+ "\"Quantity\":1"
					+ "}"
				+ "}";*/
				
				"{\r\n" + 
				"  \"caOrderID\": \"102913\",\r\n" + 
				"  \"caOrderLineID\": \"2964\",\r\n" + 
				"  \"marketPlaceOrderID\": \"G-SHP-1157-33-1111\",\r\n" + 
				"  \"marketPlaceorderType\": \"OT_GOOGLE\",\r\n" + 
				"  \"returnOrderNo\": \"000511419\",\r\n" + 
				"  \"messageType\": \"FULL_RETURN_UPDATE\",\r\n" + 
				"  \"reason\": \"BuyerCancelled\",\r\n" + 
				"  \"sellerAdjustmentID\": \"AdjustmentID-2964\",\r\n" + 
				"  \"quantity\": 1,\r\n" + 
				"  \"shippingAdjustment\": null,\r\n" + 
				"  \"shippingTaxAdjustment\": null,\r\n" + 
				"  \"forceCalculateOmittedAmounts\": null,\r\n" + 
				"  \"adjustmentAmount\": null\r\n" + 
				"}";
	}

	public static String getFileContent(String fileName) {
		
		String os = System.getProperty("os.name");
		String filePath = OrderStatusServiceTest.class.getClassLoader().getResource(fileName).toString();
		if (filePath.startsWith("file:/")) {
			
			// Windows and MAC issue. For MAC need a / at beginning
			if(!StringUtils.isEmpty(os)) {
				if(os.indexOf("win")>=0 || os.indexOf("Win")>=0) {
					filePath = filePath.substring(6);
				}else if(os.indexOf("mac")>=0 || os.indexOf("Mac")>=0) {
					filePath = filePath.substring(5);
				}else {
					//Not handling at the moment
				}
			}
			
		}
		return OrderStatusUpdateUtil.readFile(filePath);
	}
	
	private static  CustomerOrderDetail getMockCustomerOrderDetailForGoogleOrder() throws Exception{
		
		return new ObjectMapper().readValue(getFileContent("EOM_Customer_OrderDetails_GL.json"), CustomerOrderDetail.class);
		
		//new ObjectMapper()
	}
	
	private static  CustomerOrderDetail getMockCustomerOrderDetailForFacebookOrder() throws Exception{
		
		return new ObjectMapper().readValue(getFileContent("EOM_Customer_OrderDetails_FB.json"), CustomerOrderDetail.class);
		
		//new ObjectMapper()
	}
	
	private static Map<String, String> createMockTokenMap() {

		tokenMap.put("username", "dummy_user");
		tokenMap.put("password", "dummy_password");

		return tokenMap;
	}
	
	
	private static Adjustment getMockAdjustmentForFullReturn() {
Adjustment adjustment = Adjustment.builder()
				.reason(IConstants.RETURN_REASON)
				.sellerAdjustmentID(IConstants.ADJUSTMENT_ID+103682)
				.build();
		
		adjustment.setCaOrderID("103682");
		adjustment.setReturnOrderNo("000511413");
		adjustment.setMarketPlaceOrderID("11240015750101");
		adjustment.setMarketPlaceorderType(IConstants.ORDER_TYPE_FB);
		
		return adjustment;
	}

	
	private String configString = "{\"MQ_CONFIG\":{\"MQ_APP_PWD\":\"Hybris@501\",\"MQ_APP_USER\":\"hybrisapp\",\"MQ_CHANNEL\":\"HYBRIS.CH1\","
			+ "\"MQ_HOST\":\"172.26.99.224\",\"MQ_PORT\":1500,\"MQ_QMGR\":\"QAQM1\",\"MQ_RECV_QNAME\":\"SNDR.HYB.CUSTORDER.TA1.E01\"}}";

}
