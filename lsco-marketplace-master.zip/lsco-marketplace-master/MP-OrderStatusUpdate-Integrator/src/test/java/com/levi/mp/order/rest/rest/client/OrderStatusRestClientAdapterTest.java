package com.levi.mp.order.rest.rest.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.levi.mp.OrderStatusUpdateTestConfig;
import com.levi.mp.config.OrderStatusUpdateLoadConfiguration;
import com.levi.mp.order.model.json.Adjustment;
import com.levi.mp.order.model.json.CustomerOrderDetail;
import com.levi.mp.order.model.json.Item;
import com.levi.mp.order.model.json.OrderStatusUpdateConfig;
import com.levi.mp.order.model.json.ShipDetail;
import com.levi.mp.order.model.json.Shipment;
import com.levi.mp.order.rest.client.OrderStatusRestClientAdapter;
import com.levi.mp.order.service.OrderStatusServiceTest;
import com.levi.mp.order.service.SQSMessageService;
import com.levi.mp.order.util.OrderStatusUpdateUtil;
import com.levi.mp.shared.sns.SNSService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = OrderStatusUpdateTestConfig.class)
public class OrderStatusRestClientAdapterTest {
	
	@MockBean
	OrderStatusUpdateLoadConfiguration orderStatusUpdateLoadConfiguration;
	
	@MockBean(name="restTemplate")
	RestTemplate restTemplate;
	
	@MockBean(name="RestTemplateWithTimeout")
	RestTemplate restTemplateWithTimeout;
	
	@MockBean
	SQSMessageService sqsMessageService;
	
	@MockBean
	SNSService snsService;

	
	@Autowired
	OrderStatusRestClientAdapter orderStatusRestClientAdapter;
	
	private static final OrderStatusUpdateConfig orderStatusUpdateConfig = new OrderStatusUpdateConfig();
	private static final Map<String, String> tokenMap = new HashMap<>();
	
	/*@Autowired
	ChannelAdvisorTokenService channelAdvisorTokenService;*/
	
	String caAccessToken = "Dummy_Access_Token";
	String dummyCAOrderId = "102913";
	String dummyCAOrderLineId = "2964";
	String dummyExternalOrderNumber = "102913";
	String dummyMarketPlaceOrderNumber = "G-SHP-1157-33-1111";
	String dummyMarketPlaceOrderType = "OT_GOOGLE";
	String dummyReturnOrderNo = "000511419";
	
	@BeforeClass
	public static void setUp() {
		createConfig();
		createMockTokenMap();
	}
	
	@Test
	public void updateShipStatusTest_Success() {
		
		ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);
		
		try {
			boolean status = orderStatusRestClientAdapter.updateShipStatus(getShipment(), caAccessToken);
			Assert.assertTrue(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null); //Fail if exception is raised
		}
	}
	
	
	
	@Test
	public void updateShipStatusTest_Non204_Response() {
		
		ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);
		
		Mockito.doNothing().when(sqsMessageService).sendMessages(Mockito.anyString());
		
		try {
			boolean status = orderStatusRestClientAdapter.updateShipStatus(getShipment(), caAccessToken);
			Assert.assertFalse(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void updateShipStatusTest_HttpStatusCodeException() {
		
		//ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", null, null, null));
		
		//Mockito.doNothing().when(sqsMessageService).sendMessages(Mockito.anyString());
		
		try {
			boolean status = orderStatusRestClientAdapter.updateShipStatus(getShipment(), caAccessToken);
			Assert.assertFalse(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void updateShipStatusTest_Non204_Response_SQSException() {
		
		ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);
		
		Mockito.doThrow(new RuntimeException("Dummy SQS Exception"))
		.when(sqsMessageService).sendMessages(Mockito.anyString());
	
		Mockito.when(snsService.notifySupport(Mockito.anyString(), 
				Mockito.anyString())).thenReturn(Boolean.TRUE);

		try {
			boolean status = orderStatusRestClientAdapter.updateShipStatus(getShipment(), caAccessToken);
			Assert.assertFalse(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	
	
	@Test
	public void updatePartialOrderCancelStatus_Success() {
		ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);
		
		try {
			boolean status = orderStatusRestClientAdapter.updatePartialOrderCancelStatus(getAdjustment(), caAccessToken);
			Assert.assertTrue(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null); //Fail if exception is raised
		}
	}
	
	
	
	@Test
	public void updatePartialOrderCancelStatus_Non204_Response() {
		ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);
		
		Mockito.doNothing().when(sqsMessageService).sendMessages(Mockito.anyString());
		
		try {
			boolean status = orderStatusRestClientAdapter.updatePartialOrderCancelStatus(getAdjustment(), caAccessToken);
			Assert.assertFalse(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void updatePartialOrderCancelStatus_HttpStatusCodeException() {
		//ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
		.thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", null, null, null));
		
		//Mockito.doNothing().when(sqsMessageService).sendMessages(Mockito.anyString());
		
		try {
			boolean status = orderStatusRestClientAdapter.updatePartialOrderCancelStatus(getAdjustment(), caAccessToken);
			Assert.assertFalse(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void updateFullOrderCancelStatus_Success() {
		ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);
		
		try {
			boolean status = orderStatusRestClientAdapter.updateFullOrderCancelStatus(getAdjustment(), caAccessToken);
			Assert.assertTrue(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null); //Fail if exception is raised
		}
	}
	
	@Test
	public void updateFullOrderCancelStatus_Non204_Response() {
		ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);
		
		Mockito.doNothing().when(sqsMessageService).sendMessages(Mockito.anyString());
		
		try {
			boolean status = orderStatusRestClientAdapter.updateFullOrderCancelStatus(getAdjustment(), caAccessToken);
			Assert.assertFalse(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	@Test
	public void updateFullOrderCancelStatus_HttpStatusCodeException() {
		//ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();
		
		Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig())
			.thenReturn(orderStatusUpdateConfig);
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
		.thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", null, null, null));
		
		//Mockito.doNothing().when(sqsMessageService).sendMessages(Mockito.anyString());
		/*Mockito.doThrow(new RuntimeException("Dummy Exception"))
			.when(sqsMessageService).sendMessages(Mockito.anyString());*/
		
		try {
			boolean status = orderStatusRestClientAdapter.updateFullOrderCancelStatus(getAdjustment(), caAccessToken);
			Assert.assertFalse(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	
	@Test
	public void updateReturnOrderStatus_Success() {
		ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);
		
		try {
			boolean status = orderStatusRestClientAdapter.updateReturnOrderStatus(getAdjustment(), caAccessToken);
			Assert.assertTrue(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null); //Fail if exception is raised
		}
	}
	
	
	@Test
	public void updateReturnOrderStatus_Non204_Response() {
		ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
			.thenReturn(responseEntity);
		
		Mockito.doNothing().when(sqsMessageService).sendMessages(Mockito.anyString());
		
		try {
			boolean status = orderStatusRestClientAdapter.updateReturnOrderStatus(getAdjustment(), caAccessToken);
			Assert.assertFalse(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void updateReturnOrderStatus_HttpStatusCodeException() {
		//ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();
		
		Mockito.when(restTemplate.exchange(
				Mockito.anyString(),
				Mockito.any(HttpMethod.class), 
				Mockito.any(), 
				ArgumentMatchers.<Class<String>>any()))
		.thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", null, null, null));
		
		//Mockito.doNothing().when(sqsMessageService).sendMessages(Mockito.anyString());
		
		try {
			boolean status = orderStatusRestClientAdapter.updateReturnOrderStatus(getAdjustment(), caAccessToken);
			Assert.assertFalse(status);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void fetchCustomerOrderDetailsFromEOMTest_Success() {
		Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig())
			.thenReturn(orderStatusUpdateConfig);
		
		ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.OK)
				.body(getFileContent("EOM_Customer_OrderDetails_GL.json"));
		
		try {
			Mockito.when(restTemplateWithTimeout.exchange(
					Mockito.anyString(),
					Mockito.any(HttpMethod.class), 
					Mockito.any(), 
					ArgumentMatchers.<Class<String>>any()))
				.thenReturn(responseEntity);
			
			CustomerOrderDetail customerOrderDetail = orderStatusRestClientAdapter
					.fetchCustomerOrderDetailsFromEOM("DummyOrderEOM");
			
			Assert.assertNotNull(customerOrderDetail);
			Assert.assertNotNull(customerOrderDetail.getCustomerOrder());
			Assert.assertNotNull(customerOrderDetail.getCustomerOrder().getOrderLines());
			Assert.assertNotNull(customerOrderDetail.getCustomerOrder().getOrderLines().getOrderLineList());
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void fetchCustomerOrderDetailsFromEOMTest_Exception() {
		
		Mockito.when(orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig())
			.thenReturn(orderStatusUpdateConfig);
		
		try {
			Mockito.when(restTemplateWithTimeout.exchange(
					Mockito.anyString(),
					Mockito.any(HttpMethod.class), 
					Mockito.any(), 
					ArgumentMatchers.<Class<String>>any()))
				.thenThrow(new RuntimeException("Dummy Exception while fetching Customer Order Details"));
			
			CustomerOrderDetail customerOrderDetail = orderStatusRestClientAdapter
					.fetchCustomerOrderDetailsFromEOM("DummyOrderEOM");
			
		} catch (Exception e) {
			Assert.assertTrue(e.getMessage()!=null);
		}
	}
	
	
	@Test
	public void updateFullReturnOrderStatusTest_Success() {
		
		
		try {
			ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.NO_CONTENT).build();
			
			Mockito.when(restTemplate.exchange(
					Mockito.anyString(),
					Mockito.any(HttpMethod.class),
					Mockito.any(),
					ArgumentMatchers.<Class<String>>any()
					))
				.thenReturn(responseEntity);
			
			orderStatusRestClientAdapter
				.updateFullReturnOrderStatus(getAdjustment(), caAccessToken);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);//Fail on exception
		}
		
	}
	
	
	@Test
	public void updateFullReturnOrderStatusTest_Non204_Response() {
		
		try {
			ResponseEntity<String> responseEntity = ResponseEntity.badRequest().build();
			
			Mockito.when(restTemplate.exchange(
					Mockito.anyString(),
					Mockito.any(HttpMethod.class),
					Mockito.any(),
					ArgumentMatchers.<Class<String>>any()
					))
				.thenReturn(responseEntity);
			
			Mockito.doNothing().when(sqsMessageService).sendMessages(Mockito.anyString());
			
			orderStatusRestClientAdapter
			.updateFullReturnOrderStatus(getAdjustment(), caAccessToken);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);//Fail on exception
		}
		
	}
	
	
	@Test
	public void updateFullReturnOrderStatusTest_Non204_Response_SQSException() {
		
			ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
			
			Mockito.when(restTemplate.exchange(
					Mockito.anyString(),
					Mockito.any(HttpMethod.class),
					Mockito.any(),
					ArgumentMatchers.<Class<String>>any()
					))
				.thenReturn(responseEntity);
			
			Mockito.doThrow(new RuntimeException("Dummy SQS Exception"))
				.when(sqsMessageService).sendMessages(Mockito.anyString());
			
			Mockito.when(snsService.notifySupport(Mockito.anyString(), Mockito.anyString())).thenReturn(Boolean.TRUE);
			
		try {
			orderStatusRestClientAdapter
			.updateFullReturnOrderStatus(getAdjustment(), caAccessToken);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);//Fail on exception
		}
		
	}
	
	
	@Test
	public void updateFullReturnOrderStatusTest_HttpStatusCodeException() {
			
			Mockito.when(restTemplate.exchange(
					Mockito.anyString(),
					Mockito.any(HttpMethod.class),
					Mockito.any(),
					ArgumentMatchers.<Class<String>>any()
					))
				.thenThrow(HttpClientErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", 
						null, null, null));
			
			Mockito.doNothing()
				.when(sqsMessageService).sendMessages(Mockito.anyString());
			
		try {
			orderStatusRestClientAdapter
			.updateFullReturnOrderStatus(getAdjustment(), caAccessToken);
			
		} catch (Exception e) {
			Assert.assertFalse(e.getMessage()!=null);//Fail on exception
		}
		
	}
	
	
	/*@Test
	@Ignore //These are using actual CA calls
	//@Test
	public void updateShipStatusTest() {
		try {
			
			if(caAccessToken == null) {
				caAccessToken = channelAdvisorTokenService.getOAuth2Token();
			}
			
			String caOrderId = "103107";
			Shipment shipment = getShipment();
			orderStatusRestClientAdapter.updateShipStatus(caOrderId, shipment , caAccessToken);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Test
	@Ignore //These are using actual CA calls
	public void updateCancelStatusTest() {
		
		if(caAccessToken == null) {
			caAccessToken = channelAdvisorTokenService.getOAuth2Token();
		}
		
		String caOrderLineId = "2964"; //This is the ITEM ID in CA
		//String caAccessToken = "KVR5e-jgqQwZcbC4QaKA-YCPZ3lcbuHWfsX6DfO6n5g-22653";
		Adjustment adjustment = getAdjustment();
		try {
			orderStatusRestClientAdapter.updateCancelStatus(caOrderLineId, adjustment, caAccessToken);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	
	public Adjustment getAdjustment() {
		
		Adjustment adjustment = new Adjustment();
		adjustment.setReason("BuyerCancelled");
		adjustment.setSellerAdjustmentID("AdjustmentID-2964");
		adjustment.setQuantity(1);
		
		adjustment.setCaOrderID(dummyCAOrderId);
		adjustment.setReturnOrderNo(dummyReturnOrderNo);
		adjustment.setMarketPlaceOrderID(dummyMarketPlaceOrderNumber);
		adjustment.setMarketPlaceorderType(dummyMarketPlaceOrderType);
		adjustment.setCaOrderLineID(dummyCAOrderLineId);
		
		return adjustment;
	}
	
	
	public Shipment getShipment() {
		
		Shipment shipment = new Shipment();
		ShipDetail shipDetail = new ShipDetail();
		shipDetail.setShippedDateUtc("2018-12-08T12:58:47.1Z");
		shipDetail.setTrackingNumber("1Z999AA10123456765");
		shipDetail.setSellerFulfillmentID("ship-kdjslj");
		shipDetail.setDistributionCenterID("0");
		shipDetail.setDeliveryStatus("Complete");
		shipDetail.setShippingCarrier("UPS");
		shipDetail.setShippingClass("Ground");
		
		List<Item> items = new ArrayList<>();
		Item item =  new Item();
		item.setSku("00501011502830");
		item.setQuantity(1);
		
		items.add(item);
		shipDetail.setItems(items);
		shipment.setValue(shipDetail);
		
		shipment.setCaOrderID(dummyCAOrderId);
		shipment.setMarketPlaceOrderID(dummyMarketPlaceOrderNumber);
		shipment.setMarketPlaceorderType(dummyMarketPlaceOrderType);
		
		return shipment;
	}
	
	
	public static String getFileContent(String fileName) {
		
		String os = System.getProperty("os.name");
		String filePath = OrderStatusServiceTest.class.getClassLoader().getResource(fileName).toString();
		if (filePath.startsWith("file:/")) {
			
			// Windows and MAC issue. For MAC need a / at beginning
			if(!StringUtils.isEmpty(os)) {
				if(os.indexOf("win")>=0 || os.indexOf("Win")>=0) {
					filePath = filePath.substring(6);
				}else if(os.indexOf("mac")>=0 || os.indexOf("Mac")>=0) {
					filePath = filePath.substring(5);
				}else {
					//Not handling at the moment
				}
			}
			
		}
		return OrderStatusUpdateUtil.readFile(filePath);
	}
	

	private static void createConfig() {
		orderStatusUpdateConfig.setSqsQueueName("");
		orderStatusUpdateConfig.setLeviEOMUserName("Dummy User");
		orderStatusUpdateConfig.setLeviEOMPasswd("Dummy Password");
		orderStatusUpdateConfig.setLeviEOMHost("https://google.com");
		
		
	}
	
	private static Map<String, String> createMockTokenMap() {

		tokenMap.put("username", "dummy_user");
		tokenMap.put("password", "dummy_password");

		return tokenMap;
	}
}
