package com.levi.mp.order.backend.processor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;



import com.cucumber.listener.Reporter;
//import com.jayway.restassured.response.Header;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import com.levi.mp.order.backend.orderxmls.*;


public class CreateShipment {
DocumentBuilder docBuilder;
DocumentBuilderFactory docFactory;
Document doc;
Element root;
File output;
public String OutputFilePath;

public CreateShipment(List<OrdersToFulfill> orderlist,File f, String type, String fp){
docFactory = DocumentBuilderFactory.newInstance();

                try {
                    docBuilder = docFactory.newDocumentBuilder();

                    try {
				                // root elements
				    doc = docBuilder.newDocument();
				    root=doc.createElement("ns0:OrderShipments");
				    root.setAttribute("xmlns:ns0","http://www.levi.com/US/OrderShipment/2017-05-01");
				    doc.appendChild(root);
				
				    processOrders(orderlist,type);
				    TransformerFactory transformerFactory = TransformerFactory.newInstance();
				    Transformer transformer = transformerFactory.newTransformer();
                    DOMSource source = new DOMSource(doc);
                    Date today=new Date();
                    SimpleDateFormat sd=new SimpleDateFormat("YYYYMMddHHmmssSSS");
                    String trans=sd.format(today);
                    

                    if(!type.equalsIgnoreCase("shipment") && !type.equalsIgnoreCase("USshipment")&& !type.equalsIgnoreCase("cancel")
                                                    && !type.equalsIgnoreCase("shipmentScript")){
                    
                    output=new File(fp+"/ORDSHP"+trans+".xml");
                    }
                    else if(type.equalsIgnoreCase("shipmentScript")) {
                                    
                    output=new File(fp+"/ORDSHP"+trans+".xml");
                    }
                    else{
                                    
                	output=new File(fp+"/ORDSHP"+trans+".xml");
                    }

                    StreamResult result = new StreamResult(output);
                    transformer.transform(source, result);
                    docBuilder.reset();//added
                    transformer.reset();//added
                                                                    
                    		} catch (TransformerConfigurationException e) {
//System.out.println(e);
						                e.printStackTrace();
						} catch (TransformerException e) {
						
						                e.printStackTrace();
						}

                    	Reporter.addStepLog("Shipment files are created Successfully");
                	} catch (ParserConfigurationException e) {
                    Reporter.addStepLog("Status of the order not updated in Channel Advisor"+ ExceptionUtils.getStackTrace(e)); 

                    e.printStackTrace();
                    //System.out.println(e);
    }
    }

    boolean processOrders(List<OrdersToFulfill> orderlist, String type){
                    for(OrdersToFulfill order:orderlist){

                    System.out.println(order);
                    
                    Element ordershipment=doc.createElement("OrderShipment");
                    root.appendChild(ordershipment);
                    fillHeaderInfo(ordershipment,order.h);
                    for(Detail det:order.d)
                    fillDetail(ordershipment,det,type);
                    int shp=0;
                    for(Detail det:order.d)
                    shp=shp+det.QuantityOrdered;
                    if(shp>0){
                    Element pack=doc.createElement("Package");
                    ordershipment.appendChild(pack);
                    fillPackageHeader(pack, order);
                    for(Detail det:order.d)
                    fillPackage(pack,det,type);
                                    }
                    }
                    return false;
    }
    void fillPackageHeader(Element pack, OrdersToFulfill order){
    
                    Element ShippingCareer=null;
                    Element ShippingSer = null;
//                            if("USfile".equals(type) || "USshipment".equals(type))
    //            {
                    ShippingCareer=doc.createElement("ShippingCarrier");
                    ShippingCareer.appendChild(doc.createTextNode("FR1US00074"));
                    ShippingSer=doc.createElement("ShippingServiceLevel");
                    ShippingSer.appendChild(doc.createTextNode("01"));
    //}


                    /*                           else{
                                ShippingCareer=doc.createElement("ShippingCarrier");
                                ShippingCareer.appendChild(doc.createTextNode("CP"));
                                ShippingSer=doc.createElement("ShippingServiceLevel");
                                /*if(order.h.ShippingCarrierGroup.equalsIgnoreCase("2 DAY")){
                                                ShippingSer.appendChild(doc.createTextNode("Second Day"));
                                }else if(order.h.ShippingCarrierGroup.equalsIgnoreCase("1 Day")){
                                                ShippingSer.appendChild(doc.createTextNode("Next Day"));
                                } else{
                                                ShippingSer.appendChild(doc.createTextNode("GND"));
                }
*/           

                    
                    Element TrackingNum=doc.createElement("TrackingNum");
                    String TrackingNumber = new SimpleDateFormat("HHmmss").format(new Date());
                    TrackingNum.appendChild(doc.createTextNode("1Z867F6RP200" + TrackingNumber));
                    Element DCCartonId=doc.createElement("DCCartonId");
                    String DCCarton = new SimpleDateFormat("YYYYMMddHHmmssSSS").format(new Date());
                    DCCarton = DCCarton + new Random().nextInt(100000);
                    if(DCCarton.length()>20){
                                    DCCartonId.appendChild(doc.createTextNode(DCCarton.substring(0, 20)));
                    }
                    Element ShippedDateTime=doc.createElement("ShippedDateTime");
                    Date today=new Date();
                    SimpleDateFormat sd=new SimpleDateFormat("YYYYMMddHHmmss");
                    String trans=sd.format(today);
                    ShippedDateTime.appendChild(doc.createTextNode(trans));
                    pack.appendChild(ShippingCareer);
                    pack.appendChild(ShippingSer);
                    pack.appendChild(TrackingNum);
                    pack.appendChild(DCCartonId);
                    pack.appendChild(ShippedDateTime);


    }
    void fillDetail(Element ordershipment,Detail d, String type){
                    Element detail=doc.createElement("Detail");

                    /*<RecordType>S</RecordType>   S or C
                    <TransactionDateTime>20150804120946</TransactionDateTime>
                    <ClientOrderLine>1</ClientOrderLine>
                    <ClientPartNum>1739000000S</ClientPartNum>
                    <QtyShipped>0000002</QtyShipped>
                    <QtyCancelled>0</QtyCancelled>
                    <CancelReasonCode>
                    </CancelReasonCode>*/
                    String record="S";
                    int qtyCanc=0;
                    int qtyShip=0;
                    String rsnCode;
                    String invStatus;
                    
                    if(!type.equalsIgnoreCase("cancel")){
                                    qtyCanc=d.QuantityCancelled;
                                    qtyShip=d.QuantityOrdered;
                    }
                    else{
                                    qtyCanc=d.QuantityOrdered;
                                    rsnCode="Z7";
                                    invStatus="DMG";
                    }
                    Date today=new Date();
                    SimpleDateFormat sd=new SimpleDateFormat("YYYYMMddHHmmss");
                    String trans=sd.format(today);
                                                    //String reason="CP";


                    Element recordtype=doc.createElement("RecordType");
                    recordtype.appendChild(doc.createTextNode(record));

                    Element transactiondt=doc.createElement("TransactionDateTime");
                    transactiondt.appendChild(doc.createTextNode(trans));

                    Element ClientOrderLine=doc.createElement("LSCoOrderLine");
                    ClientOrderLine.appendChild(doc.createTextNode(d.OrderLineSeq));

                    Element ClientPartNum=doc.createElement("LSCoPartNum");
                    ClientPartNum.appendChild(doc.createTextNode(d.LSCoPartNum));


                    Element transactiondt1=doc.createElement("TransactionDateTime");
                    transactiondt1.appendChild(doc.createTextNode(trans));

                    Element ClientOrderLine1=doc.createElement("LSCoOrderLine");
                    ClientOrderLine1.appendChild(doc.createTextNode(d.OrderLineSeq));

                    Element ClientPartNum1=doc.createElement("LSCoPartNum");
                    ClientPartNum1.appendChild(doc.createTextNode(d.LSCoPartNum));

                    Element QtyShipped=doc.createElement("QtyShipped");
                    QtyShipped.appendChild(doc.createTextNode(String.format("%7s",String.valueOf(qtyShip)).replace(' ','0')));

                    Element qtyCancelled=doc.createElement("QtyCancelled");
                    qtyCancelled.appendChild(doc.createTextNode(String.valueOf("0")));

                    Element cancelreason=doc.createElement("CancelReasonCode");
                    cancelreason.appendChild(doc.createTextNode(""));
                    Element cancelreason1=doc.createElement("CancelReasonCode");
                    cancelreason1.appendChild(doc.createTextNode(d.CancelReasonCode));

                    Element InventoryStatus=doc.createElement("InventoryStatus");
                    InventoryStatus.appendChild(doc.createTextNode(d.InventoryStatusShp));

                    detail.appendChild(recordtype);
                    detail.appendChild(transactiondt1);
                    detail.appendChild(ClientOrderLine1);
                    detail.appendChild(ClientPartNum1);
                    detail.appendChild(QtyShipped);
                    detail.appendChild(qtyCancelled);
                    detail.appendChild(cancelreason);
                    detail.appendChild(InventoryStatus);
if(qtyShip>0)
                ordershipment.appendChild(detail);

                if(qtyCanc>0){
                                Element detail1=doc.createElement("Detail");
                    ordershipment.appendChild(detail1);
                    Element recordtype1=doc.createElement("RecordType");
                    recordtype1.appendChild(doc.createTextNode("C"));
                    detail1.appendChild(recordtype1);
                    detail1.appendChild(transactiondt);
                    detail1.appendChild(ClientOrderLine);
                    detail1.appendChild(ClientPartNum);

                    Element QtyShipped1=doc.createElement("QtyShipped");
                    QtyShipped1.appendChild(doc.createTextNode("0"));

                    Element qtyCancelled1=doc.createElement("QtyCancelled");
                    qtyCancelled1.appendChild(doc.createTextNode(String.format("%7s",String.valueOf(qtyCanc)).replace(' ','0')));

                    Element cancelreason2=doc.createElement("CancelReasonCode");
                    cancelreason2.appendChild(doc.createTextNode("Z7"));
                    
                    Element InventoryStatusCan=doc.createElement("InventoryStatus");
                    InventoryStatusCan.appendChild(doc.createTextNode("DMG"));

                    detail1.appendChild(QtyShipped1);
                    detail1.appendChild(qtyCancelled1);
                    detail1.appendChild(cancelreason2);
                    detail1.appendChild(InventoryStatusCan);
                }
    }
    void fillHeaderInfo(Element ordershipment,Header h){
    /*           <WarehouseId>227</WarehouseId>
                    <ClientId>100080</ClientId>
                    <ClientOrderNum>20674003</ClientOrderNum>
                    <DCOrderNum>F100066678001</DCOrderNum>*/

                    Element warehouseid=doc.createElement("WarehouseId");
                    warehouseid.appendChild(doc.createTextNode(h.WarehouseId));

                    Element clientid=doc.createElement("ClientId");
                    clientid.appendChild(doc.createTextNode(h.ClientId));

                    Element ClientOrderNum=doc.createElement("LSCoDistributionOrderNum");
                    ClientOrderNum.appendChild(doc.createTextNode(h.LSCoDistributionOrderNum));
                    ordershipment.appendChild(ClientOrderNum);

                    Element DCOrderNum= null;
                    Element SmartLabelNum= null;
//                            if("USfile".equals(type) || "USshipment".equals(type)){
    
                    DCOrderNum=doc.createElement("DCOrderNum");
                    DCOrderNum.appendChild(doc.createTextNode(h.OrderNumber));
                    String smartLabelNumValue = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase().substring(0, 18);
                    SmartLabelNum=doc.createElement("SmartLabelNum");
                    SmartLabelNum.appendChild(doc.createTextNode(smartLabelNumValue));
//            }
/*           else{
                                DCOrderNum=doc.createElement("DCOrderNum");
                                String date = new SimpleDateFormat("YYMMddHHmmssSSS").format(new Date());
                                DCOrderNum.appendChild(doc.createTextNode("DC" + date));

                    }*/
                    ordershipment.appendChild(warehouseid);
                    ordershipment.appendChild(clientid);
                    ordershipment.appendChild(DCOrderNum);
    //            if("USfile".equals(type) || "USshipment".equals(type)){
                    ordershipment.appendChild(SmartLabelNum);
    //            }


    }

    void fillPackage(Element pack,Detail d, String type){
    /*           <PackageDetail>
                    <ClientOrderLine>1</ClientOrderLine>
                    <ClientPartNum>1739000000S</ClientPartNum>
                    <QtyShipped>2</QtyShipped>
                    </PackageDetail>*/
                    int qtyShip=0;
                    if(!type.equalsIgnoreCase("cancel")){
                                    qtyShip = d.QuantityOrdered;
                    }
                    if(qtyShip>0){
                    Element packagedetail=doc.createElement("PackageDetail");
                    pack.appendChild(packagedetail);
                    Element ClientOrderLine=doc.createElement("LSCoOrderLine");
                    ClientOrderLine.appendChild(doc.createTextNode(d.OrderLineSeq));

                    Element ClientPartNum=doc.createElement("LSCoPartNum");
                    ClientPartNum.appendChild(doc.createTextNode(d.LSCoPartNum));

                    Element QtyShipped=doc.createElement("QtyShipped");
                    QtyShipped.appendChild(doc.createTextNode(String.valueOf(qtyShip)));

                    packagedetail.appendChild(ClientOrderLine);
                    packagedetail.appendChild(ClientPartNum);
                    packagedetail.appendChild(QtyShipped);
                    }
        }

}
