package com.levi.mp.order.stepmethods;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.cucumber.listener.Reporter;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.levi.mp.order.model.json.OrderDownloadData;
import com.levi.mp.order.model.json.OrderStatusUpdate;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DownloadFileFromS3 {           

@SuppressWarnings("deprecation")
public List<OrderDownloadData> downloadFileFromS3(String clientRegion,String bucketName,String key) throws IOException, ParseException{                      

        S3Object fullObject = null;
        List<OrderDownloadData> orderDownloadDataList =null;
        try {
            AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
			                    .withRegion(clientRegion)
			                    .withCredentials(new ProfileCredentialsProvider())
			                    .build();      
            
            fullObject = s3Client.getObject(new GetObjectRequest(bucketName, key));
            CsvMapper csvMapper = new CsvMapper();
            CsvSchema schema = csvMapper.schemaFor(OrderDownloadData.class)
                                            .withHeader();
            ObjectReader oReader = csvMapper.reader(OrderDownloadData.class).with(schema);
            MappingIterator<OrderDownloadData> mit =oReader.readValues(fullObject.getObjectContent());
            orderDownloadDataList = new ArrayList<OrderDownloadData>();

            while (mit.hasNext()) {
                            
                            orderDownloadDataList.add(mit.next());
                                }              
                                          
        }catch(Exception e){
               e.printStackTrace();
        }
        return orderDownloadDataList;
    }

public JSONObject getJSONAttributeVal(String filename) throws IOException, ParseException{
                Object configobj = new JSONParser().parse(new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream(filename)));
    JSONObject jconfigobj = (JSONObject) configobj; 
                return jconfigobj;
}
                
}
