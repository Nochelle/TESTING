package com.levi.mp.order.backend.processor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.swing.JComboBox;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import lombok.extern.log4j.Log4j2;

import org.springframework.boot.autoconfigure.cache.CacheProperties.EhCache;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.cucumber.listener.Reporter;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.levi.mp.order.backend.filetransfers.FileDownloader;
import com.levi.mp.order.backend.filetransfers.FileUploader;
import com.levi.mp.order.backend.orderxmls.OrdersToFulfill;
import com.levi.mp.order.backend.orderxmls.ShipmentInfo;
import com.levi.mp.order.backend.orderxmls.ShippingDetail;
import com.levi.mp.order.model.json.OrderDownloadData;
import com.levi.mp.order.stepdef.BackendStep;
import com.levi.mp.order.stepdef.OrderStatusUpdateSteps;
//import com.levi.mp.order.stepmethods.PushOrdersInEOM;
import com.levi.mp.order.util.CommonUtilities;
import com.levi.mp.order.util.TestDataProvider.TestData;

import org.assertj.core.api.SoftAssertions;

import static org.junit.Assert.*;

@Log4j2
public class BackendStarter {


	public static String status_for_shipping=null;
	public String orderStatus_get;
	public static List<OrderDownloadData> orderDownloadDataList;
	public OrderStatusUpdateSteps orderStatusUpdateSteps;
	private SoftAssertions softAssertions=new SoftAssertions();
	public BackendStarter() throws Throwable 
	{

		orderDownloadDataList=OrderStatusUpdateSteps.orderDownloadDataList;

		//static List<OrdersToFulfill> orderlist = new ArrayList<OrdersToFulfill>();
		//static OTFHandler p = new OTFHandler();

	}

	public void deleteimproperShipmentOTFFiles(ArrayList<String> FilePaths, String ORDERNUM) throws IOException, SAXException, ParserConfigurationException, TransformerFactoryConfigurationError, TransformerException{
		for (int i=0; i<FilePaths.size();i++){
			File xmlFile = new File(FilePaths.get(i));
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			InputStream iStream = new FileInputStream(xmlFile);
			org.w3c.dom.Document document = documentBuilderFactory.newDocumentBuilder().parse(iStream);
			StringWriter stringWriter = new StringWriter();
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "false");
			transformer.transform(new DOMSource(document), new StreamResult(stringWriter));
			String output = stringWriter.toString();
			String xml2String =  output;


			if(!xml2String.contains(ORDERNUM)){
				xmlFile.delete();
			}
		}

	}
	public File createShipment(String SFTPHOST,int SFTPPORT,String SFTPUSER,String SFTPPASS,String InboundPath,
			String FilePath , String ThreeDigitNum, String ORDERNUM,String STATUS) throws JSchException, SftpException, IOException, SAXException, ParserConfigurationException, TransformerFactoryConfigurationError, TransformerException {
		try {
			File fXmlFile ;

			ArrayList<String> otdfilepaths = null;
			int count=0;
			boolean flag_for_function=false;
			try {
				otdfilepaths = FileDownloader.SFTP_DownloadOTF(SFTPHOST, SFTPPORT, SFTPUSER, SFTPPASS, InboundPath, FilePath, ThreeDigitNum);
				flag_for_function=true;
			} catch (Exception e) {
			
				while (flag_for_function==false&&count<3) {
					count++;
					otdfilepaths = FileDownloader.SFTP_DownloadOTF(SFTPHOST, SFTPPORT, SFTPUSER, SFTPPASS, InboundPath, FilePath, ThreeDigitNum);
					flag_for_function=true;
					
				}
				
				e.printStackTrace();
			}
			
			
			if(otdfilepaths.size()>1)
			{
				for (int i = 1; i < otdfilepaths.size(); i++) {
					otdfilepaths.remove(i);

				}
			}

			System.err.println(">>>>>>>>>>>>>>>>>>>> "+otdfilepaths.size());
			for(int i = 0; i < otdfilepaths.size(); i++) {
				System.out.println(otdfilepaths.get(i).toString());
			}

			deleteimproperShipmentOTFFiles(otdfilepaths,ORDERNUM);

			File shipment = null;
			for (int i=0; i<otdfilepaths.size();i++){

				System.err.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>> STATUS IS  "+STATUS +"for "+i+" "+"Order");



				if(STATUS.contains("cancel shipment")||STATUS.equalsIgnoreCase("cancel"))
				{
					STATUS="cancel";
					System.out.println(">>>>>>>>>>>>>>>>> Order is of type Full cancel");
				}
				else
				{
					if(STATUS.contains("full shipment")||STATUS.equalsIgnoreCase("full shipment"))
					{
						STATUS="shipment";
						System.out.println(">>>>>>>>>>>>>>>>> Order is of type Full Shipment");
					}
				}




				List<OrdersToFulfill> orderlist = new ArrayList<OrdersToFulfill>();//added
				OTFHandler p = new OTFHandler();//added 
				if(otdfilepaths.get(i)!=null){

					if(CommonUtilities.getXMLTagText(otdfilepaths.get(i),"CardType").contains("Google"))
					{
						CommonUtilities.updateXMLTagText(otdfilepaths.get(i),"ClientId","293598");

						Reporter.addStepLog("Client ID updated as 293598 successfully for  "+ORDERNUM);
					}
					else 
					{
						CommonUtilities.updateXMLTagText(otdfilepaths.get(i),"ClientId","293599");   

						Reporter.addStepLog("Client ID updated as 293599 successfully for  "+ORDERNUM);

					}
					fXmlFile = new File(otdfilepaths.get(i));
					log.info("Processing shipment file for "+ORDERNUM);
					p.processFile(fXmlFile, orderlist); 
					CreateShipment c = new CreateShipment(orderlist, fXmlFile,STATUS,FilePath);
					shipment = c.output;    
					log.info("Shipment file processed for "+ORDERNUM);



				}
			}

			return shipment;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	public void uploadShipment(String SFTPHOST,int SFTPPORT ,String SFTPUSER, String SFTPPASS, String Outbound,
			String FilePath,String FileName , File ShippmentFile,String ordernum) throws JSchException, SftpException, InterruptedException {
		log.info("Upload shipment files >>>");
		FileUploader.SFTP_UploadOTF( SFTPHOST, SFTPPORT , SFTPUSER,  SFTPPASS,  Outbound, "", "" ,  ShippmentFile,ordernum);
		log.info("Shipment files uploaded>>");
	}

	public String verifyOrderStatus( String orderStatus, String ordernum){
		try {
			Thread.sleep(3000);                                       
			log.info("Checking Order status in EOM >>> " + ordernum);
			OrderServices os= new OrderServices();
			orderStatus_get= os.getOrderStatus(TestData.EOMURL.val(), TestData.EOMUSERNAME.val(), TestData.EOMPASSWORD.val(), ordernum);
			int count=0;
			while (count<3&&orderStatus_get.equalsIgnoreCase("released")) {
				count++;
				orderStatus_get= os.getOrderStatus(TestData.EOMURL.val(), TestData.EOMUSERNAME.val(), TestData.EOMPASSWORD.val(), ordernum);

				
			}
			
			

			softAssertions
			.assertThat(orderStatus_get.contains(orderStatus));

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orderStatus_get;
	}

}
