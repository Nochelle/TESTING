package com.levi.mp.order.backend.orderxmls;

public class ShippingDetail {
	// Taking only information required to generate Shipment file from Details
	// Node
	public String OriginalOrderLineNum;
	public String ClientPartNum;
	public int QtyShipped;
	public int QtyReturned;
	public String AltOrderNum;
	public String PartClientId;
	public String OriginalClientOrderLineNum;
	public String ClientOrderLine;
	public String LSCoOrderLine;

	@Override
	public String toString() {
		return "OrderLineSequence: " + OriginalOrderLineNum + "\nClientPartNum: "
				+ ClientPartNum + "\nQuantityOrdered: " + QtyShipped
				+ "\nAltOrderNum: " + AltOrderNum + "\nPartClientId: "+ PartClientId
				+ "\nOriginalClientOrderLineNum: "+OriginalClientOrderLineNum
				+"\nLSCoOrderLine: "+LSCoOrderLine
				+"\nClientOrderLine: "+ClientOrderLine+"\n\n";
		// return "";
	}
}
