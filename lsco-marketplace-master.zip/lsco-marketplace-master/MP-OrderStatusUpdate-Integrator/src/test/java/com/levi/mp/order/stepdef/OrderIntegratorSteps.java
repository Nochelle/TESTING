//package com.levi.mp.order.stepdef;
//
//import java.io.File;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.apache.commons.lang3.StringUtils;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//import org.json.simple.parser.ParseException;
//
//import com.fasterxml.jackson.core.JsonParseException;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.JsonMappingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.levi.mp.order.model.json.OrderCreationData;
//import com.levi.mp.order.model.json.UpdateSchemaForOrderCreate;
//import com.levi.mp.order.stepmethods.AccessTokenGenerator;
//import com.levi.mp.order.stepmethods.OrderIntegratorMethods;
//import com.levi.mp.order.stepmethods.PushOrdersInEOM;
//import com.levi.mp.order.stepmethods.UploadFileToS3;
//import com.levi.mp.order.util.CommonUtilities;
//
//import cucumber.api.PendingException;
//import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;
//import io.restassured.response.Response;
//
//
//public class OrderIntegratorSteps{
//                
//public OrderIntegratorMethods orderintegratormethods;
//public AccessTokenGenerator accessTokenGenerator;
//public PushOrdersInEOM pushOrdersInEOM;
//String orderId;
//String orderidres="";
//String siteOrderId="";
//String accessToken;
//String fullFilmentID;
//String channel;
//static List<String> doNumberList= new ArrayList<String>();
//static List<String> orderNumberList= new ArrayList<String>();
//List<OrderCreationData> orderUpdateData = new ArrayList<OrderCreationData>();
//ObjectMapper objectMapper = new ObjectMapper();     
//UpdateSchemaForOrderCreate createOrderDefault;
//UploadFileToS3 uploadFileToS3;
//
//
//    public OrderIntegratorSteps() throws IOException, ParseException{
//    orderintegratormethods = new OrderIntegratorMethods();
//    accessTokenGenerator = new AccessTokenGenerator();
//    pushOrdersInEOM = new PushOrdersInEOM();
//    uploadFileToS3=new UploadFileToS3();
//    accessToken= accessTokenGenerator.createNewAccessToken("testprops/testconfig.json", "testprops/RefreshTokenJSON.json");
//                    
//    }
//    @When("^Submit the POST request to create \"([^\"]*)\" order and validate$")
//    public void submit_the_POST_request_to_create_order_and_validate(String option) throws Throwable {
//    //AccessToken= accessTokenGenerator.createNewAccessToken("testprops/testconfig.json", "testprops/RefreshTokenJSON.json");
//    Response response = null;
//    JSONObject jo;
//    //if else
//    switch (option.trim().toLowerCase()) {
//    case "google":
//                    jo = orderintegratormethods.getJSONAttributeVal("testdata/order_create_google.json");
//                    response= orderintegratormethods.submit_the_POST_request_to_create_order_from_JSONOBJ("testprops/testconfig.json",accessToken,"",jo,"google");
//                    
//                    break;
//    case "facebook":
//                    jo = orderintegratormethods.getJSONAttributeVal("testdata/order_create_facebook.json");
//                    response= orderintegratormethods.submit_the_POST_request_to_create_order_from_JSONOBJ("testprops/testconfig.json",accessToken,"",jo,"facebook");
//                    
//                    break;
//    default:
//                    break;
//    }
//    orderidres= response.jsonPath().getString("SiteOrderID");
//    siteOrderId=response.jsonPath().getString("ID");               
//    channel=response.jsonPath().getString("SiteName");
//    }
//    @Then("^Update fulfillment details in order details json$")
//    public void patch_order_details_JSON_to_update_nodes() throws Throwable {
//
//    try {
//		if(!StringUtils.isBlank(siteOrderId)){                         
//		                fullFilmentID = orderintegratormethods.getFulfilmentID("testprops/testconfig.json",siteOrderId,accessToken);
//		orderintegratormethods.update_Patch("testprops/testconfig.json",fullFilmentID,accessToken,"testdata/fulfilment_patch.json");
//		orderintegratormethods.validate_after_Patch("testprops/testconfig.json",siteOrderId,accessToken,"testdata/fulfilment_patch.json");
//		}else if(!orderUpdateData.isEmpty()){
//		                for(int i=0; i<orderUpdateData.size(); i++){                                                                                                                                                           
//		                                fullFilmentID = orderintegratormethods.getFulfilmentID("testprops/testconfig.json",orderUpdateData.get(i).getOrderNumber().split("_")[0],accessToken);
//		                orderintegratormethods.update_Patch("testprops/testconfig.json",fullFilmentID,accessToken,"testdata/fulfilment_patch.json");
//		                orderintegratormethods.validate_after_Patch("testprops/testconfig.json",orderUpdateData.get(i).getOrderNumber().split("_")[0],accessToken,"testdata/fulfilment_patch.json");
//		                }
//		                
//		}else{
//		                // Write code here that to get CA ID from order ID
//		}
//	} catch (Exception e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//                    
//                    
//                    
//    }
//    @Then("^I validate order generated$")
//    public void i_validate_order_generated() throws Throwable {
//                    orderintegratormethods.validate_order_generated();
//    }
//
//    @Then("^the order details should be successfully validated in OMS$")
//    public void validate_the_order_in_EOM() throws Throwable {
//    Response res;                    
//    //orderidres="G-AUT-9876-55-3843";
//    CommonUtilities.sleep(120);
//    if(orderidres!=""){           
//                res=orderintegratormethods.validate_order_status_in_EOM("testprops/testconfig.json",orderidres,channel,"");
//                    orderNumberList.add(res.jsonPath().getString("customerOrder.orderNumber"));
//                    doNumberList.add(res.jsonPath().getString("customerOrder.doDetails.doDetail.doNbr"));
//    }else if(!orderUpdateData.isEmpty()){
//                    for(int i=0; i<orderUpdateData.size(); i++){
//                    res=orderintegratormethods.validate_order_status_in_EOM("testprops/testconfig.json",orderUpdateData.get(i).getOrderNumber().split("_")[1],orderUpdateData.get(i).getSiteName(),"");
//                                    orderNumberList.add(res.jsonPath().getString("customerOrder.orderNumber"));
//                                    doNumberList.add(res.jsonPath().getString("customerOrder.doDetails.doDetail.doNbr"));
//                                    //System.out.println(ONumberList.get(i));
//                                    //System.out.println(DONumberList.get(i));
//                    }
//    }
//    
//                    
//    }
//    @When("^Create new access token$")
//    public void create_new_access_token() throws IOException, ParseException{                         
//                    accessTokenGenerator.createNewAccessToken("testprops/testconfig.json", "testprops/RefreshTokenJSON.json");
//    }
//    @When("^Read order input data from CSV and place orders and validate$")
//    public void read_data_from_CSV() throws Exception{
//	Response res;
//	String orderId;
//	String siteOrderID;
//	String orderNCAID;
//	orderUpdateData = CommonUtilities.readNodesFromCSV(this.getClass().getClassLoader().getResource("").getPath().concat("testdata/testorder.csv").replaceFirst("/", ""));
//	
//	for(int i=0;i<orderUpdateData.size();i++){
//                try{
//                                if(orderUpdateData.get(i).getSiteName().toLowerCase().contains("google")){       
//                                    placeOrder(i,"google");
//                    }else if(orderUpdateData.get(i).getSiteName().toLowerCase().contains("facebook")){
//                                    placeOrder(i,"facebook");
//                                                
//                                }else{
//                                                
//                                }
//                }
//                catch(Exception e){
//                                
//                }
//                                                                
//}                              
//                    //objectMapper.writeValue(new File("D:\\MarketPlace\\testorderOut.csv"), orderCreationData);
//    //CommonUtilities.writeToCSV(System.getProperty("user.dir").concat("\\src\\test\\resources\\testdata\\testorderOut.csv"), orderUpdateData);;
//    CommonUtilities.writeToCSV(this.getClass().getClassLoader().getResource("").getPath().concat("testdata/testorderOut.csv").replaceFirst("/", ""),orderUpdateData);
//    
//                    
//    }
//    private void placeOrder(int i, String channel) throws IOException, JsonParseException,
//                                    JsonMappingException, JsonProcessingException, ParseException {
//    Response res;
//    String orderId;
//    String siteOrderID;
//    String orderNCAID;
//    createOrderDefault = objectMapper.readValue(new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream("testdata/order_create_"+channel+".json")),UpdateSchemaForOrderCreate.class);
//createOrderDefault.setShippingAddressLine1(orderUpdateData.get(i).getShippingAddress().toString().replaceAll(",", ""));
//    createOrderDefault.getItemList().get(0).setSku(orderUpdateData.get(i).getItem().toString().replaceAll(",", ""));                
//    
//    String jsonData = objectMapper.writeValueAsString(createOrderDefault);
//    Object configobj = new JSONParser().parse(jsonData);
//    JSONObject jconfigobj = (JSONObject) configobj;
//    
//    res = orderintegratormethods.submit_the_POST_request_to_create_order_from_JSONOBJ("testprops/testconfig.json",accessToken,"",jconfigobj,channel);
//    orderId=res.jsonPath().getString("ID");
//    siteOrderID=res.jsonPath().getString("SiteOrderID");
//    orderNCAID=orderId.concat("_").concat(siteOrderID);
//    orderUpdateData.get(i).setOrderNumber(orderNCAID);
//    //System.out.println(orderNCAID);
//    }
//    
//    @Then("^trigger lambda function to push orders to EOM$")
//    public void push_auto_generated_orders_to_EOM_triggiring_lambdaDevCode() throws IOException, ParseException{
//
//        if(!StringUtils.isBlank(siteOrderId)){         
//                        pushOrdersInEOM.processNewAutomatedOrders(siteOrderId,accessToken);
//        }else if(!orderUpdateData.isEmpty()){
//                        for(int i=0; i<orderUpdateData.size(); i++){
//                        pushOrdersInEOM.processNewAutomatedOrders(orderUpdateData.get(i).getOrderNumber().split("_")[0],accessToken);
//                        }
//        }
//
//    }
//    
//    @Then("^upload output csv files to S3$")
//    public void upload_files_to_S3() throws IOException, ParseException{
//                    uploadFileToS3.uploadFileToS3("us-west-2", "levi-marketplaces", "qadatafactory/testorderOut.csv");
//    }
//    
//                
//}
