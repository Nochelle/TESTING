package com.levi.mp.order.model.json;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * OrderLines Model class containing list of {@code OrderLine}
 * 
 * @author adhar@levi.com
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({ "orderLine" })
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderLines {

	@JsonProperty("orderLine")
	private List<OrderLine> orderLineList;

}
