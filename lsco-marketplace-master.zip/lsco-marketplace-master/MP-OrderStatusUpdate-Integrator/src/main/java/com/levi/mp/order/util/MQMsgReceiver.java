package com.levi.mp.order.util;

import java.util.ArrayList;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.QueueConnection;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.mq.jms.MQQueue;
import com.levi.mp.config.MQBeanHelper;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class MQMsgReceiver {

	@Autowired
	MQBeanHelper beanHelper;

	private QueueConnection queueConnection;

	private QueueSession queueSession;

	/**
	 * Get all the messages from MQ and return the list
	 * 
	 * @param config
	 * @return
	 */
	public List<String> receiveMQMsg() {
		List<String> msgList = new ArrayList<>();
		int waitSec = Integer.parseInt(beanHelper.getConfig().getOrderStatusUpdateConfig().getMqConfig().getWaitSecond());

		try {
			Message message = null;
			String txtMsg = null;
			QueueReceiver queueReceiver = this.createQueueReceiver();
			log.debug("Checking for any new MQ message>>>");

			while (true) {
				message = queueReceiver.receive(waitSec * 1000); // wait for 10 sec
				if (message != null) { // process next message
					if (message instanceof TextMessage) {
						txtMsg = ((TextMessage) message).getText();
						log.debug("Order status update tXML message>>>>\n" + txtMsg);
						msgList.add(txtMsg); // add each message to the list
					} else {
						log.error("***NOT a TextMessage***");
					}
				} else { // no more message, exit
					log.info("There are no more messages, exiting>>>");
					break;
				}
			} // end while loop

		} catch (JMSException e) {
			log.error("***JMSException while getting message from MQ***", e);
			throw new RuntimeException("JMSException while getting message from MQ", e);
		} catch (Throwable t) {
			log.error("***Exception while getting message from MQ***", t.getMessage());
			throw new RuntimeException("Exception while getting message from MQ", t);
		} finally {
			try {
				if (null != queueConnection) {
					queueConnection.close();
					log.info("JMS connection successfully closed...");
				}
			} catch (JMSException e) {
				log.error("***Exception while closing MQ connection***", e);
				throw new RuntimeException("***Exception while closing MQ connection***", e);
			}
		}

		return msgList;
	}

	private QueueReceiver createQueueReceiver() throws JMSException {
		QueueReceiver queueReceiver = null;

		try {

			/* Create Connection */
			queueConnection = beanHelper.getQueueConnection();
			queueConnection.start();

			/* Create session */
			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			/* Create receiver queue */
			MQQueue mqQueue = beanHelper.getMQQueue();
			queueReceiver = queueSession.createReceiver(mqQueue);
			log.debug("MQ connection successfully started for: " + beanHelper.getConfig().getOrderStatusUpdateConfig().getMqConfig().getMQHOST() + "::"
					+ beanHelper.getConfig().getOrderStatusUpdateConfig().getMqConfig().getMQCHANNEL() + "::"
					+ beanHelper.getConfig().getOrderStatusUpdateConfig().getMqConfig().getMQRECVQNAME());

			return queueReceiver;
		} catch (JMSException e) {
			log.error("***Exception while creating QueueReceiver: " + beanHelper.getConfig().getOrderStatusUpdateConfig().getMqConfig().getMQHOST() + "::"
					+ beanHelper.getConfig().getOrderStatusUpdateConfig().getMqConfig().getMQCHANNEL() + "::"
					+ beanHelper.getConfig().getOrderStatusUpdateConfig().getMqConfig().getMQRECVQNAME(), e);
			throw new RuntimeException(e);
		}

	}
}
