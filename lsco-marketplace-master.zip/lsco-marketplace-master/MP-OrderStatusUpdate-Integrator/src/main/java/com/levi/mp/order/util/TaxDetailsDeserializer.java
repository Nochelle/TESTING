package com.levi.mp.order.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.levi.mp.order.model.json.TaxDetail;
import com.levi.mp.order.model.json.TaxDetails;

/**
 * Custom Deserializer for OrderLines
 * 
 * @author Prabir Nandi
 *
 */
public class TaxDetailsDeserializer extends JsonDeserializer<TaxDetails> {

	@Override
	public TaxDetails deserialize(JsonParser p, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {

		TaxDetails taxDetails = null;
		ObjectMapper mapper = new ObjectMapper();

		JsonNode taxDetailsNode = p.getCodec().readTree(p);

		JsonNode taxDetailNode = taxDetailsNode.get("taxDetail");

		// If taxDetailsNode is an Array, parse it directly
		if (taxDetailNode instanceof ArrayNode) {

			taxDetails = mapper.readValue(taxDetailsNode.toString(), TaxDetails.class);

		} else { // Get the TaxDetail object and put in a List<OrderLine>

			TaxDetail taxDetail = mapper.readValue(taxDetailNode.toString(), TaxDetail.class);

			List<TaxDetail> taxDetailList = new ArrayList<>();
			taxDetailList.add(taxDetail);

			taxDetails = new TaxDetails();
			taxDetails.setTaxDetailList(taxDetailList);
		}

		return taxDetails;
	}

}
