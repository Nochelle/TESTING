package com.levi.mp.order.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.AmazonSQSException;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.levi.mp.config.OrderStatusUpdateLoadConfiguration;

import lombok.extern.log4j.Log4j2;

/**
 * 
 * @author Prabir Nandi
 *
 */
@Log4j2
@Service
public class SQSMessageService {
	
	@Autowired
	OrderStatusUpdateLoadConfiguration orderStatusUpdateLoadConfiguration;	
	
	@Autowired
	private AmazonSQS sqs;
	
	//final AmazonSQS sqs = AmazonSQSClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
	//final String QUEUE_NAME = "MP_STATUS_UPDATES"; 
	

	/**
	 * 
	 * @param message
	 */
	public void sendMessages(String message) {
		final SendMessageRequest messageRequest = new SendMessageRequest();
		
		String sqsQueueName = orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig().getSqsQueueName();
		
		String sqsMsgDelaySec = orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig().getSqsMsgDelaySec();
		
		String queueUrl = sqs.getQueueUrl(sqsQueueName).getQueueUrl();
		SendMessageRequest send_msg_request = messageRequest.withQueueUrl(queueUrl).withMessageBody(message)
				.withDelaySeconds(Integer.parseInt(sqsMsgDelaySec));
		sqs.sendMessage(send_msg_request);
		log.info("Message sent to SQS successfully, message:>>>\n"+message);
	}

	/**
	 * Receive messages from SQS
	 * @return
	 */
	public Map<String, String> getMessages() {
		String sqsQueueName = orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig().getSqsQueueName();
		
		ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest().
				withQueueUrl(sqsQueueName).withWaitTimeSeconds(10).withMaxNumberOfMessages(10);
		
		//receiveMessageRequest.setQueueUrl(sqsQueueName);
		//receiveMessageRequest.setMaxNumberOfMessages(10);
        //receiveMessageRequest.setWaitTimeSeconds(20);
		
		Map<String, String> sqsMsgMap = new HashMap<>();
		
		while(true) {
			List<Message> messages = sqs.receiveMessage(receiveMessageRequest).getMessages();
			log.debug("Queue depth size>>>"+messages.size());
			if(messages.size() == 0) break;
			
			for (Message m : messages) {
				log.debug("received message from SQS:>>>\n"+m.getBody());
				sqsMsgMap.put(m.getReceiptHandle(), m.getBody());
			}
		}
		
		return sqsMsgMap;
	}
	
	/**
	 * 
	 * @param receiptHandle
	 * @return
	 */
	public boolean deleteMessage(String receiptHandle) {
		//DeleteMessageResult result = 
		String sqsQueueName = orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig().getSqsQueueName();
		try {
			sqs.deleteMessage(sqs.getQueueUrl(sqsQueueName).getQueueUrl(), receiptHandle); // delete message from the queue
		} catch (AmazonSQSException e) {
			log.error("***Error ,not able to delete the message***"+receiptHandle, e);
			return Boolean.TRUE;
		}		
		log.debug("SQS Message deleted successfully");
		return Boolean.TRUE;
	}

	/*public static void main(String[] args) {
		SQSMessageService messageService = new SQSMessageService();
		//messageService.sendMessages("{\"Value_3\":{\"ShippedDateUtc\":\"2014-07-04T19:58:47.1Z\",\"TrackingNumber\":\"1Z 999 AA1 01 2345 6784\",\"SellerFulfillmentID\":\"FooBar\",\"DistributionCenterID\":0,\"DeliveryStatus\":\"Complete\",\"ShippingCarrier\":\"UPS\",\"ShippingClass\":\"Ground\",\"Items\":[{\"Sku\":\"ABC\",\"Quantity\":1}]}}");
		//messageService.sendMessages("{\"Value_4\":{\"ShippedDateUtc\":\"2014-07-04T19:58:47.1Z\",\"TrackingNumber\":\"1Z 999 AA1 01 2345 6785\",\"SellerFulfillmentID\":\"FooBar\",\"DistributionCenterID\":0,\"DeliveryStatus\":\"Complete\",\"ShippingCarrier\":\"UPS\",\"ShippingClass\":\"Ground\",\"Items\":[{\"Sku\":\"ABC\",\"Quantity\":1}]}}");
		
		messageService.getMessages();
		
		//messageService.deleteMessage("AQEB4mriUWH9p4v90SvC3FM3trb0PBtdLbrJCbcvTjuutgXeGjZ/aCpqlU2kPmKanv89rKgpt6EPLgwAOFff+bhYpKbXW15ZJ3nulvf8LYsutDLLAJwe3M4oYY+oOwUF9ZKTXhY/ed41/0KiCbhPzhKhvMBpp0K+F8ZwQ1EySlXakfibDACVwI0m1eZhat74IALtJIMTHPDujHa1aSE1HFSf+s0n/CnRvC2rR8bmJRLwN8u0W+D6R/QlyxGJoD2PVBXv+PxlUCbBVhPNsBmUmyN/CAw33l6aHXf6QX6G0HGO8sCXx5bSRaTgX9Ph/cq5GTY06Ce6baX3A7Iz5+fEdmkosuQwAw5CxIVN8Bv7JF1+yDiCdmZxJUJAONPJmMravqTehGGzqXBEEP0kd2wPJqlRpQ==");
	}*/

}
