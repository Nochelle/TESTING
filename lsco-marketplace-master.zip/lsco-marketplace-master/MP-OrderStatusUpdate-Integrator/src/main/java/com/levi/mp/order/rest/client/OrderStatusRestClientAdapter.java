package com.levi.mp.order.rest.client;

import java.io.IOException;
import java.util.Base64;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.config.OrderStatusUpdateLoadConfiguration;
import com.levi.mp.order.model.json.Adjustment;
import com.levi.mp.order.model.json.CustomerOrderDetail;
import com.levi.mp.order.model.json.OrderUpdateInfo;
import com.levi.mp.order.service.SQSMessageService;
import com.levi.mp.order.util.IConstants;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class OrderStatusRestClientAdapter {

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	@Qualifier("RestTemplateWithTimeout")
	private RestTemplate restTemplateWithTimeout;

	@Autowired
	SQSMessageService sqsMessageService;
	
	@Autowired
	SNSService snsService;
	
	@Autowired
	OrderStatusUpdateLoadConfiguration orderStatusUpdateLoadConfiguration;
	
	String errorMessage;
	String subject;

	/**
	 * Update Order ship status by calling CA Ship updateAPI
	 * 
	 * @param caOrderId
	 * @param shipment
	 * @return
	 * @throws IOException
	 */
	//public boolean updateShipStatus(String caOrderId, Shipment shipment, String caAccessToken) {
	public boolean updateShipStatus(OrderUpdateInfo shipment, String caAccessToken) {
		String shipURL = "https://api.channeladvisor.com/v1/Orders(" + shipment.getCaOrderID() 
							+ ")/Ship?access_token="+ caAccessToken;

		log.info("updating partial shipment status for CA Order id:>>>" + shipment.getCaOrderID() + 
				", URL:\n" + shipURL.substring(0, shipURL.indexOf("?access_token")));

		String bodyPayload = "";

		try {
			// setup header
			HttpHeaders headers = new HttpHeaders();
			headers.set("Content-Type", org.springframework.http.MediaType.APPLICATION_JSON_VALUE);

			bodyPayload = new ObjectMapper().writeValueAsString(shipment);
			log.debug("request body for partial shipment status update:\n" + bodyPayload);

			HttpEntity<?> httpEntityRequest = new HttpEntity<>(bodyPayload, headers);

			// make the rest call
			ResponseEntity<String> restResponse = restTemplate.exchange(shipURL, HttpMethod.POST, httpEntityRequest,
					String.class);

			log.info("Response StatusCode for partial shipment status:" + restResponse.getStatusCode());

			if (!restResponse.getStatusCode().equals(HttpStatus.NO_CONTENT)) {
				throw new RuntimeException("Error while updating partial shipment status update API, Response status: "
						+ restResponse.getStatusCode());
			}

			return Boolean.TRUE;
		} catch (HttpStatusCodeException e) {
			errorMessage = "HttpStatusCodeException(" + e.getRawStatusCode()
							+ ") while updating partial shipment status CA OrderId[" + shipment.getCaOrderID() + "],"
							+ "MarketplaceOrderID["+ shipment.getMarketPlaceOrderID()+"],"
							+ "MarketplaceOrderType["+shipment.getMarketPlaceorderType()+"]"+ System.lineSeparator()
							+ e.getResponseBodyAsString()+System.lineSeparator()+"Error Message:"+e.getMessage() 
							+ System.lineSeparator()+ "bodyPayload:"+bodyPayload;
			log.error(errorMessage);
			
			subject = "[MP-OrderStatusUpdate]:Error in partial shipment to CA OrderId["+shipment.getCaOrderID() +"]";
			notifySupportEmail(errorMessage, subject);
			
			if (IConstants.HTTP_STATUS_CODE_UNAUTHORIZED == e.getRawStatusCode() || String.valueOf(e.getRawStatusCode()).startsWith("5")) {
				handleErrorPartialShip(shipment);
			}
			
		} catch (Exception e) {
			errorMessage = "Exception while updating shipment status CA OrderId[" + shipment.getCaOrderID() + "],"
					+ "MarketplaceOrderID["+ shipment.getMarketPlaceOrderID()+"],MarketplaceOrderType["+shipment.getMarketPlaceorderType()+"]"
					+ System.lineSeparator()+"Error Message: "+e.getMessage() ;
			log.fatal(errorMessage, e);
			log.error("Exception request body for partial shipment status update:\n" + bodyPayload);
			
			subject = "[MP-OrderStatusUpdate]:Exception in partial shipment to CA OrderId["+shipment.getCaOrderID() +"]";
			notifySupportEmail(errorMessage, subject);
			
			handleErrorPartialShip(shipment);
		}

		return Boolean.FALSE;
	}

	private void handleErrorPartialShip(OrderUpdateInfo shipment) {

		shipment.setMessageType(IConstants.PARTIAL_SHIP_UPDATE);
		
		log.info("Sending failed Partial Ship Order Message for CA Order: "+shipment.getCaOrderID()+" to SQS for reprocessing...");
		try {
			 sqsMessageService.sendMessages(
					 new ObjectMapper().disable(MapperFeature.USE_ANNOTATIONS).writeValueAsString(shipment));
		} catch (Exception e1) {
			log.error("Exception while parsing ShipmentSQS>>>", e1);
			
			log.info("Sending notification to support team");
			//Notify Support
			String notificationMessage = 
					"Exception in sending Partial Ship Order Message to SQS for CA OrderId["+shipment.getCaOrderID()+"]"
					+" having MarketplaceOrderID["+ shipment.getMarketPlaceOrderID()+"]"
					+ " and MarketplaceOrderType["+shipment.getMarketPlaceorderType()+"]"
					+ System.lineSeparator()
					+"Error Message: "
					+ System .lineSeparator()
					+ExceptionUtils.getStackTrace(e1);	
			String subject = "[MP-OrderStatusUpdate]:Exception sending Partial Ship Order Message to SQS";
			
			snsService.notifySupport(notificationMessage, subject);
		}

	}

	/**
	 * Update Order line cancel status by calling CA Adjust API
	 * 
	 * @param caOrderLineId
	 * @param adjustment
	 * @return
	 * @throws IOException
	 */
	//public boolean updatePartialOrderCancelStatus(String caOrderLineId, Adjustment adjustment, String caAccessToken) {
	public boolean updatePartialOrderCancelStatus(OrderUpdateInfo adjustment, String caAccessToken) {

		String adjustURL = "https://api.channeladvisor.com/v1/OrderItems(" + adjustment.getCaOrderLineID() + ")/Adjust?access_token="
				+ caAccessToken;

		log.info("updating Partial Order Cancel status for CA OrderLineId id:>>>" + adjustment.getCaOrderLineID() + 
				", URL:\n" + adjustURL.substring(0, adjustURL.indexOf("?access_token")));

		String bodyPayload = "";

		try {
			// setup header
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			bodyPayload = new ObjectMapper().writeValueAsString(adjustment);
			log.debug("Request body for Partial Order Cancel status update:\n" + bodyPayload);

			HttpEntity<?> httpEntityRequest = new HttpEntity<>(bodyPayload, headers);

			// make the rest call
			ResponseEntity<String> restResponse = restTemplate.exchange(adjustURL, HttpMethod.POST, httpEntityRequest,
					String.class);

			log.info("Response StatusCode Partial Order Cancel:" + restResponse.getStatusCode());

			if (!restResponse.getStatusCode().equals(HttpStatus.NO_CONTENT)) {
				throw new RuntimeException("Error while calling Partial Order Cancel API, Response status: "
						+ restResponse.getStatusCode());
			}
			return Boolean.TRUE;

		} catch (HttpStatusCodeException e) {
			errorMessage = "HttpStatusCodeException(" + e.getRawStatusCode()
				+ ") while calling Partial Order Cancel API for caOrderLineId[" + adjustment.getCaOrderLineID() + "],"
						+"MarketplaceOrderID["+ adjustment.getMarketPlaceOrderID()+"],MarketplaceOrderType["+adjustment.getMarketPlaceorderType()+"]\n"
				+ e.getResponseBodyAsString()+"\nError Message:"+e.getMessage()
				+ System.lineSeparator()+ "bodyPayload:"+bodyPayload;
			
			log.error(errorMessage);
			subject = "[MP-OrderStatusUpdate]:Error in partial cancel to CA OrderLineId["+adjustment.getCaOrderLineID() +"]";
			notifySupportEmail(errorMessage, subject);
			
			if (IConstants.HTTP_STATUS_CODE_UNAUTHORIZED == e.getRawStatusCode() || String.valueOf(e.getRawStatusCode()).startsWith("5")) {
				handleErrorPartialOrderCancel((Adjustment)adjustment);
			}
		} catch (Exception e) {
			errorMessage = "Exception while Error while calling Partial Order Cancel API for caOrderLineId[" + adjustment.getCaOrderLineID()+ "],"
					+"MarketplaceOrderID["+ adjustment.getMarketPlaceOrderID()+"],MarketplaceOrderType["+adjustment.getMarketPlaceorderType()+"]"
					+ System.lineSeparator()+"Error Message: "+e.getMessage();
					
			log.fatal(errorMessage, e);
			log.error("Exception request body for partial Partial Order Cancel status update:\n" + bodyPayload);
			
			subject = "[MP-OrderStatusUpdate]:Exception in partial cancel to CA OrderLineId["+adjustment.getCaOrderLineID() +"]";
			notifySupportEmail(errorMessage, subject);
			
			handleErrorPartialOrderCancel((Adjustment)adjustment);
		}
		return Boolean.FALSE;
	}
	
	/**
	 * update return order status
	 * @param caOrderLineId
	 * @param adjustment
	 * @param caAccessToken
	 * @return
	 */
	public boolean updateReturnOrderStatus(OrderUpdateInfo adjustment, String caAccessToken) {

		String adjustURL = "https://api.channeladvisor.com/v1/OrderItems(" + adjustment.getCaOrderLineID() + ")/Adjust?access_token="
				+ caAccessToken;

		log.info("updating return order status for CA OrderLineId id:>>>" + adjustment.getCaOrderLineID() + 
				", URL:\n" + adjustURL.substring(0, adjustURL.indexOf("?access_token")));

		String bodyPayload = "";

		try {
			// setup header
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			bodyPayload = new ObjectMapper().writeValueAsString(adjustment);
			log.debug("Request body for return order status update:\n" + bodyPayload);

			HttpEntity<?> httpEntityRequest = new HttpEntity<>(bodyPayload, headers);

			// make the rest call
			ResponseEntity<String> restResponse = restTemplate.exchange(adjustURL, HttpMethod.POST, httpEntityRequest,
					String.class);

			log.info("Response StatusCode return order:" + restResponse.getStatusCode());

			if (!restResponse.getStatusCode().equals(HttpStatus.NO_CONTENT)) {
				/*log.error("Error while calling return order API, Response status: "
						+ restResponse.getStatusCode());*/
				throw new RuntimeException("Error while calling return order API, Response status: "
						+ restResponse.getStatusCode());
			}
			return Boolean.TRUE;

		} catch (HttpStatusCodeException e) {
			errorMessage = "HttpStatusCodeException(" + e.getRawStatusCode()
			+ ") while calling return order API for caOrderLineId[" + adjustment.getCaOrderLineID() + "],"+
					"MarketplaceOrderID["+ adjustment.getMarketPlaceOrderID()+"],MarketplaceOrderType["+adjustment.getMarketPlaceorderType()+"]\n"
			+ e.getResponseBodyAsString()+"\nError Message:"+e.getMessage()
			+ System.lineSeparator()+ "bodyPayload:"+bodyPayload;
			
			log.error(errorMessage);
			
			subject = "[MP-OrderStatusUpdate]:Error in update return order to CA OrderId["+adjustment.getCaOrderLineID() +"]";
			notifySupportEmail(errorMessage, subject);
			
			if (IConstants.HTTP_STATUS_CODE_UNAUTHORIZED == e.getRawStatusCode() || String.valueOf(e.getRawStatusCode()).startsWith("5")) {
				handleErrorReturnOrder((Adjustment)adjustment);
			}
		} catch (Exception e) {
			errorMessage = "Exception while Error while calling return order API for caOrderLineId[" + adjustment.getCaOrderLineID()+ "],"+
							"MarketplaceOrderID["+ adjustment.getMarketPlaceOrderID()+"],MarketplaceOrderType["+adjustment.getMarketPlaceorderType()+"]"
							+ System.lineSeparator()+"Error Message: "+e.getMessage();;
					
			log.fatal(errorMessage, e);
			log.error("Exception request body for partial return order status update:\n" + bodyPayload);
			
			subject = "[MP-OrderStatusUpdate]:Exception in update return order to CA OrderId["+adjustment.getCaOrderLineID() +"]";
			notifySupportEmail(errorMessage, subject);
			
			handleErrorReturnOrder((Adjustment)adjustment);
		}
		return Boolean.FALSE;
	}

	private void handleErrorReturnOrder(Adjustment adjustment) {
		adjustment.setMessageType(IConstants.PARTIAL_RETURN_UPDATE);
		log.info("Sending failed Partial Return Order message for CA OrderLineId: "+adjustment.getCaOrderLineID()+" to SQS  for reprocessing...");
		try {
			sqsMessageService.sendMessages(
					new ObjectMapper().disable(MapperFeature.USE_ANNOTATIONS).writeValueAsString(adjustment));
		} catch (Exception e1) {
			log.error("Exception while parsing Return Order adjustmentSQS>>>", e1);
			
			log.info("Sending notification to support team");
			//Notify Support
			String notificationMessage = 
					"Exception in sending Return Order Message to SQS for caOrderLineId["+adjustment.getCaOrderLineID()+"]"
					+" having MarketplaceOrderID["+ adjustment.getMarketPlaceOrderID()+"]"
					+ " and MarketplaceOrderType["+adjustment.getMarketPlaceorderType()+"]"
					+ System.lineSeparator()
					+"Error Message: "
					+ System .lineSeparator()
					+ExceptionUtils.getStackTrace(e1);	
			String subject = "[MP-OrderStatusUpdate]:Exception sending Return Order Message to SQS";
			
			snsService.notifySupport(notificationMessage, subject);
		}
	}

	private void handleErrorPartialOrderCancel(Adjustment adjustment) {
		adjustment.setMessageType(IConstants.PARTIAL_CANCEL_UPDATE);
		log.info("Sending failed Partial Order Cancel message for CA OrderLineId: "+adjustment.getCaOrderLineID()+" to SQS for reprocessing...");
		try {
			sqsMessageService.sendMessages(
					new ObjectMapper().disable(MapperFeature.USE_ANNOTATIONS).writeValueAsString(adjustment));
		} catch (Exception e1) {
			log.error("Exception while parsing PartialOrderCancel adjustmentSQS>>>", e1);
			
			log.info("Sending notification to support team");
			//Notify Support
			String notificationMessage = 
					"Exception in sending Partial Order Cancel Message to SQS for caOrderLineId["+adjustment.getCaOrderLineID()+"]"
					+" having MarketplaceOrderID["+ adjustment.getMarketPlaceOrderID()+"]"
					+ " and MarketplaceOrderType["+adjustment.getMarketPlaceorderType()+"]"
					+ System.lineSeparator()
					+"Error Message: "
					+ System .lineSeparator()
					+ExceptionUtils.getStackTrace(e1);	
			String subject = "[MP-OrderStatusUpdate]:Exception in sending Partial Order Cancel Message to SQS";
			
			snsService.notifySupport(notificationMessage, subject);
		}

	}

	/**
	 * Full Order Cancel request to CA
	 * 
	 * @param caOrderId
	 * @param caAccessToken
	 */
	public boolean updateFullOrderCancelStatus(OrderUpdateInfo adjustment, String caAccessToken) {
		String fullOrderCancelURL = "https://api.channeladvisor.com/v1/Orders(" + adjustment.getCaOrderID() + ")/Adjust?access_token="
				+ caAccessToken;
		// setup header
		log.info("updating FULL Order cancel status for CA Order id:>>>" + adjustment.getCaOrderID() + 
				", URL:\n" + fullOrderCancelURL.substring(0, fullOrderCancelURL.indexOf("?access_token")));

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<?> httpEntityRequest = new HttpEntity<>(headers);

			// make the rest call
			ResponseEntity<String> restResponse = restTemplate.exchange(fullOrderCancelURL, HttpMethod.POST,
					httpEntityRequest, String.class);

			log.info("Response StatusCode for FULL Order cancel:" + restResponse.getStatusCode());

			if (!restResponse.getStatusCode().equals(HttpStatus.NO_CONTENT)) {
				/*log.error("Error while calling FULL Order cancel API, Response status: "
						+ restResponse.getStatusCode());*/
				throw new RuntimeException("Error while calling FULL Order cancel API, Response status: "
						+ restResponse.getStatusCode());
			}
			return Boolean.TRUE;
		} catch (HttpStatusCodeException e) {
			errorMessage = "HttpStatusCodeException(" + e.getRawStatusCode()
			+ ") while calling FULL Order cancel for CA Order id[" + adjustment.getCaOrderID() + "],"
					+"MarketplaceOrderID["+ adjustment.getMarketPlaceOrderID()+"],MarketplaceOrderType["+adjustment.getMarketPlaceorderType()+"]"
			+ e.getResponseBodyAsString()+"\nError Message:"+e.getMessage();
			
			log.error(errorMessage);
			
			subject = "[MP-OrderStatusUpdate]:Error in full order cancel to CA OrderId["+adjustment.getCaOrderID() +"]";
			notifySupportEmail(errorMessage, subject);
			
			if (IConstants.HTTP_STATUS_CODE_UNAUTHORIZED == e.getRawStatusCode() || String.valueOf(e.getRawStatusCode()).startsWith("5")) {
				handleErrorFullOrderCancel(adjustment);
			}
			
		} catch (Exception e) {
			errorMessage = "Exception while calling FULL Order cancel for CA Order id[" + adjustment.getCaOrderID() + "],"
							+"MarketplaceOrderID["+ adjustment.getMarketPlaceOrderID()+"],MarketplaceOrderType["+adjustment.getMarketPlaceorderType()+"]"
							+ System.lineSeparator() + "Error Message: "+ e.getMessage();
			log.fatal(errorMessage, e);
			
			subject = "[MP-OrderStatusUpdate]:Exception in full order cancel to CA OrderId["+adjustment.getCaOrderID() +"]";
			notifySupportEmail(errorMessage, subject);

			handleErrorFullOrderCancel(adjustment);
		}
		return Boolean.FALSE;
	}

	private void handleErrorFullOrderCancel(OrderUpdateInfo adjustment) {
		adjustment.setMessageType(IConstants.FULL_CANCEL_UPDATE);
		log.info("Sending failed Full Order Cancel Message for CA OrderId: "+adjustment.getCaOrderID()+" to SQS for reprocessing...");
		try {
			sqsMessageService.sendMessages(
					new ObjectMapper().disable(MapperFeature.USE_ANNOTATIONS).writeValueAsString(adjustment));
		} catch (Exception e1) {
			log.error("JsonProcessingException while parsing FullOrderCancel adjustmentSQS>>>", e1);
			
			log.info("Sending notification to support team");
			//Notify Support
			String notificationMessage = 
					"Exception in sending Full Order Cancel Message to SQS for caOrderId["+adjustment.getCaOrderID()+"]"
					+" having MarketplaceOrderID["+ adjustment.getMarketPlaceOrderID()+"]"
					+ " and MarketplaceOrderType["+adjustment.getMarketPlaceorderType()+"]"
					+ System.lineSeparator()
					+"Error Message: "
					+ System .lineSeparator()
					+ExceptionUtils.getStackTrace(e1);	
			String subject = "[MP-OrderStatusUpdate]:Exception in sending Full Order Cancel Message to SQS";
			
			snsService.notifySupport(notificationMessage, subject);
		}
		
	}
	
	
	/**
	 * Method to fetch {@code CustomerOrderDetail} for an EOM order
	 * 
	 * @param orderNoEOM
	 * @param authTokenMap
	 * @return {@code CustomerOrderDetail}
	 */
	public CustomerOrderDetail fetchCustomerOrderDetailsFromEOM(String orderNoEOM) {

		String url = orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig().getLeviEOMHost()
				+ "/services/olm/customerorder/customerOrderDetails";
		
		String userName = orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig().getLeviEOMUserName();
		String passwd = orderStatusUpdateLoadConfiguration.getOrderStatusUpdateConfig().getLeviEOMPasswd();

		try {

			HttpHeaders requestHeaders = new HttpHeaders();
			requestHeaders.setContentType(MediaType.APPLICATION_JSON);

			String auth = userName + ":" + passwd;
			byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes());
			String authHeader = "Basic " + new String(encodedAuth);
			requestHeaders.add("Authorization", authHeader);

			HttpEntity<String> requestEntity = new HttpEntity<>(requestHeaders);

			UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(url)
					.queryParam("responseType", "FullCustomerOrder").queryParam("customerOrderNumber", orderNoEOM);

			log.info("Invoking LEVI EOM API for customer order details with url: "
					+ uriComponentsBuilder.build().toString());

			ResponseEntity<String> responseEntity = restTemplateWithTimeout.exchange(uriComponentsBuilder.build().toString(),
					HttpMethod.GET, requestEntity, String.class);

			HttpStatus responseStatus = responseEntity.getStatusCode();
			String responseBody = responseEntity.getBody();

			log.info("LEVI EOM API customer order details response status: " + responseStatus.value());
			log.debug("LEVI EOM API customer order details response content:" + responseBody);

			if (!responseStatus.equals(HttpStatus.OK)) {
				throw new RuntimeException("Unsuccessful response from LEVI EOM API for customer order details!");
			}
			
			CustomerOrderDetail customerOrderDetail = new ObjectMapper()
					.readValue(responseBody, CustomerOrderDetail.class);
			
			if (customerOrderDetail == null 
					|| customerOrderDetail.getCustomerOrder() == null
					|| customerOrderDetail.getCustomerOrder().getOrderLines() == null
					|| customerOrderDetail.getCustomerOrder().getOrderLines().getOrderLineList( )== null
					|| customerOrderDetail.getCustomerOrder().getOrderLines().getOrderLineList().isEmpty()) {
				
				throw new RuntimeException("Customer order details could not be parsed from LEVI EOM API response!");
			}
			
			return customerOrderDetail;

		} catch (Exception e) {
			// log.fatal("Exception occurred while fetching extOrderLineId from EOM for EOM
			// Order: " + orderNoEOM, e);
			throw new RuntimeException(
					"Exception occurred while fetching customer order details for EOM Order: " + orderNoEOM, e);
		}

	}

	/**
	 * Update FULL Order Return
	 * @param externalOrderNumber
	 * @param adustmentForFullRetun
	 * @param caAccessToken
	 * @return
	 */
	public boolean updateFullReturnOrderStatus(Adjustment adustmentForFullReturn,
			String caAccessToken) {
		String adjustFullReturnURL = "https://api.channeladvisor.com/v1/Orders(" + adustmentForFullReturn.getCaOrderID() + ")/Adjust?access_token="
				+ caAccessToken;

		log.info("updating Full return status for CA Order id:>>>" + adustmentForFullReturn.getCaOrderID() + 
				", URL:\n" + adjustFullReturnURL.substring(0, adjustFullReturnURL.indexOf("?access_token")));

		String bodyPayload = "";

		try {
			// setup header
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			bodyPayload = new ObjectMapper().writeValueAsString(adustmentForFullReturn);
			log.debug("Request body for Full return order status update:\n" + bodyPayload);

			HttpEntity<?> httpEntityRequest = new HttpEntity<>(bodyPayload, headers);

			// make the rest call
			ResponseEntity<String> restResponse = restTemplate.exchange(adjustFullReturnURL, HttpMethod.POST, httpEntityRequest,
					String.class);

			log.info("Response StatusCode Full return order:" + restResponse.getStatusCode());

			if (!restResponse.getStatusCode().equals(HttpStatus.NO_CONTENT)) {
				/*log.error("Error while calling Full return order API, Response status: "
						+ restResponse.getStatusCode());*/
				throw new RuntimeException("Error while calling Full return order API, Response status: "
						+ restResponse.getStatusCode());
			}
			return Boolean.TRUE;

		} catch (HttpStatusCodeException e) {
			errorMessage = "HttpStatusCodeException(" + e.getRawStatusCode()
			+ ") while calling FULL return order API for CA Order Id[" + adustmentForFullReturn.getCaOrderID() + "],"
					+"MarketplaceOrderID["+ adustmentForFullReturn.getMarketPlaceOrderID()+"],"
					+ "MarketplaceOrderType["+adustmentForFullReturn.getMarketPlaceorderType()+"]\n"
			+ e.getResponseBodyAsString()+"\nError Message:"+e.getMessage()
			+ System.lineSeparator()+ "bodyPayload:"+bodyPayload;
			
			log.error(errorMessage);
			
			subject = "[MP-OrderStatusUpdate]:Error in full return order to CA OrderId["+adustmentForFullReturn.getCaOrderID() +"]";
			notifySupportEmail(errorMessage, subject);
			
			if (IConstants.HTTP_STATUS_CODE_UNAUTHORIZED == e.getRawStatusCode() || String.valueOf(e.getRawStatusCode()).startsWith("5")) {
				handleErrorFullRetrunOrder(adustmentForFullReturn);
			}
			
		} catch (Exception e) {
			errorMessage = "Exception while Error while calling FULL return order API for CA Order Id[" + adustmentForFullReturn.getCaOrderID()+ "],"
					+"MarketplaceOrderID["+ adustmentForFullReturn.getMarketPlaceOrderID()+"]"
					+ "MarketplaceOrderType["+adustmentForFullReturn.getMarketPlaceorderType()+"]"
					+ System.lineSeparator() + "Error Message: "+ e.getMessage();
			log.fatal(errorMessage, e);
			log.error("Exception request body for FULL return order status update:\n" + bodyPayload);
			
			subject = "[MP-OrderStatusUpdate]:Exception in full return order to CA OrderId["+adustmentForFullReturn.getCaOrderID() +"]";
			notifySupportEmail(errorMessage, subject);
			
			handleErrorFullRetrunOrder(adustmentForFullReturn);
		}
		return Boolean.FALSE;
		
	}

	/**
	 * 
	 * @param externalOrderNumber
	 * @param adustmentForFullRetun
	 */
	private void handleErrorFullRetrunOrder(Adjustment adjustmentForFullReturn) {
		adjustmentForFullReturn.setMessageType(IConstants.FULL_RETURN_UPDATE);
		log.info("Sending failed Full Order Return Message for CA OrderId: "+adjustmentForFullReturn.getCaOrderID()+" to SQS for reprocessing...");
		try {
			sqsMessageService.sendMessages(
					new ObjectMapper().disable(MapperFeature.USE_ANNOTATIONS).writeValueAsString(adjustmentForFullReturn));
		} catch (Exception e1) {
			log.error("Exception while parsing Full Order Return adjustmentSQS>>>", e1);
			
			log.info("Sending notification to support team");
			//Notify Support
			String notificationMessage = 
					"Exception in sending Full Order Return Message to SQS for CA Order ID["+adjustmentForFullReturn.getCaOrderID()+"]"
					+" having MarketplaceOrderID["+ adjustmentForFullReturn.getMarketPlaceOrderID()+"]"
					+ " and MarketplaceOrderType["+adjustmentForFullReturn.getMarketPlaceorderType()+"]"
					+ System.lineSeparator()
					+"Error Message: "
					+ System .lineSeparator()
					+ExceptionUtils.getStackTrace(e1);	
			String subject = "[MP-OrderStatusUpdate]:Exception in sending Full Order Return Message to SQS";
			
			snsService.notifySupport(notificationMessage, subject);
		}
		
	}
	
	public void notifySupportEmail(String body, String subject) {
		snsService.notifySupport(body, subject); // send only email
	}
}
