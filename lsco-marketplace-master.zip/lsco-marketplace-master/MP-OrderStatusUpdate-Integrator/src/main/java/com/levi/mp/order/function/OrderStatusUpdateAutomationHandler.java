package com.levi.mp.order.function;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.order.service.OrderStatusService;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class OrderStatusUpdateAutomationHandler {

	ApplicationContext getApplicationContext() {
		return new AnnotationConfigApplicationContext("com.levi.mp");
	}
	public String handleRequest() {
		log.info("OrderStatusUpdateHandler stared>>>");
		try {			
			orderStatusService = getApplicationContext().getBean(OrderStatusService.class);
			
			orderStatusService.reprocessUpdateOrderStatus(); // process from SQS
			orderStatusService.updateOrderStatus(); // process from MQ
			//log.info("OrderStatusUpdateHandler successfully executed>>>");
			
			
			//Change for printing process info in lambda output
			String processInfo = 
					"OrderStatusUpdateHandler successfully executed>>>"
					+System.lineSeparator()
					+"-----OrderStatusUpdate Process Statistics:-----"
					+ System.lineSeparator()
					+orderStatusService.getOrderStatusUpdateProcessInfo(); 
			
			return processInfo;
			
		} catch (Exception e) {
			log.error("***Exception while updating order status"+e.getMessage());
			
			return "Exception while updating order status: " + e.getMessage();
		}
		//return "OrderStatusUpdateHandler successfully executed";
	}

	@Autowired
	private OrderStatusService orderStatusService;
	

}
