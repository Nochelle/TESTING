package com.levi.mp.order.util;

public interface IConstants {
	
	public String DATE_FORMART_WITH_MS = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public String CST_DATE_FORMAT = "MM/dd/yyyy";
	
	public String ORDER_TYPE_GOOGLE = "OT_GOOGLE";
	public String ORDER_TYPE_FB = "OT_FB";
	
	public String CANCEL_REASON = "ItemNotAvailable"; // BuyerCancelled
	public String ADJUSTMENT_ID = "AdjustmentID-";
	
	public String RETURN_REASON = "CustomerReturnedItem";
	
	public String PARTIAL_SHIP_UPDATE = "PARTIAL_SHIP_UPDATE";
	public String PARTIAL_CANCEL_UPDATE = "PARTIAL_CANCEL_UPDATE";
	public String PARTIAL_RETURN_UPDATE = "PARTIAL_RETURN_UPDATE";
	public String FULL_RETURN_UPDATE = "FULL_RETURN_UPDATE";
	public String FULL_CANCEL_UPDATE = "FULL_CANCEL_UPDATE";
	public int HTTP_STATUS_CODE_UNAUTHORIZED = 401;
	public String SHIPPING_ADJUSTMENT = "ShippingAdjustment";
	public String SHIPPING_TAX_ADJUSTMENT = "ShippingTaxAdjustment";
	
	public String SUCESS = "SUCCESS";
	public String FAILURE = "FAILURE";
	
}
