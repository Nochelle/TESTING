
package com.levi.mp.order.model.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Value"
})
@Data
@EqualsAndHashCode(callSuper=true)
@NoArgsConstructor
@JsonIgnoreProperties(
	value= {
			"caOrderID", 
			"caOrderLineID",
			"marketPlaceOrderID",
			"returnOrderNo",
			"marketPlaceorderType",
			"messageType"
		}
	)
public class Shipment extends OrderUpdateInfo{
    @JsonProperty("Value")
    private ShipDetail value;

}
