package com.levi.mp.order.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.levi.mp.order.model.json.OrderLine;
import com.levi.mp.order.model.json.OrderLines;

/**
 * Custom Deserializer for OrderLines
 * 
 * @author adhar@levi.com
 *
 */
public class OrderLinesDeserializer extends JsonDeserializer<OrderLines> {

	@Override
	public OrderLines deserialize(JsonParser p, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {

		OrderLines orderLines = null;
		ObjectMapper mapper = new ObjectMapper();

		JsonNode orderLinesNode = p.getCodec().readTree(p);

		JsonNode orderLineNode = orderLinesNode.get("orderLine");

		// If orderLineNode is an Array, parse it directly
		if (orderLineNode instanceof ArrayNode) {

			orderLines = mapper.readValue(orderLinesNode.toString(), OrderLines.class);

		} else { // Get the orderLine object and put in a List<OrderLine>

			OrderLine orderLine = mapper.readValue(orderLineNode.toString(), OrderLine.class);

			List<OrderLine> orderLineList = new ArrayList<>();
			orderLineList.add(orderLine);

			orderLines = new OrderLines();
			orderLines.setOrderLineList(orderLineList);
		}

		return orderLines;
	}

}
