package com.levi.mp.order.model.json;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
@JsonPropertyOrder({
	"chargeCategory", "chargeAmount"
})
@Data
public class ChargeDetail {
	@JsonProperty("chargeCategory")
    private String chargeCategory;
	
	@JsonProperty("chargeAmount")
    private BigDecimal chargeAmount;
}
