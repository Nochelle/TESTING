package com.levi.mp.order.util;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.springframework.stereotype.Component;

import com.levi.mp.order.model.json.Adjustment;
import com.levi.mp.order.model.json.OrderUpdateInfo;
import com.levi.mp.order.model.json.ChargeDetail;
import com.levi.mp.order.model.json.CustomerOrderDetail;
import com.levi.mp.order.model.json.Item;
import com.levi.mp.order.model.json.ShipDetail;
import com.levi.mp.order.model.json.Shipment;
import com.levi.mp.order.model.json.TaxDetail;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines.OrderLine;
import com.levi.mp.order.model.xml.TXML.Message.Order.ShipmentDetails.ShipmentDetail;
import com.levi.mp.order.model.xml.TXML.Message.Order.ShipmentDetails.ShipmentDetail.Cartons.Carton;
import com.levi.mp.order.model.xml.TXML.Message.Order.ShipmentDetails.ShipmentDetail.Cartons.Carton.CartonDetails.CartonDetail;
import com.levi.mp.order.retn.model.xml.TXML.Message.ReturnOrder.ReturnOrderLines;
import com.levi.mp.order.retn.model.xml.TXML.Message.ReturnOrder.ReturnOrderLines.ReturnOrderLine;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class OrderStatusUpdateUtil {
	
	/**
	 * 
	 * @param orderLines
	 * @return
	 */
	public List<Adjustment> getReturns(OrderUpdateInfo orderUpdateInfo, ReturnOrderLines returnOrderLines, Map<String, String> respMap) {
		List<Adjustment> adjustmentList = new ArrayList<>();
		Adjustment adjustment;
		
		//for each pc13 match with EOM customerOrderDetails API response
		//call EOM customerOrderDetails API, match with pc13 and get the extLineId 
		
		String extLineId = "";
		BigDecimal shippingAdjustment = new BigDecimal("0.00");
		BigDecimal shippingTaxAdjustment = new BigDecimal("0.00");
		BigDecimal originalReturnQty;
		
		for (ReturnOrderLine returnOrderLine : returnOrderLines.getReturnOrderLine()) {
			originalReturnQty = returnOrderLine.getQuantity().getOriginalReturnQty();
			extLineId = respMap.get(returnOrderLine.getItemID());
			//log.debug("pc13:"+returnOrderLine.getItemID());
			//log.debug("OriginalOrderedQty:"+originalReturnQty.intValue());
			
			adjustment = new Adjustment();
			adjustment.setReason("CustomerReturnedItem");
			adjustment.setSellerAdjustmentID(IConstants.ADJUSTMENT_ID+orderUpdateInfo.getCaOrderID()+"-"+extLineId+"-"+orderUpdateInfo.getReturnOrderNo());
			adjustment.setQuantity(originalReturnQty.intValue());
			
			// set shipping adjustment to zero so CA don't refund back shipping charge and shipping tax to customer
			shippingAdjustment = originalReturnQty.multiply(new BigDecimal(respMap.get(IConstants.SHIPPING_ADJUSTMENT)));
			if(shippingAdjustment.signum()!=0) {
				adjustment.setShippingAdjustment(new BigDecimal("0"));
			}
			
			shippingTaxAdjustment = originalReturnQty.multiply(new BigDecimal(respMap.get(IConstants.SHIPPING_TAX_ADJUSTMENT)));
			if(shippingTaxAdjustment.signum()!=0) {
				adjustment.setShippingTaxAdjustment(new BigDecimal("0"));
			}
			
			if(shippingAdjustment.signum()!=0 || shippingTaxAdjustment.signum()!=0) {
				adjustment.setForceCalculateOmittedAmounts(Boolean.TRUE);
			}
			
			adjustment.setCaOrderID(orderUpdateInfo.getCaOrderID());
			adjustment.setMarketPlaceOrderID(orderUpdateInfo.getMarketPlaceOrderID());
			adjustment.setMarketPlaceorderType(orderUpdateInfo.getMarketPlaceorderType());
			adjustment.setReturnOrderNo(orderUpdateInfo.getReturnOrderNo());
			adjustment.setCaOrderLineID(extLineId);
			
			adjustmentList.add(adjustment);
			
		}
		
		return adjustmentList;
	}

	/**
	 * 
	 * @param orderLines
	 * @param caOrderId
	 * @return
	 */
	public List<Adjustment> getCancellations(OrderUpdateInfo orderUpdateInfo, OrderLines orderLines) {
		List<Adjustment> adjustmentList = new ArrayList<>();
		String newCancelQty;
		Adjustment adjustment;
		
    	//prepare for Cancellation Status Update request to CA
    	for(OrderLine orderLine : orderLines.getOrderLine()) {
			newCancelQty = orderLine.getQuantity().getNewCancelledQty().getValue();
    		//:TODO temporary
			//newCancelQty = orderLine.getQuantity().getTotalCancelledQty().getValue();
			adjustment = new Adjustment();
    		if((new Double(newCancelQty).intValue())>0) { // make a Adjust POST call if newCalcelQty > 0
    			//POST https://api.channeladvisor.com/v1/OrderItems(Message:Order:OrderLines:OrderLine:ExternalLineID)/Adjust?access_token=xxxxxxxxxx 
    			adjustment.setReason("ItemNotAvailable");
    			adjustment.setSellerAdjustmentID(IConstants.ADJUSTMENT_ID+orderUpdateInfo.getCaOrderID()+"-"+orderLine.getExternalLineID().getValue());
    			adjustment.setQuantity(new Double(newCancelQty).intValue());
    			
    			adjustment.setCaOrderID(orderUpdateInfo.getCaOrderID());
    			adjustment.setCaOrderLineID(orderLine.getExternalLineID().getValue());
    			adjustment.setMarketPlaceOrderID(orderUpdateInfo.getMarketPlaceOrderID());
    			adjustment.setMarketPlaceorderType(orderUpdateInfo.getMarketPlaceorderType());
    			
    			adjustmentList.add(adjustment);
        	}
    	}
		return adjustmentList;
	}

	/**
	 * Iterate Cartons to update the shipment status of the order 
	 * @param config
	 * @param externalOrderNumber
	 * @param shipmentDetail
	 * @throws ParseException 
	 */
	public List<Shipment> getShipments(OrderUpdateInfo orderUpdateInfo, ShipmentDetail shipmentDetail) {
		List<Shipment> shipmentList = new ArrayList<>();
		Shipment shipment;
		ShipDetail shipDetail;
		List<Item> items;
		
		try {
			for (Carton carton : shipmentDetail.getCartons().getCarton()) {
        		String processShipment = carton.getProcessShipment();
        		//log.debug("***getDONbr>>"+carton.getDONbr()+",processShipment:"+processShipment);
        		// if processShipment is true , then consider this as a new shipment
        		if("true".equalsIgnoreCase(processShipment)) {
            		
        			shipment = new Shipment();
        			shipDetail = new ShipDetail();
        			//Change for proper formatting of Date
        			shipDetail.setShippedDateUtc(OrderStatusUpdateUtil.convertDateToDateTime(
        					carton.getShipDate().getValue(), new SimpleDateFormat(IConstants.CST_DATE_FORMAT)));
        			shipDetail.setTrackingNumber(carton.getTrackingNbr().getValue());
        			shipDetail.setSellerFulfillmentID(carton.getShipmentNbr());
        			//shipDetail.setDistributionCenterID(carton.getReferenceField3().getValue());
        			shipDetail.setDistributionCenterID("0");
        			shipDetail.setDeliveryStatus("Complete");
        			shipDetail.setShippingCarrier(carton.getCarrier().getValue());
        			shipDetail.setShippingClass(carton.getShipVia().getValue());
        			
        			items = new ArrayList<>();
        			Item item = null;
            		for(CartonDetail cartonDetail : carton.getCartonDetails().getCartonDetail()) {
            			item = new Item();
            			item.setSku(cartonDetail.getItemID());
            			item.setQuantity(cartonDetail.getQuantity().intValue());
            			items.add(item);
            		}
            		
            		shipDetail.setItems(items);
            		shipment.setValue(shipDetail);
            		
            		shipment.setCaOrderID(orderUpdateInfo.getCaOrderID());
            		shipment.setMarketPlaceOrderID(orderUpdateInfo.getMarketPlaceOrderID());
            		shipment.setMarketPlaceorderType(orderUpdateInfo.getMarketPlaceorderType());
            		
            		shipmentList.add(shipment);
            		
        		}else {
        			log.info("skip, not a new shipment update, getDONbr:"+carton.getDONbr()
        					+", caOrderID:"+orderUpdateInfo.getCaOrderID()+", marketPlaceOrderID:"+orderUpdateInfo.getMarketPlaceOrderID());
        		}
    		}
		} catch (Exception e) {
			log.fatal("Exception occurred while buiding ShipmentDetail caOrderID:"
					+orderUpdateInfo.getCaOrderID()+", marketPlaceOrderID:"+orderUpdateInfo.getMarketPlaceOrderID(), e);
			throw new RuntimeException("Exception occurred while buiding ShipmentDetail",e);
		}
		return shipmentList;
		
	}
	
	/**
	 * Method to get the String content of a file
	 * 
	 * @param absoulteFileName
	 * @return the String content of the file
	 */
	public static String readFile(String absoulteFileName) {

		try (Stream<String> stream = Files.lines(Paths.get(absoulteFileName), StandardCharsets.ISO_8859_1)) {
			StringBuffer fileContent = new StringBuffer();
			stream.forEach(str -> fileContent.append(str));

			return fileContent.toString();
		} catch (IOException e) {
			log.error("Exception while reading file " + absoulteFileName + " ", e);
		}

		return "";

	}
	
	/**
	 * Convert String date to dateTime
	 * 
	 * @param dateString
	 * @param inputDateFormat
	 * @return
	 * @throws ParseException
	 */
	public static String convertDateToDateTime(String dateString, SimpleDateFormat inputDateFormat)
			throws ParseException {

		if (dateString == null || "".equalsIgnoreCase(dateString)) {
			throw new RuntimeException("Invalid date");
		}

		Date inputDate = inputDateFormat.parse(dateString);

		DateFormat utcFormat = new SimpleDateFormat(IConstants.DATE_FORMART_WITH_MS);
		String utcDateTimeStr = utcFormat.format(inputDate);

		return utcDateTimeStr;
	}
	
	
	/**
	 * Get external Order Line id from EOM from {@code CustomerOrderDetail}
	 * 
	 * @param customerOrderDetail
	 * @return a map containing the external line ids for each pc13s
	 */
	public Map<String, String> getExtOrderLineIdFromCustomerDetail(CustomerOrderDetail customerOrderDetail) {
		
		// Map to store ExtLineId for a corresponding pc13
		Map<String, String> pc13ToExtLineIdMap = new HashMap<>();	
		
		int sumTotalShippedQuantity = 0;
		
		for(com.levi.mp.order.model.json.OrderLine orderLine : customerOrderDetail.getCustomerOrder().getOrderLines().getOrderLineList()) {
			pc13ToExtLineIdMap.put(orderLine.getItemId(), orderLine.getExtLineId());
			sumTotalShippedQuantity += orderLine.getQuantityDetails().getTotalShippedQuantity();
		}
		
		BigDecimal totalChargeAmount = new BigDecimal("0.00");
		BigDecimal shippingAdjustment = new BigDecimal("0.00");
		
		//log.debug("sumTotalShippedQuantity>>>"+sumTotalShippedQuantity);
		
		// calculate ShippingAdjustment
		for(ChargeDetail chargeDetail : customerOrderDetail.getCustomerOrder().getChargeDetails().getChargeDetailList()) {
			if("Shipping".equalsIgnoreCase(chargeDetail.getChargeCategory())) { // checking for Shipping charge only
				totalChargeAmount = totalChargeAmount.add(chargeDetail.getChargeAmount());
			}
		}
		
		if(totalChargeAmount.signum()!=0) {
			shippingAdjustment = totalChargeAmount.divide(new BigDecimal(sumTotalShippedQuantity));
		}
		pc13ToExtLineIdMap.put(IConstants.SHIPPING_ADJUSTMENT, getStringAmountValue(shippingAdjustment));

		
		BigDecimal shippingTaxAdjustment = new BigDecimal("0.00");
		BigDecimal totalTaxAmount = new BigDecimal("0.00");
		// calculate ShippingTaxAdjustment
		for(TaxDetail taxDetail : customerOrderDetail.getCustomerOrder().getTaxDetails().getTaxDetailList())	{
			if("Freight Tax".equalsIgnoreCase(taxDetail.getTaxCategory())){
				totalTaxAmount = totalTaxAmount.add(taxDetail.getTaxAmount());
			}
		}
		
		if(totalTaxAmount.signum()!=0){
			shippingTaxAdjustment = totalTaxAmount.divide(new BigDecimal(sumTotalShippedQuantity));
		}
		pc13ToExtLineIdMap.put(IConstants.SHIPPING_TAX_ADJUSTMENT, getStringAmountValue(shippingTaxAdjustment));
	
		log.debug("pc13ToExtLineIdMap: " + pc13ToExtLineIdMap);
	
		return pc13ToExtLineIdMap;
	}
	

	/**
	 * Convert and return BigDecimal Amount to String with 2 decimals
	 * 
	 * @param bd
	 * @return
	 */
	public String getStringAmountValue(BigDecimal bd) {
		DecimalFormat df = new DecimalFormat("0.00");
		return df.format(bd);
	}

	/**
	 * Return BigDecimal Amount with 2 decimals
	 * 
	 * @param bd
	 * @return
	 */
	public BigDecimal getBigDecimalAmountValue(BigDecimal bd) {
		return bd.setScale(2, BigDecimal.ROUND_HALF_DOWN);
	}


	/**
	 * 
	 * @param retrunXML
	 * @param externalOrderNumber
	 * @return
	 */
	public Adjustment getAdustmentForFullReturn(OrderUpdateInfo orderUpdateInfo, com.levi.mp.order.retn.model.xml.TXML retrunXML) {
		Adjustment adjustment = Adjustment.builder()
			.reason(IConstants.RETURN_REASON)
			.sellerAdjustmentID(IConstants.ADJUSTMENT_ID+orderUpdateInfo.getCaOrderID())
			//.adjustmentAmount(getBigDecimalAmountValue(retrunXML.getMessage().getReturnOrder().getNetAmount())) //:TODO temp remove amount as this is not working in CA
			.build();
		
		adjustment.setCaOrderID(orderUpdateInfo.getCaOrderID());
		adjustment.setReturnOrderNo(orderUpdateInfo.getReturnOrderNo());
		adjustment.setMarketPlaceOrderID(orderUpdateInfo.getMarketPlaceOrderID());
		adjustment.setMarketPlaceorderType(orderUpdateInfo.getMarketPlaceorderType());
		
		return adjustment;
	}
	
}
