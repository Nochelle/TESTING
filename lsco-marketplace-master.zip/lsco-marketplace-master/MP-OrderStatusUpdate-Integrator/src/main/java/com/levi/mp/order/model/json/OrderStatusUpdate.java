package com.levi.mp.order.model.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown= true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"SiteName",
	"Line Items",
	"Item",
	"QTY",
	"Tender Type",
	"Card Type",
	"Promotion applied?",
	"Shipping address",
	"Shipping Method",
	"Shipping & Billing address same?",
	"Billing address",
	"Unit Item Price",
	"Item Price",
	"Shipping & Handling",
	"Discount/Promotion",
	"Tax",
	"Total Price",
	"Email",
	"Order Number",
	"CA ID"
		})
public class OrderStatusUpdate {
	
	@JsonProperty("SiteName")
	private String siteName;
	
	@JsonProperty("Line Items")
	private String lineItems;
	
	@JsonProperty("Item")
	private String item;
	
	@JsonProperty("QTY")
	private String qty;
	
	@JsonProperty("Tender Type")
	private String tenderType;
	
	@JsonProperty("Card Type")
	private String cardType;
	
	@JsonProperty("Promotion applied?")
	private String promotionapplied;
	
	@JsonProperty("Shipping address")
	private String shippingAddress;
	
	@JsonProperty("Shipping Method")
	private String shippingMethod;
	
	@JsonProperty("Shipping & Billing address same?")
	private String shippingNBillingSame;
	
	@JsonProperty("Billing address")
	private String billingaddress;
	
	@JsonProperty("Unit Item Price")
	private String unitItemPrice;
	
	@JsonProperty("Item Price")
	private String itemPrice;
	
	@JsonProperty("Shipping & Handling")
	private String shippingHandling;
	
	@JsonProperty("Discount/Promotion")
	private String discountPromotion;
	
	
	@JsonProperty("Tax")
	private String tax;
	
	@JsonProperty("Total Price")
	private String totalPrice;
	
	@JsonProperty("Email")
	private String email;
	
	@JsonProperty("Order Number")
	private String orderNumber;
	
	@JsonProperty("CA ID")
	private String caID;

}
