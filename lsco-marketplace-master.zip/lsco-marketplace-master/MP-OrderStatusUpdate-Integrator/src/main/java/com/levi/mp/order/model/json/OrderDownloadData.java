package com.levi.mp.order.model.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "siteName", "shipment_type","item1","qty1","item2","qty2", "siteOrderID",
		"Order Number", "doNbr" })
public class OrderDownloadData {

	@JsonProperty("siteName")
	private String siteName;

	@JsonProperty("shipment_type")
	private String shipment_type;
	
	@JsonProperty("item1")
	private String item1;
	
	@JsonProperty("qty1")
	private String qty1;
	
	@JsonProperty("item2")
	private String item2;
	
	@JsonProperty("qty2")
	private String qty2;

	@JsonProperty("siteOrderID")
	private String siteOrderID;

	@JsonProperty("Order Number")
	private String orderNumber;

	@JsonProperty("doNbr")
	private String doNbr;

}