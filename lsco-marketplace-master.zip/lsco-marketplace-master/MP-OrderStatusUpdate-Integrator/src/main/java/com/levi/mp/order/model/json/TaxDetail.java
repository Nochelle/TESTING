package com.levi.mp.order.model.json;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
@JsonPropertyOrder({
	"taxCategory", "taxAmount"
})
@Data
public class TaxDetail {
	@JsonProperty("taxCategory")
    private String taxCategory;
	
	@JsonProperty("taxAmount")
    private BigDecimal taxAmount;
}
