package com.levi.mp.order.model.json;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Reason", "SellerAdjustmentID", "Quantity" })
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper=true)
@JsonIgnoreProperties(
		value= {
				"caOrderID", 
				"caOrderLineID",
				"marketPlaceOrderID",
				"returnOrderNo",
				"marketPlaceorderType",
				"messageType"
			}
		)
public class Adjustment extends OrderUpdateInfo {

	@JsonProperty("Reason")
	private String reason;
	@JsonProperty("SellerAdjustmentID")
	private String sellerAdjustmentID;
	@JsonProperty("Quantity")
	private Integer quantity; 
	@JsonProperty("ShippingAdjustment")
	private BigDecimal shippingAdjustment;
	@JsonProperty("ShippingTaxAdjustment")
	private BigDecimal shippingTaxAdjustment;
	@JsonProperty("ForceCalculateOmittedAmounts")
	private Boolean forceCalculateOmittedAmounts;
	@JsonProperty("AdjustmentAmount")
	private BigDecimal adjustmentAmount;

}
