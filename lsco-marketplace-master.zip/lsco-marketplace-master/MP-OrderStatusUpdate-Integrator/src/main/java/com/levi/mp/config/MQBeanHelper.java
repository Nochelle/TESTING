package com.levi.mp.config;

import javax.jms.JMSException;
import javax.jms.QueueConnection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.mq.jms.MQQueue;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;

/**
 * 
 * This MQBeanHelper class will provide the MQQueueConnectionFactory and other MQ related classes
 * 
 * @author Prabir Nandi
 *
 */
@Component
public class MQBeanHelper {
	
	@Autowired
	OrderStatusUpdateLoadConfiguration orderImportIntegratorConfiguration;
	
	@Autowired
	MQQueueConnectionFactory mqQueueConnectionFactory;
	
	public MQQueueConnectionFactory getMQQueueConnectionFactory() throws JMSException {
		mqQueueConnectionFactory.setConnectionNameList(orderImportIntegratorConfiguration.getOrderStatusUpdateConfig().getMqConfig().getMQHOST());
		mqQueueConnectionFactory.setChannel(orderImportIntegratorConfiguration.getOrderStatusUpdateConfig().getMqConfig().getMQCHANNEL());// communications link
		mqQueueConnectionFactory.setPort(orderImportIntegratorConfiguration.getOrderStatusUpdateConfig().getMqConfig().getMQPORT());
		mqQueueConnectionFactory.setQueueManager(orderImportIntegratorConfiguration.getOrderStatusUpdateConfig().getMqConfig().getMQQMGR());// service provider
		mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
		return mqQueueConnectionFactory;
	}
	
	public QueueConnection getQueueConnection() throws JMSException {
		return getMQQueueConnectionFactory().createQueueConnection(orderImportIntegratorConfiguration.getOrderStatusUpdateConfig().getMqConfig().getMQAPPUSER(), 
				orderImportIntegratorConfiguration.getOrderStatusUpdateConfig().getMqConfig().getMQAPPPWD());
	}
	
	public MQQueue getMQQueue() throws JMSException {
		return new MQQueue(orderImportIntegratorConfiguration.getOrderStatusUpdateConfig().getMqConfig().getMQRECVQNAME());
	}
	
	public OrderStatusUpdateLoadConfiguration getConfig(){
		return orderImportIntegratorConfiguration;
	}

	
}
