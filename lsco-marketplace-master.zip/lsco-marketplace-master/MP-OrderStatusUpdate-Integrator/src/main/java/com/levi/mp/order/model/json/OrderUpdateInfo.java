package com.levi.mp.order.model.json;

import lombok.Data;

/**
 * Generic class containing attributes for posting order updates to CA
 * 
 * @author adhar@levi.com
 *
 */
@Data
public class OrderUpdateInfo {

	// Common attributes for Shipment/Returns/Cancellations
	protected String caOrderID;
	protected String caOrderLineID;
	protected String marketPlaceOrderID;
	protected String marketPlaceorderType;// OT_GOOGLE, OT_FB etc
	protected String returnOrderNo;
	protected String messageType; //For reprocesorder in SQS

}
