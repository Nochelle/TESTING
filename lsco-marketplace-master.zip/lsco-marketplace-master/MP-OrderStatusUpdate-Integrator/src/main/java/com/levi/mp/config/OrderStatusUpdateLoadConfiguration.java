package com.levi.mp.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.order.model.json.OrderStatusUpdateConfig;
import com.levi.mp.shared.ca.util.MPSharedUtil;

import lombok.extern.log4j.Log4j2;

/**
 * This class contains the necessary configuration properties for
 * Order Import Integrator application. The property OrderImportConfig is set from
 * order-import/order_import_config.json in S3 bucket levi-marketplaces
 * 
 * @author Prabir Nandi
 *
 */
@Component
@Log4j2
public class OrderStatusUpdateLoadConfiguration {

	private OrderStatusUpdateConfig orderStatusUpdateConfig;

	@Autowired
	MPSharedUtil mpSharedUtil;

	@PostConstruct
	public void init() {
		String jsonString;
		//get config file path from Lambda Environment variables
		String key = System.getenv("CONFIG_FILE_PATH"); // "order-import/order_import_config.json";
		try {
			jsonString = mpSharedUtil.getConfigValues(key);

			ObjectMapper objectMapper = new ObjectMapper();
			orderStatusUpdateConfig = objectMapper.readValue(jsonString, OrderStatusUpdateConfig.class);

			log.info("Loaded Order Import Integrator Configuration properties:" + orderStatusUpdateConfig);

		} catch (Exception e) {
			log.error("Exception occurred while loading configuration properties for Order Import Integrator: " + key
					+ " from S3", e);
			throw new RuntimeException(e);
		}
	}

	public OrderStatusUpdateConfig getOrderStatusUpdateConfig() {
		return orderStatusUpdateConfig;
	}

}
