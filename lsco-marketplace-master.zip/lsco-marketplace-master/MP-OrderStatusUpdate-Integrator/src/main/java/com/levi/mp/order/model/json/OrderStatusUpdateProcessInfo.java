package com.levi.mp.order.model.json;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * 
 * @author adhar@levi.com
 *
 */

@Getter
@Setter
@RequiredArgsConstructor
@EqualsAndHashCode
@AllArgsConstructor
public class OrderStatusUpdateProcessInfo {

	private Integer totMarketPlaceOrders;

	private Integer totGoogleAndFBReturnOrders;

	private Integer totRtrnOrdersPostedToCASuccess;

	private Integer totRtrOrdersPostedToCAFailure;

	private Integer totGoogleAndFBShipCancelOrders;
	
	private Integer totGoogleAndFBShipCancelSkipOrders;
	
	private Integer totShipmentsPostedToCASuccess;

	private Integer totShipmentsPostedToCAFailure;

	private Integer totCancellationsPostedToCASuccess;

	private Integer totCancellationsPostedToCAFailure;

	private Integer totMsgRcvdFromSQS;

	private Integer totPartialShipUpdates;

	private Integer totPartialShipUpdatesPostToCASuccess;

	private Integer totPartialShipUpdatesPostToCAFailure;

	private Integer totPartialCancelUpdates;

	private Integer totPartialCancelUpdatesPostToCASuccess;

	private Integer totPartialCancelUpdatesPostToCAFailure;

	private Integer totFullCancelUpdates;

	private Integer totFullCancelUpdatesPostToCASuccess;

	private Integer totFullCancelUpdatesPostToCAFailure;

	private Integer totPartialRtrnUpdates;

	private Integer totPartialRtrnUpdatesPostToCASuccess;

	private Integer totPartialRtrnUpdatesPostToCAFailure;

	private Integer totFullRtrnUpdates;

	private Integer totFullRtrnUpdatesPostToCASuccess;

	private Integer totFullRtrnUpdatesPostToCAFailure;

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OrderStatusUpdateProcessInfo ["
				+ (totMarketPlaceOrders != null ? "totMarketPlaceOrders=" + totMarketPlaceOrders : "") 
				+ (totGoogleAndFBReturnOrders!=null ? ", totGoogleAndFBReturnOrders="+ totGoogleAndFBReturnOrders: "") 
				+ (totRtrnOrdersPostedToCASuccess!=null ? ", totRtrnOrdersPostedToCASuccess=" + totRtrnOrdersPostedToCASuccess :"")
				+ (totRtrOrdersPostedToCAFailure!=null ? ", totRtrOrdersPostedToCAFailure=" + totRtrOrdersPostedToCAFailure: "")
				+ (totGoogleAndFBShipCancelOrders!=null ? ", totGoogleAndFBShipCancelOrders=" + totGoogleAndFBShipCancelOrders: "")
				+ (totGoogleAndFBShipCancelSkipOrders!=null ? ", totGoogleAndFBShipCancelSkipOrders=" + totGoogleAndFBShipCancelSkipOrders: "")
				+ (totShipmentsPostedToCASuccess!= null ? ", totShipmentsPostedToCASuccess=" + totShipmentsPostedToCASuccess: "")
				+ (totShipmentsPostedToCAFailure != null ? ", totShipmentsPostedToCAFailure=" + totShipmentsPostedToCAFailure : "")
				+ (totCancellationsPostedToCASuccess != null ? ", totCancellationsPostedToCASuccess=" + totCancellationsPostedToCASuccess: "")
				+ (totCancellationsPostedToCAFailure!= null ? ", totCancellationsPostedToCAFailure=" + totCancellationsPostedToCAFailure : "") 
				+ (totMsgRcvdFromSQS!= null ? ", totMsgRcvdFromSQS="+ totMsgRcvdFromSQS: "") 
				+ (totPartialShipUpdates!= null ? ", totPartialShipUpdates=" + totPartialShipUpdates: "")
				+ (totPartialShipUpdatesPostToCASuccess!= null ? ", totPartialShipUpdatesPostToCASuccess=" + totPartialShipUpdatesPostToCASuccess: "")
				+ (totPartialShipUpdatesPostToCAFailure!= null ? ", totPartialShipUpdatesPostToCAFailure=" + totPartialShipUpdatesPostToCAFailure: "")
				+ (totPartialCancelUpdates!= null ?", totPartialCancelUpdates=" + totPartialCancelUpdates: "") 
				+ (totPartialCancelUpdatesPostToCASuccess!= null ? ", totPartialCancelUpdatesPostToCASuccess="+ totPartialCancelUpdatesPostToCASuccess: "") 
				+ (totPartialCancelUpdatesPostToCAFailure != null ? ", totPartialCancelUpdatesPostToCAFailure="+ totPartialCancelUpdatesPostToCAFailure: "") 
				+ (totFullCancelUpdates != null ? ", totFullCancelUpdates=" + totFullCancelUpdates: "")
				+ (totFullCancelUpdatesPostToCASuccess!= null ? ", totFullCancelUpdatesPostToCASuccess=" + totFullCancelUpdatesPostToCASuccess: "")
				+ (totFullCancelUpdatesPostToCAFailure!= null ? ", totFullCancelUpdatesPostToCAFailure=" + totFullCancelUpdatesPostToCAFailure: "")
				+ (totPartialRtrnUpdates!= null ? ", totPartialRtrnUpdates=" + totPartialRtrnUpdates: "") 
				+ (totPartialRtrnUpdatesPostToCASuccess!= null ? ", totPartialRtrnUpdatesPostToCASuccess="+ totPartialRtrnUpdatesPostToCASuccess: "") 
				+ (totPartialRtrnUpdatesPostToCAFailure!= null ? ", totPartialRtrnUpdatesPostToCAFailure="+ totPartialRtrnUpdatesPostToCAFailure: "") 
				+ (totFullRtrnUpdates!= null ? ", totFullRtrnUpdates=" + totFullRtrnUpdates: "")
				+ (totFullRtrnUpdatesPostToCASuccess != null ? ", totFullRtrnUpdatesPostToCASuccess=" + totFullRtrnUpdatesPostToCASuccess: "")
				+ (totFullRtrnUpdatesPostToCAFailure!= null ? ", totFullRtrnUpdatesPostToCAFailure=" + totFullRtrnUpdatesPostToCAFailure: "") 
				+ "]";
	}

}
