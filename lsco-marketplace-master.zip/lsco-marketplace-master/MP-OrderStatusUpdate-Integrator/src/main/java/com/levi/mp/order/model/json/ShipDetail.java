
package com.levi.mp.order.model.json;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ShippedDateUtc",
    "TrackingNumber",
    "SellerFulfillmentID",
    "DistributionCenterID",
    "DeliveryStatus",
    "ShippingCarrier",
    "ShippingClass",
    "Items"
})
@Data
@NoArgsConstructor
public class ShipDetail {
    @JsonProperty("ShippedDateUtc")
    private String shippedDateUtc;
    @JsonProperty("TrackingNumber")
    private String trackingNumber;
    @JsonProperty("SellerFulfillmentID")
    private String sellerFulfillmentID;
    @JsonProperty("DistributionCenterID")
    private String distributionCenterID;
    @JsonProperty("DeliveryStatus")
    private String deliveryStatus;
    @JsonProperty("ShippingCarrier")
    private String shippingCarrier;
    @JsonProperty("ShippingClass")
    private String shippingClass;
    @JsonProperty("Items")
    private List<Item> items = null;
}
