package com.levi.mp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.ibm.mq.jms.MQQueueConnectionFactory;

/**
 * Create bean for external Classes so that they can be injected using spring Autowired 
 * This is a @Configuration class
 * @author Prabir Nandi
 *
 */
@Configuration
public class OrderStatusUpdateBeanConfigurator {
	
	@Bean
	MQQueueConnectionFactory mqQueueConnectionFactory(){
		return new MQQueueConnectionFactory();
	}
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@Bean("RestTemplateWithTimeout")
	public RestTemplate restTemplateWithTimeout() {
		return new RestTemplate(getClientHttpRequestFactory());
	}
	
	@Bean
	AmazonSQS amazonSQS() {
		
		return AmazonSQSClientBuilder.standard()
			.withEndpointConfiguration(
					new AwsClientBuilder.EndpointConfiguration("https://sqs.us-west-2.amazonaws.com"
							, Regions.US_WEST_2.getName()))
			.build();
		
	}
	
	// Override timeouts in request factory
	private SimpleClientHttpRequestFactory getClientHttpRequestFactory() {
		SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
		// Connect timeout 15 sec
		clientHttpRequestFactory.setConnectTimeout(15_000);

		// Read timeout 15 sec
		clientHttpRequestFactory.setReadTimeout(15_000);
		return clientHttpRequestFactory;
	}
}
