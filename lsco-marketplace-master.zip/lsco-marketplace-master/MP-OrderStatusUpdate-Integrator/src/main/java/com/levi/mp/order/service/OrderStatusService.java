package com.levi.mp.order.service;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.levi.mp.config.OrderStatusUpdateLoadConfiguration;
import com.levi.mp.order.model.json.Adjustment;
import com.levi.mp.order.model.json.OrderUpdateInfo;
import com.levi.mp.order.model.json.CustomerOrderDetail;
import com.levi.mp.order.model.json.OrderStatusUpdateProcessInfo;
import com.levi.mp.order.model.json.Shipment;
import com.levi.mp.order.model.xml.TXML;
import com.levi.mp.order.model.xml.TXML.Message.Order.OrderLines;
import com.levi.mp.order.model.xml.TXML.Message.Order.ShipmentDetails.ShipmentDetail;
import com.levi.mp.order.rest.client.OrderStatusRestClientAdapter;
import com.levi.mp.order.util.IConstants;
import com.levi.mp.order.util.MQMsgReceiver;
import com.levi.mp.order.util.OrderStatusUpdateUtil;
import com.levi.mp.shared.ca.auth.ChannelAdvisorTokenService;
import com.levi.mp.shared.ca.util.MPSharedUtil;
import com.levi.mp.shared.sns.SNSService;

import lombok.extern.log4j.Log4j2;

/**
 * 
 * @author Prabir Nandi
 *
 */
@Service
@Log4j2
public class OrderStatusService {

	@Autowired
	ChannelAdvisorTokenService channelAdvisorTokenService;

	@Autowired
	MPSharedUtil mpSharedUtil;

	@Autowired
	OrderStatusUpdateUtil orderStatusUpdateUtil;

	@Autowired
	SNSService snsService;

	@Autowired
	OrderStatusRestClientAdapter orderStatusRestClientAdapter;

	@Autowired
	MQMsgReceiver mQMsgReceiver;

	@Autowired
	SQSMessageService sqsMessageService;

	@Autowired
	OrderStatusUpdateLoadConfiguration orderStatusUpdateLoadConfiguration;

	OrderStatusUpdateProcessInfo orderStatusUpdateProcessInfo = new OrderStatusUpdateProcessInfo();

	public void updateOrderStatus() throws IOException {

		// get the Order status xml List from MQ
		List<String> respMsgList = mQMsgReceiver.receiveMQMsg();

		if (respMsgList == null || respMsgList.size() < 1) {
			log.info("No messeages found on MQ, do return back>>>");
			//Set up statistics in case there are no messages from MQ 
			orderStatusUpdateProcessInfo.setTotMarketPlaceOrders(0);
			return;
		}

		final String caAccessToken = channelAdvisorTokenService.getOAuth2Token();
		// log.info("caAccessToken>>>"+caAccessToken);

		JAXBContext jaxbContext;
		String caOrderId = "";
		String orderNo = "";
		String returnOrderNo = "";
		ShipmentDetail shipmentDetail;
		OrderLines orderLines;
		String orderType = "";

		int googleReturnOrderCount = 0;

		int googleRtnOrdFailPostToCA = 0;
		int googleRtnOrdSuccessPostToCA = 0;
		int googleShipOrdLineSuccessPostToCA = 0;
		int googleShipOrdLineFailPostToCA = 0;
		int googleCancelOrdLineSuccessPostToCA = 0;
		int googleCancelOrdLineFailPostToCA = 0;

		int fbRtnOrdFailPostToCA = 0;
		int fbRtnOrdSuccessPostToCA = 0;
		int fbShipOrdLineSuccessPostToCA = 0;
		int fbShipOrdLineFailPostToCA = 0;
		int fbCancelOrdLineSuccessPostToCA = 0;
		int fbCancelOrdLineFailPostToCA = 0;

		int facebookReturnOrderCount = 0;
		int shipCancelGoogleOrderCount = 0;
		int shipCancelFacebookOrderCount = 0;

		int googleShipCancelSkipOrderCount = 0;
		int fbShipCancelSkipOrderCount = 0;

		// iterate all messages and update CA with Shipment/Cancel status
		for (String xmlString : respMsgList) {
			List<Shipment> shipmentList = null;
			boolean hasStatusUpdateData = Boolean.FALSE;
			boolean isMarketplaceOrder = Boolean.FALSE;

			try {
				// check for message type and ReturnOrderStatus as 'Return Invoice Created' for Return processing
				if (xmlString.contains("<Message_Type>ReturnOrder</Message_Type>") 
						&& xmlString.contains("<ReturnOrderStatus>Return Invoice Created</ReturnOrderStatus>")) {
					jaxbContext = JAXBContext.newInstance(com.levi.mp.order.retn.model.xml.TXML.class);
					Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
					com.levi.mp.order.retn.model.xml.TXML returnTXML = (com.levi.mp.order.retn.model.xml.TXML) unmarshaller.unmarshal(new StringReader(xmlString));
					orderNo = returnTXML.getMessage().getReturnOrder().getParentOrderNumber();
					returnOrderNo = returnTXML.getMessage().getReturnOrder().getReturnOrderNumber();

					// filter for GOOGLE & FACEBOOK type of return orders
					if (!StringUtils.isEmpty(orderNo) && (orderNo.length() >= 14 || orderNo.startsWith("G-"))) {

						isMarketplaceOrder = Boolean.TRUE;
						log.debug("Processing return for Order:" + orderNo);

						// Count of google or facebook return orders
						if (orderNo.startsWith("G-")) {
							googleReturnOrderCount++;
						} else if (orderNo.length() >= 14) {
							facebookReturnOrderCount++;
						}

						// Call LEVI EOM API for getting CustomerOrderDetail
						// Invoke the LEVI EOM REST API
						CustomerOrderDetail customerOrderDetail = orderStatusRestClientAdapter.fetchCustomerOrderDetailsFromEOM(orderNo);
						caOrderId = customerOrderDetail.getCustomerOrder().getExternalOrderNumber();

						log.info("Processing return for Order:" + orderNo + ", caOrderId:" + caOrderId
								+", Order Type:"+customerOrderDetail.getCustomerOrder().getOrderType());

						OrderUpdateInfo orderUpdateInfo = new OrderUpdateInfo();
						orderUpdateInfo.setCaOrderID(caOrderId);
						orderUpdateInfo.setReturnOrderNo(returnOrderNo);
						orderUpdateInfo.setMarketPlaceOrderID(orderNo);
						orderUpdateInfo.setMarketPlaceorderType(customerOrderDetail.getCustomerOrder().getOrderType());

						// Split update to CA logic for Google and Facebook return orders
						if (IConstants.ORDER_TYPE_GOOGLE.equalsIgnoreCase(customerOrderDetail.getCustomerOrder().getOrderType())) { // Google return
							// call EOM customerOrderDetails API, get pc13 and get the extLineId
							Map<String, String> respMap = orderStatusUpdateUtil.getExtOrderLineIdFromCustomerDetail(customerOrderDetail);

							List<Adjustment> returnItems = orderStatusUpdateUtil.getReturns(orderUpdateInfo, returnTXML.getMessage().getReturnOrder().getReturnOrderLines(), respMap);

							if (returnItems != null && returnItems.size() > 0) {
								hasStatusUpdateData = Boolean.TRUE;
							}

							Map<String, Integer> returnUpdateToCAStatusMap = postReturnUpdateToCA(returnItems, caAccessToken);

							// Store status of return updates post to CA for each of the order lines for an order
							googleRtnOrdSuccessPostToCA += returnUpdateToCAStatusMap.get(IConstants.SUCESS);
							googleRtnOrdFailPostToCA += returnUpdateToCAStatusMap.get(IConstants.FAILURE);

						} else if (IConstants.ORDER_TYPE_FB.equalsIgnoreCase(customerOrderDetail.getCustomerOrder().getOrderType())) { // Facebook return
							// Since this is a facebook order, so only FULL return is allowed that means a FULL Order cancel

							hasStatusUpdateData = Boolean.TRUE;

							boolean status = postFullReturnUpdateToCA(orderStatusUpdateUtil.getAdustmentForFullReturn(orderUpdateInfo, returnTXML), caAccessToken);

							if (status) {
								fbRtnOrdSuccessPostToCA++;
							} else {
								fbRtnOrdFailPostToCA++;
							}
						}

					} // else skip as this is not either Google or Facebook return
				} else if (xmlString.contains("<Message_Type>ORDER_STATUS</Message_Type>")) { // process for Order status update (shipment & cancel )

					jaxbContext = JAXBContext.newInstance(TXML.class);
					Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
					TXML txml = (TXML) unmarshaller.unmarshal(new StringReader(xmlString));

					orderType = txml.getMessage().getOrder().getOrderType();
					// filter by order type, only process OT_GOOGLE & OT_FACEBOOK type of orders
					if (IConstants.ORDER_TYPE_GOOGLE.equalsIgnoreCase(orderType) || IConstants.ORDER_TYPE_FB.equalsIgnoreCase(orderType)) {

						isMarketplaceOrder = Boolean.TRUE;

						if (IConstants.ORDER_TYPE_GOOGLE.equalsIgnoreCase(orderType)) {
							shipCancelGoogleOrderCount++;
						} else {
							shipCancelFacebookOrderCount++;
						}

						orderNo = txml.getMessage().getOrder().getOrderNumber().getValue();
						caOrderId = txml.getMessage().getOrder().getExternalOrderNumber().getValue();

						// CA Order basic info
						OrderUpdateInfo orderUpdateInfo = new OrderUpdateInfo();
						orderUpdateInfo.setCaOrderID(caOrderId);
						orderUpdateInfo.setMarketPlaceOrderID(orderNo);
						orderUpdateInfo.setMarketPlaceorderType(orderType);

						log.debug("***Processing shipment/cancel update for Order: " + orderNo + ", CA Order ID: " + caOrderId);

						// skip shipment update if there is no shipment detail info
						if (txml.getMessage().getOrder().getShipmentDetails().getShipmentDetail() != null) {
							shipmentDetail = txml.getMessage().getOrder().getShipmentDetails().getShipmentDetail();
							// log.debug("TotalNumberOfCartons>>" + shipmentDetail.getTotalNumberOfCartons());

							shipmentList = orderStatusUpdateUtil.getShipments(orderUpdateInfo, shipmentDetail);

							if (shipmentList != null && shipmentList.size() > 0) {
								hasStatusUpdateData = Boolean.TRUE;
								log.info("Processing shipment status update for Order: " + orderNo + ", CA Order ID: " + caOrderId + ", total shipment count: " + shipmentList.size());
								// update shipment
								Map<String, Integer> shipmentStatusUpdateMap = postShipmentUpdateToCA(shipmentList, caAccessToken);

								// Track Shipment status
								if (IConstants.ORDER_TYPE_GOOGLE.equalsIgnoreCase(orderType)) {
									googleShipOrdLineSuccessPostToCA += shipmentStatusUpdateMap.get(IConstants.SUCESS);
									googleShipOrdLineFailPostToCA += shipmentStatusUpdateMap.get(IConstants.FAILURE);
								} else {
									fbShipOrdLineSuccessPostToCA += shipmentStatusUpdateMap.get(IConstants.SUCESS);
									fbShipOrdLineFailPostToCA += shipmentStatusUpdateMap.get(IConstants.FAILURE);
								}
							}

						}

						// update cancel status only if there is no shipment happened for the same order
						// as per logic the shipment and cancel updates will never come together in a single order status XML
						if (shipmentList == null || shipmentList.size() == 0) { // for cancel order

							String orderStatus = txml.getMessage().getOrder().getOrderStatus();

							if (IConstants.ORDER_TYPE_FB.equalsIgnoreCase(orderType)) { // for Facebook order cancel
								if ("Canceled".equalsIgnoreCase(orderStatus)) {
									// update Full Order Cancel for Facebook
									log.info("Processing cancel status update for Order:" + orderNo + ", CA Order ID:" + caOrderId);
									hasStatusUpdateData = Boolean.TRUE;
									boolean fullOrderCancelStatus = postAdjustmentsToCAForFullOrderCancel(orderUpdateInfo, caAccessToken);

									if (fullOrderCancelStatus) {
										fbCancelOrdLineSuccessPostToCA++;
									} else {
										fbCancelOrdLineFailPostToCA++;
									}

								} else {
									// Keep a track of shipCancel orders which do not contain either valid shipment/cancellations
									fbShipCancelSkipOrderCount++;
									// Ignore and log. Do not NotifyMPSupport.
									log.warn("No shipment or cancellation request found in ORDER_STATUS Message_Type XML for Order No: " + orderNo + ", CA Order ID: " + caOrderId
											+ ", MarketplaceOrderType:" + orderType);
								}

							} else if (IConstants.ORDER_TYPE_GOOGLE.equalsIgnoreCase(orderType)) { // for Google order cancel
								if (!"Canceled".equalsIgnoreCase(orderStatus) && !"Released".equalsIgnoreCase(orderStatus)) {
									orderLines = txml.getMessage().getOrder().getOrderLines();
									List<Adjustment> cancelItems = orderStatusUpdateUtil.getCancellations(orderUpdateInfo, orderLines);

									if (cancelItems != null && cancelItems.size() > 0) {
										// update Partial cancel for Google
										log.info("Processing cancel status update for Order: " + orderNo + ", CA Order ID: " + caOrderId + ", cancelled quantity: " + cancelItems.size());
										hasStatusUpdateData = Boolean.TRUE;
										Map<String, Integer> cancellationToCAStatusMap = postAdjustmentsToCAForPartialCancel(cancelItems, caAccessToken);

										googleCancelOrdLineSuccessPostToCA += cancellationToCAStatusMap.get(IConstants.SUCESS);
										googleCancelOrdLineFailPostToCA += cancellationToCAStatusMap.get(IConstants.FAILURE);
									} else {
										googleShipCancelSkipOrderCount++;
										String notificationMessage = "NewCancelQty data not found in ORDER_STATUS Message_Type XML for Order No: " + orderNo + ", CA Order ID: " + caOrderId
												+ ", MarketplaceOrderType: " + orderType;
										log.info(notificationMessage);
										hasStatusUpdateData=true;
									}
								} else {
									googleShipCancelSkipOrderCount++;// This scenario is for google xml messages which has an order status of Canceled
									log.info("Ignore this Google Order Level cancel Message_Type ORDER_STATUS XML for Order No: " + orderNo + ", CA Order ID: " + caOrderId
											+ ", MarketplaceOrderType: " + orderType);
									hasStatusUpdateData=true;
								}
							} // end Google order cancel processing

						} // end cancel order processing

					} // else skip as this is not either Google or Facebook order status (shipment & cancel ) update
				} // else skip as this message is not either status update or return

				if (isMarketplaceOrder && !hasStatusUpdateData) { // if no Return, shipment and cancellation data found, log that order
					log.info("Either of return, shipment or cancelation data found for Order No: " + orderNo + ", CA Order ID: " + caOrderId + ", MarketplaceOrderType: " + orderType);
				}
			} catch (Exception e) {
				log.error("Exception occurred during processing status update for OrderNumber:" + orderNo + ", CA Order ID:" + caOrderId, e);
				// TODO: handle exception save error to MQ for post processing
				log.info("Sending notification to support team");
				// Notify Support
				String notificationMessage = "Exception while processing status update for OrderNumber: " + orderNo + ", CA Order ID: " + caOrderId + ", MarketplaceOrderType: " + orderType
						+ System.lineSeparator() + "Error Message: " + System.lineSeparator() + ExceptionUtils.getStackTrace(e);
				String subject = "[MP-OrderStatusUpdate]:Exception while processing status update for Order No:" + orderNo;

				snsService.notifySupport(notificationMessage, subject);
				// throw new RuntimeException(notificationMessage, e);
			}
		} // end for loop

		// Store track of process related information

		orderStatusUpdateProcessInfo.setTotMarketPlaceOrders(googleReturnOrderCount + facebookReturnOrderCount + shipCancelGoogleOrderCount + shipCancelFacebookOrderCount);
		orderStatusUpdateProcessInfo.setTotGoogleAndFBReturnOrders(googleReturnOrderCount + facebookReturnOrderCount);
		orderStatusUpdateProcessInfo.setTotRtrnOrdersPostedToCASuccess(googleRtnOrdSuccessPostToCA + fbRtnOrdSuccessPostToCA);
		orderStatusUpdateProcessInfo.setTotRtrOrdersPostedToCAFailure(googleRtnOrdFailPostToCA + fbRtnOrdFailPostToCA);
		orderStatusUpdateProcessInfo.setTotGoogleAndFBShipCancelOrders(shipCancelGoogleOrderCount + shipCancelFacebookOrderCount);
		orderStatusUpdateProcessInfo.setTotGoogleAndFBShipCancelSkipOrders(googleShipCancelSkipOrderCount + fbShipCancelSkipOrderCount);
		orderStatusUpdateProcessInfo.setTotShipmentsPostedToCASuccess(googleShipOrdLineSuccessPostToCA + fbShipOrdLineSuccessPostToCA);
		orderStatusUpdateProcessInfo.setTotShipmentsPostedToCAFailure(googleShipOrdLineFailPostToCA + fbShipOrdLineFailPostToCA);
		orderStatusUpdateProcessInfo.setTotCancellationsPostedToCASuccess(googleCancelOrdLineSuccessPostToCA + fbCancelOrdLineSuccessPostToCA);
		orderStatusUpdateProcessInfo.setTotCancellationsPostedToCAFailure(googleCancelOrdLineFailPostToCA + fbCancelOrdLineFailPostToCA);

		log.info("--------------------------------------------OrderStatusUpdate Process Statistics:--------------------------------------------");
		log.info("Total number of marketPlace orders received from MQ: " + orderStatusUpdateProcessInfo.getTotMarketPlaceOrders());
		log.info("Total number of Google and facebook return orders: " + orderStatusUpdateProcessInfo.getTotGoogleAndFBReturnOrders());
		log.info("Total number of Google return orders: " + googleReturnOrderCount);
		log.info("Total number of Google return order lines posted successfully to CA: " + googleRtnOrdSuccessPostToCA);
		log.info("Total number of Google return order lines which could not be posted to CA: " + googleRtnOrdFailPostToCA);

		log.info("Total number of Facebook return orders: " + facebookReturnOrderCount);
		log.info("Total number of Facebook return orders posted successfully to CA: " + fbRtnOrdSuccessPostToCA);
		log.info("Total number of Facebook return orders which could not be posted to CA: " + fbRtnOrdFailPostToCA);

		log.info("Total number of Google and Facebook Ship/Cancel orders: " + orderStatusUpdateProcessInfo.getTotGoogleAndFBShipCancelOrders());
		log.info("Total number of Google Ship/Cancel orders: " + shipCancelGoogleOrderCount);
		log.info("Total number of Google Ship/Cancel Skipped orders: " + googleShipCancelSkipOrderCount);
		// Shipments for Google
		log.info("Total number of Google Shipments posted successfully to CA: " + googleShipOrdLineSuccessPostToCA);
		log.info("Total number of Google Shipments which could not be posted to CA: " + googleShipOrdLineFailPostToCA);
		// Cancellations for Google
		log.info("Total number of Google Cancellations posted successfully to CA: " + googleCancelOrdLineSuccessPostToCA);
		log.info("Total number of Google Cancellations which could not be posted to CA: " + googleCancelOrdLineFailPostToCA);

		// Shipments for Facebook
		log.info("Total number of Facebook Ship/Cancel orders: " + shipCancelFacebookOrderCount);
		log.info("Total number of Facebook Ship/Cancel Skipped orders: " + fbShipCancelSkipOrderCount);
		log.info("Total number of Facebook Shipments posted successfully to CA: " + fbShipOrdLineSuccessPostToCA);
		log.info("Total number of Facebook Shipments which could not be posted to CA: " + fbShipOrdLineFailPostToCA);

		// Cancellations for Facebook
		log.info("Total number of Facebook Cancellations posted successfully to CA: " + fbCancelOrdLineSuccessPostToCA);
		log.info("Total number of Facebook Cancellations which could not be posted to CA: " + fbCancelOrdLineFailPostToCA);

		log.info("----------------------------------------------------------------------------------------");

	}

	/**
	 * 
	 * @param caOrderId
	 * @param caAccessToken
	 */
	public boolean postAdjustmentsToCAForFullOrderCancel(OrderUpdateInfo adjustment, String caAccessToken) {
		return orderStatusRestClientAdapter.updateFullOrderCancelStatus(adjustment, caAccessToken);
	}

	/**
	 * Iterate orderline cancellation to call CA Adjustment API
	 * 
	 * @param adjustmentMap
	 * @return
	 */
	public Map<String, Integer> postAdjustmentsToCAForPartialCancel(List<Adjustment> adjustmentList, String caAccessToken) {

		Map<String, Integer> cancellationToCAStatusMap = new HashMap<>();

		int successCount = 0;
		int failureCount = 0;

		for (Adjustment adjustment : adjustmentList) {
			/* String caOrderLineId = entry.getKey(); */
			/* Adjustment adjustment = entry.getValue(); */
			boolean status = orderStatusRestClientAdapter.updatePartialOrderCancelStatus(adjustment, caAccessToken);
			if (status) {
				successCount++;
			} else {
				failureCount++;
			}
		}

		cancellationToCAStatusMap.put(IConstants.SUCESS, successCount);
		cancellationToCAStatusMap.put(IConstants.FAILURE, failureCount);

		return cancellationToCAStatusMap;

	}

	/**
	 * Iterate shipments to call CA ship update API
	 * 
	 * @param externalOrderNumber
	 * @param shipmentUpdates
	 * @return
	 */
	public Map<String, Integer> postShipmentUpdateToCA(List<Shipment> shipmentUpdates, String caAccessToken) {

		Map<String, Integer> shipmentStatusMap = new HashMap<>();

		int successCount = 0;
		int failureCount = 0;

		// for each shipment call CA Ship API
		for (Shipment shipment : shipmentUpdates) {
			boolean status = orderStatusRestClientAdapter.updateShipStatus(shipment, caAccessToken);
			if (status) {
				successCount++;
			} else {
				failureCount++;
			}
		}

		shipmentStatusMap.put(IConstants.SUCESS, successCount);
		shipmentStatusMap.put(IConstants.FAILURE, failureCount);

		return shipmentStatusMap;

	}

	/**
	 * 
	 * @param returntMap
	 * @param caAccessToken
	 */
	public Map<String, Integer> postReturnUpdateToCA(List<Adjustment> returnItems, String caAccessToken) {

		Map<String, Integer> returnUpdateToCAStatusMap = new HashMap<>();

		int successCount = 0;
		int failureCount = 0;

		for (Adjustment adjustment : returnItems) {
			/*
			 * String caOrderLineId = entry.getKey(); Adjustment adjustment = entry.getValue();
			 */
			boolean status = orderStatusRestClientAdapter.updateReturnOrderStatus(adjustment, caAccessToken);
			if (status) {
				successCount++;
			} else {
				failureCount++;
			}
		}

		returnUpdateToCAStatusMap.put(IConstants.SUCESS, successCount);
		returnUpdateToCAStatusMap.put(IConstants.FAILURE, failureCount);

		return returnUpdateToCAStatusMap;

	}

	private boolean postFullReturnUpdateToCA(Adjustment adustmentForFullReturn, String caAccessToken) {
		return orderStatusRestClientAdapter.updateFullReturnOrderStatus(adustmentForFullReturn, caAccessToken);
	}

	/**
	 * 
	 * @throws IOException
	 */
	public void reprocessUpdateOrderStatus() throws IOException {

		int noOfPartialShipUpdates = 0;
		int noOfPartialCancelUpdates = 0;
		int noOfFullCancelUpdates = 0;
		int noOfPartialReturnUpdates = 0;
		int noOfFullReturnUpdates = 0;

		int noOfPartialShipUpdatesSuccessPostToCA = 0;
		int noOfPartialShipUpdatesFailPostToCA = 0;
		int noOfPartialCancelUpdatesSuccessPostToCA = 0;
		int noOfPartialCancelUpdatesFailPostToCA = 0;
		int noOfFullCancelUpdatesSuccesPostToCA = 0;
		int noOfFullCancelUpdatesFailPostToCA = 0;
		int noOfPartialReturnUpdatesSuccessPostToCA = 0;
		int noOfPartialReturnUpdatesFailPostToCA = 0;
		int noOfFullReturnUpdatesSuccessPostToCA = 0;
		int noOfFullReturnUpdatesFailPostToCA = 0;

		log.info("Processing SQS started>>>");
		Map<String, String> sqsMsgMap = sqsMessageService.getMessages();

		if (sqsMsgMap == null || sqsMsgMap.size() < 1) {
			log.info("No messeages found on SQS, do return back>>>");
			//Set up statistics in case there are no messages from SQS 
			orderStatusUpdateProcessInfo.setTotMsgRcvdFromSQS(0);
			return;
		}

		final String caAccessToken = channelAdvisorTokenService.getOAuth2Token();
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.disable(MapperFeature.USE_ANNOTATIONS);
		
		String msg;
		String receiptHandle;
		for (Map.Entry<String, String> entry : sqsMsgMap.entrySet()) {
			msg = entry.getValue();
			receiptHandle = entry.getKey();
			if (!StringUtils.isEmpty(msg)) {
				if (msg.contains(IConstants.PARTIAL_SHIP_UPDATE)) {
					noOfPartialShipUpdates++;
					Shipment shipment = objectMapper.readValue(msg, Shipment.class);
					List<Shipment> shipmentList = new ArrayList<>();
					shipmentList.add(shipment);

					Map<String, Integer> shipmentStatusMap = postShipmentUpdateToCA(shipmentList, caAccessToken);

					noOfPartialShipUpdatesSuccessPostToCA += shipmentStatusMap.get(IConstants.SUCESS);
					noOfPartialShipUpdatesFailPostToCA += shipmentStatusMap.get(IConstants.FAILURE);

					sqsMessageService.deleteMessage(receiptHandle);
				} else if (msg.contains(IConstants.PARTIAL_CANCEL_UPDATE)) {
					noOfPartialCancelUpdates++;
					Adjustment adjustment = objectMapper.readValue(msg, Adjustment.class);
					List<Adjustment> adjustmentMap = new ArrayList<>();
					adjustmentMap.add(adjustment);

					Map<String, Integer> cancellationToCAStatusMap = postAdjustmentsToCAForPartialCancel(adjustmentMap, caAccessToken);

					noOfPartialCancelUpdatesSuccessPostToCA += cancellationToCAStatusMap.get(IConstants.SUCESS);
					noOfPartialCancelUpdatesFailPostToCA += cancellationToCAStatusMap.get(IConstants.FAILURE);

					sqsMessageService.deleteMessage(receiptHandle);
				} else if (msg.contains(IConstants.FULL_CANCEL_UPDATE)) {
					noOfFullCancelUpdates++;
					Adjustment adjustment = objectMapper.readValue(msg, Adjustment.class);

					boolean status = postAdjustmentsToCAForFullOrderCancel(adjustment, caAccessToken);

					// Keep track of statuses
					if (status) {
						noOfFullCancelUpdatesSuccesPostToCA++;

					} else {
						noOfFullCancelUpdatesFailPostToCA++;
					}

					sqsMessageService.deleteMessage(receiptHandle);
				} else if (msg.contains(IConstants.PARTIAL_RETURN_UPDATE)) {
					noOfPartialReturnUpdates++;
					Adjustment adjustment = objectMapper.readValue(msg, Adjustment.class);
					List<Adjustment> returnItems = new ArrayList<>();
					returnItems.add(adjustment);

					Map<String, Integer> returnUpdateToCAStatusMap = postReturnUpdateToCA(returnItems, caAccessToken);

					noOfPartialReturnUpdatesSuccessPostToCA += returnUpdateToCAStatusMap.get(IConstants.SUCESS);
					noOfPartialReturnUpdatesFailPostToCA += returnUpdateToCAStatusMap.get(IConstants.FAILURE);

					sqsMessageService.deleteMessage(receiptHandle);
				} else if (msg.contains(IConstants.FULL_RETURN_UPDATE)) {
					noOfFullReturnUpdates++;
					Adjustment adjustment = objectMapper.readValue(msg, Adjustment.class);

					boolean status = postFullReturnUpdateToCA(adjustment, caAccessToken);

					// Keep track of statuses
					if (status) {
						noOfFullReturnUpdatesSuccessPostToCA++;

					} else {
						noOfFullReturnUpdatesFailPostToCA++;
					}

					sqsMessageService.deleteMessage(receiptHandle);
				} else {
					log.warn("***NOT a Valid message from SQS***");
				}
			}
		}

		log.info("Processing SQS completed>>>");

		// Store track of process related information
		orderStatusUpdateProcessInfo.setTotMsgRcvdFromSQS(sqsMsgMap.size());
		orderStatusUpdateProcessInfo.setTotPartialShipUpdates(noOfPartialShipUpdates);
		orderStatusUpdateProcessInfo.setTotPartialShipUpdatesPostToCASuccess(noOfPartialShipUpdatesSuccessPostToCA);
		orderStatusUpdateProcessInfo.setTotPartialShipUpdatesPostToCAFailure(noOfPartialShipUpdatesFailPostToCA);
		orderStatusUpdateProcessInfo.setTotPartialCancelUpdates(noOfPartialCancelUpdates);
		orderStatusUpdateProcessInfo.setTotPartialCancelUpdatesPostToCASuccess(noOfPartialCancelUpdatesSuccessPostToCA);
		orderStatusUpdateProcessInfo.setTotPartialCancelUpdatesPostToCAFailure(noOfPartialCancelUpdatesFailPostToCA);
		orderStatusUpdateProcessInfo.setTotFullCancelUpdates(noOfFullCancelUpdates);
		orderStatusUpdateProcessInfo.setTotFullCancelUpdatesPostToCASuccess(noOfFullCancelUpdatesSuccesPostToCA);
		orderStatusUpdateProcessInfo.setTotFullCancelUpdatesPostToCAFailure(noOfFullCancelUpdatesFailPostToCA);
		orderStatusUpdateProcessInfo.setTotPartialRtrnUpdates(noOfPartialReturnUpdates);
		orderStatusUpdateProcessInfo.setTotPartialRtrnUpdatesPostToCASuccess(noOfPartialReturnUpdatesSuccessPostToCA);
		orderStatusUpdateProcessInfo.setTotPartialRtrnUpdatesPostToCAFailure(noOfPartialReturnUpdatesFailPostToCA);
		orderStatusUpdateProcessInfo.setTotFullRtrnUpdates(noOfFullReturnUpdates);
		orderStatusUpdateProcessInfo.setTotFullRtrnUpdatesPostToCASuccess(noOfFullReturnUpdatesSuccessPostToCA);
		orderStatusUpdateProcessInfo.setTotFullRtrnUpdatesPostToCAFailure(noOfFullReturnUpdatesFailPostToCA);

		// log.info(">>>>>>>>>>>>>"+orderStatusUpdateProcessInfo);

		/*
		 * String processInfo; try { processInfo = new ObjectMapper().writer().withDefaultPrettyPrinter() .writeValueAsString(orderStatusUpdateProcessInfo); log.info(processInfo); } catch
		 * (JsonProcessingException e) { // TODO Auto-generated catch block e.printStackTrace(); }
		 */

		log.info("--------------------------------------------Reprocess OrderStatusUpdate Process Statistics:--------------------------------------------");
		log.info("Total number of mesages fetched from SQS: " + sqsMsgMap.size());
		log.info("Total number of " + IConstants.PARTIAL_SHIP_UPDATE + " messages from SQS: " + noOfPartialShipUpdates);
		log.info("Total number of Shipments posted successfully to CA: " + noOfPartialShipUpdatesSuccessPostToCA);
		log.info("Total number of Shipments which could not be posted to CA: " + noOfPartialShipUpdatesFailPostToCA);

		log.info("Total number of " + IConstants.PARTIAL_CANCEL_UPDATE + " messages from SQS: " + noOfPartialCancelUpdates);
		log.info("Total number of Partial Cancellations posted successfully to CA: " + noOfPartialCancelUpdatesSuccessPostToCA);
		log.info("Total number of Partial Cancellations which could not be posted to CA: " + noOfPartialCancelUpdatesFailPostToCA);

		log.info("Total number of " + IConstants.FULL_CANCEL_UPDATE + " messages from SQS: " + noOfFullCancelUpdates);
		log.info("Total number of Full Cancel Updates posted successfully to CA: " + noOfFullCancelUpdatesSuccesPostToCA);
		log.info("Total number of Full Cancel Updates which could not be posted to CA: " + noOfFullCancelUpdatesFailPostToCA);

		log.info("Total number of " + IConstants.PARTIAL_RETURN_UPDATE + " messages from SQS: " + noOfPartialReturnUpdates);
		log.info("Total number of Partial Return Updates osted successfully to CA: " + noOfPartialReturnUpdatesSuccessPostToCA);
		log.info("Total number of Partial Return Updates which could not be posted to CA: " + noOfPartialReturnUpdatesFailPostToCA);

		log.info("Total number of " + IConstants.FULL_RETURN_UPDATE + " messages from SQS: " + noOfFullReturnUpdates);
		log.info("Total number of Full Return Updates posted successfully to CA: " + noOfFullReturnUpdatesSuccessPostToCA);
		log.info("Total number of Full Return Updates which could not be posted to CA: " + noOfFullReturnUpdatesFailPostToCA);
		log.info("----------------------------------------------------------------------------------------");

	}

	/**
	 * Get config json from S3
	 * 
	 * @return
	 * @throws IOException
	 */
//	public OrderStatusUpdateConfig getConfig() throws IOException {
//
//		String jsonString = mpSharedUtil.getConfigValues("order-status-update/order_status_update_config.json");
//		ObjectMapper objectMapper = new ObjectMapper();
//		return objectMapper.readValue(jsonString, OrderStatusUpdateConfig.class);
//	}

	public OrderStatusUpdateProcessInfo getOrderStatusUpdateProcessInfo() {
		return orderStatusUpdateProcessInfo;
	}

	public void setOrderStatusUpdateProcessInfo(OrderStatusUpdateProcessInfo orderStatusUpdateProcessInfo) {
		this.orderStatusUpdateProcessInfo = orderStatusUpdateProcessInfo;
	}
}
