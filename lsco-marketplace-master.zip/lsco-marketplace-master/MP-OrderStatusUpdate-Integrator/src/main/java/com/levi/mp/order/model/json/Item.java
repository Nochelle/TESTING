
package com.levi.mp.order.model.json;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Sku",
    "Quantity"
})
@Data
@NoArgsConstructor
public class Item {
    @JsonProperty("Sku")
    private String sku;
    @JsonProperty("Quantity")
    private Integer quantity;
}
