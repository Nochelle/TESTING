package com.levi.mp.order.model.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.levi.mp.order.util.OrderLinesDeserializer;
import com.levi.mp.order.util.TaxDetailsDeserializer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
@JsonPropertyOrder({
	"externalOrderNumber",
    "orderLines"
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerOrder {
	
	@JsonProperty("externalOrderNumber")
	private String externalOrderNumber;
	
	@JsonProperty("orderLines")
	@JsonDeserialize(using=OrderLinesDeserializer.class)
    private OrderLines orderLines;
	
	@JsonProperty("chargeDetails")
	private ChargeDetails chargeDetails;
	
	@JsonProperty("taxDetails")
	@JsonDeserialize(using=TaxDetailsDeserializer.class)
	private TaxDetails taxDetails;
	
	@JsonProperty("orderType")
	private String orderType;
	
}
