package com.levi.mp.order.model.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
@JsonPropertyOrder({ 
	"MQ_CONFIG",
	"SQS_QUEUE_NAME",
	"SQS_MSG_DELAY_SEC",
	"LEVI_EOM_USERNAME",
	"LEVI_EOM_PASSWD",
	"LEVI_EOM_HOST"
	})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderStatusUpdateConfig {
	
	@JsonProperty("MQ_CONFIG")
	MQConfig mqConfig;
	
	@JsonProperty("SQS_QUEUE_NAME")
	String sqsQueueName;
	
	@JsonProperty("SQS_MSG_DELAY_SEC")
	String sqsMsgDelaySec;
	
	@JsonProperty("LEVI_EOM_USERNAME")
	private String leviEOMUserName;
	
	@JsonProperty("LEVI_EOM_PASSWD")
	private String leviEOMPasswd;
	
	@JsonProperty("LEVI_EOM_HOST")
	private String leviEOMHost;
}
